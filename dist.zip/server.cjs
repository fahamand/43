var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server.ts
var server_exports = {};
module.exports = __toCommonJS(server_exports);
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var import_dns = __toESM(require("dns"), 1);
var import_genai = require("@google/genai");
var import_dotenv = __toESM(require("dotenv"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_promise = __toESM(require("mysql2/promise"), 1);
var import_adm_zip = __toESM(require("adm-zip"), 1);
var import_compression = __toESM(require("compression"), 1);
import_dotenv.default.config();
import_dns.default.setDefaultResultOrder("ipv4first");
function getAppConfig() {
  const configPath = import_path.default.join(process.cwd(), "wp-config.json");
  if (import_fs.default.existsSync(configPath)) {
    try {
      const content = import_fs.default.readFileSync(configPath, "utf8");
      const parsed = JSON.parse(content);
      if (parsed.GEMINI_API_KEY) {
        process.env.GEMINI_API_KEY = parsed.GEMINI_API_KEY;
      }
      if (parsed.GEMINI_BASE_URL) {
        process.env.GEMINI_BASE_URL = parsed.GEMINI_BASE_URL;
      }
      if (parsed.PORT) {
        process.env.PORT = parsed.PORT.toString();
      }
      return parsed;
    } catch (e) {
      console.error("Error reading wp-config.json:", e);
    }
  }
  return {
    DB_TYPE: "mysql",
    DB_HOST: "localhost",
    DB_PORT: 3306,
    DB_USER: "wdamlpty_hesabdari-h-fahamand",
    DB_PASSWORD: "stsE*j70[m5FlSNY",
    DB_NAME: "wdamlpty_hesabdari-h.fahamand"
  };
}
var dbType = "mysql";
var mysqlPool = null;
var mysqlError = null;
function cleanHostBackupFolders() {
  const dirsToClean = [
    import_path.default.join(process.cwd(), "backup"),
    import_path.default.join(process.cwd(), "backups"),
    import_path.default.join(process.cwd(), "dist", "backup"),
    import_path.default.join(process.cwd(), "dist", "backups")
  ];
  for (const dir of dirsToClean) {
    if (import_fs.default.existsSync(dir)) {
      try {
        import_fs.default.rmSync(dir, { recursive: true, force: true });
        console.log(`[Storage System] Successfully removed backup directory: ${dir}`);
      } catch (err) {
        console.warn(`[Storage System] Notice: Could not remove backup dir ${dir}:`, err?.message);
      }
    }
  }
}
function cleanOldAssetBundles() {
  const blueprintAssetsDir = import_path.default.join(process.cwd(), "blueprint", "assets");
  const publicAssetsDir = import_path.default.join(process.cwd(), "public", "assets");
  const distAssetsDir = import_path.default.join(process.cwd(), "dist", "assets");
  if (!import_fs.default.existsSync(publicAssetsDir)) import_fs.default.mkdirSync(publicAssetsDir, { recursive: true });
  if (!import_fs.default.existsSync(distAssetsDir)) import_fs.default.mkdirSync(distAssetsDir, { recursive: true });
  const allAssetDirs = [publicAssetsDir, blueprintAssetsDir, distAssetsDir];
  for (const sDir of allAssetDirs) {
    if (import_fs.default.existsSync(sDir)) {
      try {
        const files = import_fs.default.readdirSync(sDir);
        for (const f of files) {
          const src = import_path.default.join(sDir, f);
          const pubDest = import_path.default.join(publicAssetsDir, f);
          const distDest = import_path.default.join(distAssetsDir, f);
          if (!import_fs.default.existsSync(pubDest)) try {
            import_fs.default.copyFileSync(src, pubDest);
          } catch (_) {
          }
          if (!import_fs.default.existsSync(distDest)) try {
            import_fs.default.copyFileSync(src, distDest);
          } catch (_) {
          }
        }
      } catch (_) {
      }
    }
  }
}
async function initDatabase() {
  cleanHostBackupFolders();
  const config = getAppConfig();
  dbType = "mysql";
  try {
    if (mysqlPool) {
      try {
        await mysqlPool.end();
      } catch (_) {
      }
      mysqlPool = null;
    }
    mysqlPool = import_promise.default.createPool({
      host: config.DB_HOST || "localhost",
      port: Number(config.DB_PORT) || 3306,
      user: config.DB_USER || "wdamlpty_hesabdari-h-fahamand",
      password: config.DB_PASSWORD || "stsE*j70[m5FlSNY",
      database: config.DB_NAME || "wdamlpty_hesabdari-h.fahamand",
      waitForConnections: true,
      connectionLimit: 15,
      queueLimit: 0,
      enableKeepAlive: true,
      keepAliveInitialDelay: 1e4,
      connectTimeout: 1e4,
      charset: "utf8mb4"
    });
    const connection = await mysqlPool.getConnection();
    console.log("Successfully connected to MySQL database!");
    try {
      await connection.query("SET NAMES utf8mb4");
      await connection.query("SET SESSION max_allowed_packet = 67108864");
    } catch (_) {
    }
    await runDatabaseMigrations(connection);
    connection.release();
    mysqlError = null;
    console.log("[Storage System] Connected to MySQL database. System operates solely via MySQL.");
  } catch (err) {
    console.error("MySQL connection failed. Error:", err.message);
    mysqlError = err.message;
  }
}
async function runDatabaseMigrations(connection) {
  const tableDefinitions = [
    // 1. JSON Storage (Kept intact for seamless compatibility)
    `CREATE TABLE IF NOT EXISTS app_state (
      state_key VARCHAR(100) PRIMARY KEY,
      state_value LONGTEXT,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 2. Users Table
    `CREATE TABLE IF NOT EXISTS users (
      id VARCHAR(100) NOT NULL,
      username VARCHAR(100) NOT NULL,
      name VARCHAR(255) NULL,
      role VARCHAR(50) DEFAULT 'seller',
      password VARCHAR(255) NULL,
      phone VARCHAR(50) NULL,
      permissions LONGTEXT NULL,
      is_active TINYINT(1) DEFAULT 1,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uk_users_username (username)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 3. Fiscal Years Table
    `CREATE TABLE IF NOT EXISTS fiscal_years (
      id VARCHAR(100) NOT NULL,
      year VARCHAR(50) NOT NULL,
      start_date VARCHAR(50) NULL,
      end_date VARCHAR(50) NULL,
      registered TINYINT(1) DEFAULT 0,
      is_closed TINYINT(1) DEFAULT 0,
      closed_at VARCHAR(50) NULL,
      closed_by VARCHAR(100) NULL,
      locked_date VARCHAR(50) NULL,
      setup_date VARCHAR(50) NULL,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_fiscal_year_year (year)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 4. Counterparts (طرف‌های حساب)
    `CREATE TABLE IF NOT EXISTS counterparts (
      id VARCHAR(100) NOT NULL,
      name VARCHAR(255) NOT NULL,
      phone VARCHAR(100) NULL,
      address TEXT NULL,
      type VARCHAR(50) DEFAULT 'both',
      acquaintance_method VARCHAR(255) NULL,
      communication_channel VARCHAR(255) NULL,
      shipping_method VARCHAR(255) NULL,
      custom_icons TEXT NULL,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_by_id VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_counterparts_name (name),
      KEY idx_counterparts_fiscal_year (fiscal_year_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 5. Categories (دسته‌بندی‌ها)
    `CREATE TABLE IF NOT EXISTS categories (
      id VARCHAR(100) NOT NULL,
      name VARCHAR(255) NOT NULL,
      parent_id VARCHAR(100) NULL,
      parent_name VARCHAR(255) NULL,
      type VARCHAR(50) DEFAULT 'transaction',
      subcategories LONGTEXT NULL,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_categories_name (name),
      KEY idx_categories_fiscal_year (fiscal_year_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 6. Warehouses (انبارها)
    `CREATE TABLE IF NOT EXISTS warehouses (
      id VARCHAR(100) NOT NULL,
      name VARCHAR(255) NOT NULL,
      code VARCHAR(100) NULL,
      location TEXT NULL,
      manager VARCHAR(255) NULL,
      phone VARCHAR(100) NULL,
      description TEXT NULL,
      is_active TINYINT(1) DEFAULT 1,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_warehouses_name (name),
      KEY idx_warehouses_fiscal_year (fiscal_year_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 7. Items (کالاها و خدمات)
    `CREATE TABLE IF NOT EXISTS items (
      id VARCHAR(100) NOT NULL,
      warehouse_id VARCHAR(100) NULL,
      name VARCHAR(255) NOT NULL,
      code VARCHAR(100) NULL,
      type VARCHAR(50) DEFAULT 'kala',
      color VARCHAR(100) NULL,
      unit VARCHAR(50) NULL,
      qty DECIMAL(15, 4) DEFAULT 0,
      initial_qty DECIMAL(15, 4) DEFAULT 0,
      last_purchase_price DECIMAL(20, 2) DEFAULT 0,
      last_sale_price DECIMAL(20, 2) DEFAULT 0,
      min_qty_alarm DECIMAL(15, 4) DEFAULT 0,
      category_name VARCHAR(255) NULL,
      parent_category VARCHAR(255) NULL,
      sub_category VARCHAR(255) NULL,
      commission_percent DECIMAL(8, 2) DEFAULT 0,
      setup_date VARCHAR(50) NULL,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_items_name (name),
      KEY idx_items_category (category_name),
      KEY idx_items_warehouse (warehouse_id),
      KEY idx_items_fiscal_year (fiscal_year_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 8. Accounts (حساب‌های بانکی و صندوق‌ها)
    `CREATE TABLE IF NOT EXISTS accounts (
      id VARCHAR(100) NOT NULL,
      name VARCHAR(255) NOT NULL,
      account_number VARCHAR(100) NULL,
      type VARCHAR(50) DEFAULT 'bank',
      balance DECIMAL(20, 2) DEFAULT 0,
      card_number VARCHAR(50) NULL,
      sheba_number VARCHAR(50) NULL,
      bank_name VARCHAR(100) NULL,
      branch VARCHAR(100) NULL,
      description TEXT NULL,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_accounts_name (name),
      KEY idx_accounts_fiscal_year (fiscal_year_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 9. Invoices (فاکتورها و پیش‌فاکتورها)
    `CREATE TABLE IF NOT EXISTS invoices (
      id VARCHAR(100) NOT NULL,
      invoice_number VARCHAR(100) NOT NULL,
      type VARCHAR(50) NOT NULL,
      date VARCHAR(50) NOT NULL,
      counterpart_id VARCHAR(100) NULL,
      counterpart_name VARCHAR(255) NULL,
      counterpart_phone VARCHAR(100) NULL,
      counterpart_address TEXT NULL,
      total_amount DECIMAL(20, 2) DEFAULT 0,
      tax DECIMAL(20, 2) DEFAULT 0,
      deposit DECIMAL(20, 2) DEFAULT 0,
      discount DECIMAL(20, 2) DEFAULT 0,
      payment_amount DECIMAL(20, 2) DEFAULT 0,
      payment_date VARCHAR(50) NULL,
      description TEXT NULL,
      is_proforma TINYINT(1) DEFAULT 0,
      is_urgent TINYINT(1) DEFAULT 0,
      urgent_type VARCHAR(50) NULL,
      shipping_method VARCHAR(255) NULL,
      acquaintance_method VARCHAR(255) NULL,
      doc_id VARCHAR(100) NULL,
      cogs_doc_id VARCHAR(100) NULL,
      cogs_total DECIMAL(20, 2) DEFAULT 0,
      is_return TINYINT(1) DEFAULT 0,
      return_ref_invoice_id VARCHAR(100) NULL,
      is_deleted TINYINT(1) DEFAULT 0,
      deleted_by VARCHAR(100) NULL,
      deleted_by_id VARCHAR(100) NULL,
      deleted_at VARCHAR(50) NULL,
      custom_icons TEXT NULL,
      attachments LONGTEXT NULL,
      payment_slips LONGTEXT NULL,
      history LONGTEXT NULL,
      allocations LONGTEXT NULL,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_by_id VARCHAR(100) NULL,
      created_by_phone VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_invoices_num (invoice_number),
      KEY idx_invoices_date (date),
      KEY idx_invoices_counterpart (counterpart_id),
      KEY idx_invoices_fiscal_year (fiscal_year_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 10. Invoice Items (اقلام فاکتورها)
    `CREATE TABLE IF NOT EXISTS invoice_items (
      id VARCHAR(100) NOT NULL,
      invoice_id VARCHAR(100) NOT NULL,
      item_id VARCHAR(100) NULL,
      name VARCHAR(255) NOT NULL,
      type VARCHAR(50) DEFAULT 'kala',
      color VARCHAR(100) NULL,
      unit VARCHAR(50) NULL,
      qty DECIMAL(15, 4) DEFAULT 1,
      unit_price DECIMAL(20, 2) DEFAULT 0,
      total_price DECIMAL(20, 2) DEFAULT 0,
      cogs_unit_cost DECIMAL(20, 2) DEFAULT 0,
      cogs_total DECIMAL(20, 2) DEFAULT 0,
      remarks TEXT NULL,
      sort_order INT DEFAULT 0,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_invoice_items_invoice (invoice_id),
      KEY idx_invoice_items_item (item_id),
      KEY idx_invoice_items_fiscal_year (fiscal_year_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 11. Transactions (تراکنش‌های بانکی و مالی)
    `CREATE TABLE IF NOT EXISTS transactions (
      id VARCHAR(100) NOT NULL,
      date VARCHAR(50) NOT NULL,
      time VARCHAR(50) NULL,
      amount DECIMAL(20, 2) NOT NULL DEFAULT 0,
      type VARCHAR(50) NOT NULL,
      description TEXT NULL,
      is_registered TINYINT(1) DEFAULT 0,
      category_parent VARCHAR(255) NULL,
      category_child VARCHAR(255) NULL,
      user_description TEXT NULL,
      is_duplicate TINYINT(1) DEFAULT 0,
      duplicate_reason TEXT NULL,
      tracking_number VARCHAR(100) NULL,
      reference_code VARCHAR(100) NULL,
      registered_date VARCHAR(50) NULL,
      account_id VARCHAR(100) NULL,
      partner_id VARCHAR(100) NULL,
      pending_deposit_id VARCHAR(100) NULL,
      borrower_id VARCHAR(100) NULL,
      borrower_name VARCHAR(255) NULL,
      loan_type VARCHAR(50) NULL,
      counterpart_id VARCHAR(100) NULL,
      counterpart_name VARCHAR(255) NULL,
      invoice_id VARCHAR(100) NULL,
      doc_id VARCHAR(100) NULL,
      attachments LONGTEXT NULL,
      is_edited TINYINT(1) DEFAULT 0,
      edited_by VARCHAR(100) NULL,
      edited_by_id VARCHAR(100) NULL,
      edited_at VARCHAR(50) NULL,
      edit_history LONGTEXT NULL,
      is_deleted TINYINT(1) DEFAULT 0,
      deleted_by VARCHAR(100) NULL,
      deleted_by_id VARCHAR(100) NULL,
      deleted_at VARCHAR(50) NULL,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_by_id VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_transactions_date (date),
      KEY idx_transactions_account (account_id),
      KEY idx_transactions_counterpart (counterpart_id),
      KEY idx_transactions_fiscal_year (fiscal_year_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 12. Accounting Docs (اسناد حسابداری)
    `CREATE TABLE IF NOT EXISTS accounting_docs (
      id VARCHAR(100) NOT NULL,
      doc_number INT NOT NULL,
      date VARCHAR(50) NOT NULL,
      description TEXT NULL,
      is_archived TINYINT(1) DEFAULT 0,
      is_manual TINYINT(1) DEFAULT 0,
      status VARCHAR(50) DEFAULT 'posted',
      operation_type VARCHAR(100) NULL,
      invoice_id VARCHAR(100) NULL,
      tx_id VARCHAR(100) NULL,
      ref_doc_id VARCHAR(100) NULL,
      idempotency_key VARCHAR(255) NULL,
      actor_id VARCHAR(100) NULL,
      actor_name VARCHAR(255) NULL,
      is_deleted TINYINT(1) DEFAULT 0,
      deleted_by VARCHAR(100) NULL,
      deleted_by_id VARCHAR(100) NULL,
      deleted_at VARCHAR(50) NULL,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_accounting_docs_num (doc_number),
      KEY idx_accounting_docs_date (date),
      KEY idx_accounting_docs_fiscal_year (fiscal_year_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 13. Accounting Doc Lines (سطرهای سند حسابداری)
    `CREATE TABLE IF NOT EXISTS accounting_doc_lines (
      id VARCHAR(100) NOT NULL,
      doc_id VARCHAR(100) NOT NULL,
      account_id VARCHAR(100) NULL,
      account_name VARCHAR(255) NULL,
      debit DECIMAL(20, 2) DEFAULT 0,
      credit DECIMAL(20, 2) DEFAULT 0,
      description TEXT NULL,
      line_index INT DEFAULT 0,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_doc_lines_doc (doc_id),
      KEY idx_doc_lines_account (account_id),
      KEY idx_doc_lines_fiscal_year (fiscal_year_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 14. Logs (لاگ‌های سیستم و ممیزی)
    `CREATE TABLE IF NOT EXISTS logs (
      id VARCHAR(100) NOT NULL,
      timestamp VARCHAR(100) NULL,
      timestamp_ms BIGINT NULL,
      level VARCHAR(50) DEFAULT 'info',
      category VARCHAR(100) NULL,
      message TEXT NULL,
      action VARCHAR(100) NULL,
      storage_location VARCHAR(100) NULL,
      target_type VARCHAR(100) NULL,
      target_id VARCHAR(100) NULL,
      target_number VARCHAR(100) NULL,
      amount DECIMAL(20, 2) DEFAULT 0,
      user_id VARCHAR(100) NULL,
      user_name VARCHAR(255) NULL,
      user_role VARCHAR(100) NULL,
      ip_address VARCHAR(100) NULL,
      details LONGTEXT NULL,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_logs_timestamp (timestamp_ms),
      KEY idx_logs_category (category),
      KEY idx_logs_fiscal_year (fiscal_year_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 15. Notifications (اعلان‌ها)
    `CREATE TABLE IF NOT EXISTS notifications (
      id VARCHAR(100) NOT NULL,
      user_id VARCHAR(100) NOT NULL,
      title VARCHAR(255) NOT NULL,
      message TEXT NULL,
      type VARCHAR(50) DEFAULT 'info',
      timestamp VARCHAR(100) NULL,
      is_read TINYINT(1) DEFAULT 0,
      sender_id VARCHAR(100) NULL,
      sender_name VARCHAR(255) NULL,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_notifications_user (user_id),
      KEY idx_notifications_fiscal_year (fiscal_year_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 16. Checklist (چک‌لیست)
    `CREATE TABLE IF NOT EXISTS checklist (
      id VARCHAR(100) NOT NULL,
      task TEXT NOT NULL,
      is_completed TINYINT(1) DEFAULT 0,
      is_public TINYINT(1) DEFAULT 0,
      completed_at BIGINT NULL,
      date VARCHAR(50) NULL,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_checklist_fiscal_year (fiscal_year_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 17. Settings (تنظیمات)
    `CREATE TABLE IF NOT EXISTS settings (
      id VARCHAR(100) NOT NULL,
      setting_key VARCHAR(100) NOT NULL,
      setting_value LONGTEXT NULL,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uk_settings_key (setting_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 18. Uploads (بارگذاری‌ها و پیوست‌ها)
    `CREATE TABLE IF NOT EXISTS uploads (
      id VARCHAR(100) NOT NULL,
      file_name VARCHAR(255) NOT NULL,
      original_name VARCHAR(255) NULL,
      file_path TEXT NULL,
      file_size BIGINT NULL,
      mime_type VARCHAR(100) NULL,
      entity_type VARCHAR(100) NULL,
      entity_id VARCHAR(100) NULL,
      data_url LONGTEXT NULL,
      fiscal_year_id VARCHAR(100) NULL,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_uploads_entity (entity_type, entity_id),
      KEY idx_uploads_fiscal_year (fiscal_year_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`,
    // 19. Settings Store (تنظیمات سیستمی و پیام‌رسان‌ها)
    `CREATE TABLE IF NOT EXISTS settings_store (
      setting_key VARCHAR(100) NOT NULL PRIMARY KEY,
      setting_value LONGTEXT NULL,
      created_by VARCHAR(100) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`
  ];
  const tableNames = [
    "app_state",
    "users",
    "fiscal_years",
    "counterparts",
    "categories",
    "warehouses",
    "items",
    "accounts",
    "invoices",
    "invoice_items",
    "transactions",
    "accounting_docs",
    "accounting_doc_lines",
    "logs",
    "notifications",
    "checklist",
    "settings",
    "uploads"
  ];
  try {
    for (const sql of tableDefinitions) {
      await connection.query(sql);
    }
    try {
      await connection.query("ALTER TABLE app_state MODIFY COLUMN state_value LONGTEXT;");
    } catch (_) {
    }
    console.log(`[Database Migration] Successfully verified/created all ${tableNames.length} InnoDB utf8mb4 tables.`);
    return { success: true, tables: tableNames };
  } catch (err) {
    console.error("[Database Migration] Migration execution error:", err.message);
    return { success: false, tables: tableNames, error: err.message };
  }
}
async function migrateAppStateDataToRelationalTables(connection) {
  const startTime = Date.now();
  const startedAt = (/* @__PURE__ */ new Date()).toISOString();
  const reports = [];
  let totalSourceRecords = 0;
  let totalDestinationRecords = 0;
  await runDatabaseMigrations(connection);
  const nowStamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[-:T.]/g, "").slice(0, 14);
  const backupTableName = `app_state_backup_${nowStamp}`;
  const backupResult = {
    created: false
  };
  try {
    await connection.query(`CREATE TABLE IF NOT EXISTS ${backupTableName} AS SELECT * FROM app_state;`);
    backupResult.backupTable = backupTableName;
    await connection.query(`CREATE TABLE IF NOT EXISTS app_state_backups (
      id INT AUTO_INCREMENT PRIMARY KEY,
      backup_table_name VARCHAR(100) NOT NULL,
      notes VARCHAR(255) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`);
    await connection.query(`INSERT INTO app_state_backups (backup_table_name, notes) VALUES (?, ?)`, [
      backupTableName,
      `Pre-migration automated snapshot at ${startedAt}`
    ]);
    try {
      const [allRows] = await connection.query("SELECT state_key, state_value FROM app_state");
      const backupDir = import_path.default.join(process.cwd(), "data", "backups");
      if (!import_fs.default.existsSync(backupDir)) {
        import_fs.default.mkdirSync(backupDir, { recursive: true });
      }
      const backupFilePath = import_path.default.join(backupDir, `app_state_backup_${nowStamp}.json`);
      import_fs.default.writeFileSync(backupFilePath, JSON.stringify(allRows, null, 2), "utf8");
      backupResult.backupFile = backupFilePath;
    } catch (fErr) {
      console.warn("[Migration Backup] Disk backup notice:", fErr.message);
    }
    backupResult.created = true;
    console.log(`[Migration Backup] Successfully created pre-migration backup table: ${backupTableName}`);
  } catch (bErr) {
    backupResult.error = bErr.message;
    console.error("[Migration Backup] Error creating backup:", bErr.message);
  }
  const stateData = {};
  try {
    const [rows] = await connection.query("SELECT state_key, state_value FROM app_state");
    if (Array.isArray(rows)) {
      for (const row of rows) {
        const val = safeUnwrapJson(row.state_value);
        const cleanKey = row.state_key.replace(/^acc_app_/, "");
        stateData[cleanKey] = val;
        stateData[`acc_app_${cleanKey}`] = val;
      }
    }
  } catch (err) {
    return {
      success: false,
      backup: backupResult,
      totalSourceRecords: 0,
      totalDestinationRecords: 0,
      reports,
      startedAt,
      completedAt: (/* @__PURE__ */ new Date()).toISOString(),
      durationMs: Date.now() - startTime,
      error: `\u062E\u0637\u0627 \u062F\u0631 \u062E\u0648\u0627\u0646\u062F\u0646 \u062F\u0627\u062F\u0647\u200C\u0647\u0627\u06CC app_state: ${err.message}`
    };
  }
  const getArray = (key) => {
    const val = stateData[key] || stateData[`acc_app_${key}`];
    return Array.isArray(val) ? val : [];
  };
  const getObjectOrArray = (key) => {
    return stateData[key] || stateData[`acc_app_${key}`] || null;
  };
  const usersList = getArray("users");
  let usersSourceCount = usersList.length;
  totalSourceRecords += usersSourceCount;
  try {
    await connection.beginTransaction();
    for (const u of usersList) {
      const id = String(u.id || (u.username ? `user_${u.username}` : `user_${Math.random().toString(36).substring(2, 9)}`));
      const username = String(u.username || id);
      const name = u.name || null;
      const role = u.role || "seller";
      const password = u.password || null;
      const phone = u.phone || null;
      const permissions = u.permissions ? JSON.stringify(u.permissions) : JSON.stringify([]);
      const isActive = u.isActive !== false ? 1 : 0;
      const createdBy = u.createdBy || null;
      await connection.query(
        `INSERT INTO users (id, username, name, role, password, phone, permissions, is_active, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           name = VALUES(name),
           role = VALUES(role),
           password = VALUES(password),
           phone = VALUES(phone),
           permissions = VALUES(permissions),
           is_active = VALUES(is_active),
           updated_at = CURRENT_TIMESTAMP`,
        [id, username, name, role, password, phone, permissions, isActive, createdBy]
      );
    }
    await connection.commit();
    const [c] = await connection.query("SELECT COUNT(*) as cnt FROM users");
    const dest = Number(c[0]?.cnt || 0);
    totalDestinationRecords += dest;
    reports.push({
      table: "users",
      sourceCount: usersSourceCount,
      destinationCount: dest,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${usersSourceCount} \u06A9\u0627\u0631\u0628\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "users",
      sourceCount: usersSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u06A9\u0627\u0631\u0628\u0631\u0627\u0646 (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const fiscalYearsList = getArray("fiscalYears").length > 0 ? getArray("fiscalYears") : getArray("fiscal_years");
  let fySourceCount = fiscalYearsList.length;
  totalSourceRecords += fySourceCount;
  try {
    await connection.beginTransaction();
    for (const fy of fiscalYearsList) {
      const id = String(fy.id || (fy.year ? `fy_${fy.year}` : `fy_${Math.random().toString(36).substring(2, 9)}`));
      const year = String(fy.year || "");
      const startDate = fy.startDate || null;
      const endDate = fy.endDate || null;
      const registered = fy.registered ? 1 : 0;
      const isClosed = fy.isClosed ? 1 : 0;
      const closedAt = fy.closedAt || null;
      const closedBy = fy.closedBy || null;
      const lockedDate = fy.lockedDate || null;
      const setupDate = fy.setupDate || null;
      const createdBy = fy.createdBy || null;
      await connection.query(
        `INSERT INTO fiscal_years (id, year, start_date, end_date, registered, is_closed, closed_at, closed_by, locked_date, setup_date, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           year = VALUES(year),
           start_date = VALUES(start_date),
           end_date = VALUES(end_date),
           registered = VALUES(registered),
           is_closed = VALUES(is_closed),
           closed_at = VALUES(closed_at),
           closed_by = VALUES(closed_by),
           locked_date = VALUES(locked_date),
           setup_date = VALUES(setup_date),
           updated_at = CURRENT_TIMESTAMP`,
        [id, year, startDate, endDate, registered, isClosed, closedAt, closedBy, lockedDate, setupDate, createdBy]
      );
    }
    await connection.commit();
    const [c] = await connection.query("SELECT COUNT(*) as cnt FROM fiscal_years");
    const dest = Number(c[0]?.cnt || 0);
    totalDestinationRecords += dest;
    reports.push({
      table: "fiscal_years",
      sourceCount: fySourceCount,
      destinationCount: dest,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${fySourceCount} \u0633\u0627\u0644 \u0645\u0627\u0644\u06CC \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "fiscal_years",
      sourceCount: fySourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u0633\u0627\u0644\u200C\u0647\u0627\u06CC \u0645\u0627\u0644\u06CC (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const counterpartsList = getArray("counterparts");
  let cpSourceCount = counterpartsList.length;
  totalSourceRecords += cpSourceCount;
  try {
    await connection.beginTransaction();
    for (const cp of counterpartsList) {
      const id = String(cp.id || `cp_${Math.random().toString(36).substring(2, 9)}`);
      const name = String(cp.name || "\u0637\u0631\u0641 \u062D\u0633\u0627\u0628");
      const phone = cp.phone || null;
      const address = cp.address || null;
      const type = cp.type || "both";
      const acquaintanceMethod = cp.acquaintanceMethod || null;
      const communicationChannel = cp.communicationChannel || null;
      const shippingMethod = cp.shippingMethod || null;
      const customIcons = cp.customIcons ? JSON.stringify(cp.customIcons) : null;
      const fiscalYearId = cp.fiscalYearId || null;
      const createdBy = cp.createdBy || null;
      const createdById = cp.createdById || null;
      await connection.query(
        `INSERT INTO counterparts (id, name, phone, address, type, acquaintance_method, communication_channel, shipping_method, custom_icons, fiscal_year_id, created_by, created_by_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           name = VALUES(name),
           phone = VALUES(phone),
           address = VALUES(address),
           type = VALUES(type),
           acquaintance_method = VALUES(acquaintance_method),
           communication_channel = VALUES(communication_channel),
           shipping_method = VALUES(shipping_method),
           custom_icons = VALUES(custom_icons),
           fiscal_year_id = VALUES(fiscal_year_id),
           updated_at = CURRENT_TIMESTAMP`,
        [id, name, phone, address, type, acquaintanceMethod, communicationChannel, shippingMethod, customIcons, fiscalYearId, createdBy, createdById]
      );
    }
    await connection.commit();
    const [c] = await connection.query("SELECT COUNT(*) as cnt FROM counterparts");
    const dest = Number(c[0]?.cnt || 0);
    totalDestinationRecords += dest;
    reports.push({
      table: "counterparts",
      sourceCount: cpSourceCount,
      destinationCount: dest,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${cpSourceCount} \u0637\u0631\u0641 \u062D\u0633\u0627\u0628 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "counterparts",
      sourceCount: cpSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u0637\u0631\u0641\u200C\u0647\u0627\u06CC \u062D\u0633\u0627\u0628 (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const categoriesList = [...getArray("categories"), ...getArray("warehouse_categories_list")];
  const uniqueCatsMap = /* @__PURE__ */ new Map();
  for (const cat of categoriesList) {
    const key = cat.id || cat.name;
    if (key && !uniqueCatsMap.has(key)) {
      uniqueCatsMap.set(key, cat);
    }
  }
  const uniqueCats = Array.from(uniqueCatsMap.values());
  let catSourceCount = uniqueCats.length;
  totalSourceRecords += catSourceCount;
  try {
    await connection.beginTransaction();
    for (const cat of uniqueCats) {
      const id = String(cat.id || `cat_${Math.random().toString(36).substring(2, 9)}`);
      const name = String(cat.name || "\u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC");
      const parentId = cat.parentId || null;
      const parentName = cat.parentName || null;
      const type = cat.type || "transaction";
      const subcategories = cat.subcategories ? JSON.stringify(cat.subcategories) : cat.subCategories ? JSON.stringify(cat.subCategories) : null;
      const fiscalYearId = cat.fiscalYearId || null;
      const createdBy = cat.createdBy || null;
      await connection.query(
        `INSERT INTO categories (id, name, parent_id, parent_name, type, subcategories, fiscal_year_id, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           name = VALUES(name),
           parent_id = VALUES(parent_id),
           parent_name = VALUES(parent_name),
           type = VALUES(type),
           subcategories = VALUES(subcategories),
           fiscal_year_id = VALUES(fiscal_year_id),
           updated_at = CURRENT_TIMESTAMP`,
        [id, name, parentId, parentName, type, subcategories, fiscalYearId, createdBy]
      );
    }
    await connection.commit();
    const [c] = await connection.query("SELECT COUNT(*) as cnt FROM categories");
    const dest = Number(c[0]?.cnt || 0);
    totalDestinationRecords += dest;
    reports.push({
      table: "categories",
      sourceCount: catSourceCount,
      destinationCount: dest,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${catSourceCount} \u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "categories",
      sourceCount: catSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC\u200C\u0647\u0627 (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const warehousesList = getArray("warehouses");
  let whSourceCount = warehousesList.length;
  totalSourceRecords += whSourceCount;
  try {
    await connection.beginTransaction();
    for (const wh of warehousesList) {
      const id = String(wh.id || `wh_${Math.random().toString(36).substring(2, 9)}`);
      const name = String(wh.name || "\u0627\u0646\u0628\u0627\u0631 \u0627\u0635\u0644\u06CC");
      const code = wh.code || null;
      const location = wh.location || null;
      const manager = wh.manager || null;
      const phone = wh.phone || null;
      const description = wh.description || null;
      const isActive = wh.isActive !== false ? 1 : 0;
      const fiscalYearId = wh.fiscalYearId || null;
      const createdBy = wh.createdBy || null;
      await connection.query(
        `INSERT INTO warehouses (id, name, code, location, manager, phone, description, is_active, fiscal_year_id, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           name = VALUES(name),
           code = VALUES(code),
           location = VALUES(location),
           manager = VALUES(manager),
           phone = VALUES(phone),
           description = VALUES(description),
           is_active = VALUES(is_active),
           fiscal_year_id = VALUES(fiscal_year_id),
           updated_at = CURRENT_TIMESTAMP`,
        [id, name, code, location, manager, phone, description, isActive, fiscalYearId, createdBy]
      );
    }
    await connection.commit();
    const [c] = await connection.query("SELECT COUNT(*) as cnt FROM warehouses");
    const dest = Number(c[0]?.cnt || 0);
    totalDestinationRecords += dest;
    reports.push({
      table: "warehouses",
      sourceCount: whSourceCount,
      destinationCount: dest,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${whSourceCount} \u0627\u0646\u0628\u0627\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "warehouses",
      sourceCount: whSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u0627\u0646\u0628\u0627\u0631\u0647\u0627 (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const itemsList = getArray("items");
  let itemsSourceCount = itemsList.length;
  totalSourceRecords += itemsSourceCount;
  try {
    await connection.beginTransaction();
    for (const it of itemsList) {
      const id = String(it.id || `item_${Math.random().toString(36).substring(2, 9)}`);
      const warehouseId = it.warehouseId || null;
      const name = String(it.name || "\u06A9\u0627\u0644\u0627");
      const code = it.code || null;
      const type = it.type || "kala";
      const color = it.color || null;
      const unit = it.unit || null;
      const qty = Number(it.qty) || 0;
      const initialQty = Number(it.initialQty) || 0;
      const lastPurchasePrice = Number(it.lastPurchasePrice) || 0;
      const lastSalePrice = Number(it.lastSalePrice) || 0;
      const minQtyAlarm = Number(it.minQtyAlarm) || 0;
      const categoryName = it.categoryName || it.category || null;
      const parentCategory = it.parentCategory || null;
      const subCategory = it.subCategory || null;
      const commissionPercent = Number(it.commissionPercent) || 0;
      const setupDate = it.setupDate || null;
      const fiscalYearId = it.fiscalYearId || null;
      const createdBy = it.createdBy || null;
      await connection.query(
        `INSERT INTO items (
           id, warehouse_id, name, code, type, color, unit, qty, initial_qty,
           last_purchase_price, last_sale_price, min_qty_alarm, category_name,
           parent_category, sub_category, commission_percent, setup_date, fiscal_year_id, created_by
         )
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           name = VALUES(name),
           code = VALUES(code),
           type = VALUES(type),
           color = VALUES(color),
           unit = VALUES(unit),
           qty = qty + (VALUES(initial_qty) - initial_qty),
           initial_qty = VALUES(initial_qty),
           last_purchase_price = VALUES(last_purchase_price),
           last_sale_price = VALUES(last_sale_price),
           min_qty_alarm = VALUES(min_qty_alarm),
           category_name = VALUES(category_name),
           parent_category = VALUES(parent_category),
           sub_category = VALUES(sub_category),
           commission_percent = VALUES(commission_percent),
           setup_date = VALUES(setup_date),
           fiscal_year_id = VALUES(fiscal_year_id),
           updated_at = CURRENT_TIMESTAMP`,
        [
          id,
          warehouseId,
          name,
          code,
          type,
          color,
          unit,
          qty,
          initialQty,
          lastPurchasePrice,
          lastSalePrice,
          minQtyAlarm,
          categoryName,
          parentCategory,
          subCategory,
          commissionPercent,
          setupDate,
          fiscalYearId,
          createdBy
        ]
      );
    }
    await connection.commit();
    const [c] = await connection.query("SELECT COUNT(*) as cnt FROM items");
    const dest = Number(c[0]?.cnt || 0);
    totalDestinationRecords += dest;
    reports.push({
      table: "items",
      sourceCount: itemsSourceCount,
      destinationCount: dest,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${itemsSourceCount} \u06A9\u0627\u0644\u0627 \u0648 \u062E\u062F\u0645\u0627\u062A \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "items",
      sourceCount: itemsSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u06A9\u0627\u0644\u0627\u0647\u0627 (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const accountsList = getArray("accounts");
  let accountsSourceCount = accountsList.length;
  totalSourceRecords += accountsSourceCount;
  try {
    await connection.beginTransaction();
    for (const acc of accountsList) {
      const id = String(acc.id || `acc_${Math.random().toString(36).substring(2, 9)}`);
      const name = String(acc.name || "\u062D\u0633\u0627\u0628");
      const accountNumber = acc.accountNumber || null;
      const type = acc.type || "bank";
      const balance = Number(acc.balance) || 0;
      const cardNumber = acc.cardNumber || null;
      const shebaNumber = acc.shebaNumber || null;
      const bankName = acc.bankName || null;
      const branch = acc.branch || null;
      const description = acc.description || null;
      const fiscalYearId = acc.fiscalYearId || null;
      const createdBy = acc.createdBy || null;
      await connection.query(
        `INSERT INTO accounts (id, name, account_number, type, balance, card_number, sheba_number, bank_name, branch, description, fiscal_year_id, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           name = VALUES(name),
           account_number = VALUES(account_number),
           type = VALUES(type),
           balance = VALUES(balance),
           card_number = VALUES(card_number),
           sheba_number = VALUES(sheba_number),
           bank_name = VALUES(bank_name),
           branch = VALUES(branch),
           description = VALUES(description),
           fiscal_year_id = VALUES(fiscal_year_id),
           updated_at = CURRENT_TIMESTAMP`,
        [id, name, accountNumber, type, balance, cardNumber, shebaNumber, bankName, branch, description, fiscalYearId, createdBy]
      );
    }
    await connection.commit();
    const [c] = await connection.query("SELECT COUNT(*) as cnt FROM accounts");
    const dest = Number(c[0]?.cnt || 0);
    totalDestinationRecords += dest;
    reports.push({
      table: "accounts",
      sourceCount: accountsSourceCount,
      destinationCount: dest,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${accountsSourceCount} \u062D\u0633\u0627\u0628 \u0628\u0627\u0646\u06A9\u06CC \u0648 \u0635\u0646\u062F\u0648\u0642 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "accounts",
      sourceCount: accountsSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u062D\u0633\u0627\u0628\u200C\u0647\u0627 (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const invoicesList = getArray("invoices");
  let invoicesSourceCount = invoicesList.length;
  let invoiceItemsTotalSourceCount = 0;
  totalSourceRecords += invoicesSourceCount;
  try {
    await connection.beginTransaction();
    for (const inv of invoicesList) {
      const id = String(inv.id || `inv_${inv.invoiceNumber || Math.random().toString(36).substring(2, 9)}`);
      const invoiceNumber = String(inv.invoiceNumber || inv.id || "");
      const type = inv.type || "sale";
      const date = String(inv.date || "");
      const counterpartId = inv.counterpartId || null;
      const counterpartName = inv.counterpartName || null;
      const counterpartPhone = inv.counterpartPhone || null;
      const counterpartAddress = inv.counterpartAddress || null;
      const totalAmount = Number(inv.totalAmount) || 0;
      const tax = Number(inv.tax) || 0;
      const deposit = Number(inv.deposit) || 0;
      const discount = Number(inv.discount) || 0;
      const paymentAmount = Number(inv.paymentAmount) || 0;
      const paymentDate = inv.paymentDate || null;
      const description = inv.description || null;
      const isProforma = inv.isProforma ? 1 : 0;
      const isUrgent = inv.isUrgent ? 1 : 0;
      const urgentType = inv.urgentType || null;
      const shippingMethod = inv.shippingMethod || null;
      const acquaintanceMethod = inv.acquaintanceMethod || null;
      const docId = inv.docId || null;
      const cogsDocId = inv.cogsDocId || null;
      const cogsTotal = Number(inv.cogsTotal) || 0;
      const isReturn = inv.isReturn ? 1 : 0;
      const returnRefInvoiceId = inv.returnRefInvoiceId || null;
      const isDeleted = inv.isDeleted ? 1 : 0;
      const deletedBy = inv.deletedBy || null;
      const deletedById = inv.deletedById || null;
      const deletedAt = inv.deletedAt || null;
      const customIcons = inv.customIcons ? JSON.stringify(inv.customIcons) : null;
      const attachments = inv.attachments ? JSON.stringify(inv.attachments) : null;
      const paymentSlips = inv.paymentSlips ? JSON.stringify(inv.paymentSlips) : null;
      const history = inv.history ? JSON.stringify(inv.history) : null;
      const allocations = inv.allocations ? JSON.stringify(inv.allocations) : null;
      const fiscalYearId = inv.fiscalYearId || null;
      const createdBy = inv.createdBy || null;
      const createdById = inv.createdById || null;
      const createdByPhone = inv.createdByPhone || null;
      await connection.query(
        `INSERT INTO invoices (
           id, invoice_number, type, date, counterpart_id, counterpart_name, counterpart_phone,
           counterpart_address, total_amount, tax, deposit, discount, payment_amount, payment_date,
           description, is_proforma, is_urgent, urgent_type, shipping_method, acquaintance_method,
           doc_id, cogs_doc_id, cogs_total, is_return, return_ref_invoice_id, is_deleted,
           deleted_by, deleted_by_id, deleted_at, custom_icons, attachments, payment_slips,
           history, allocations, fiscal_year_id, created_by, created_by_id, created_by_phone
         )
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           invoice_number = VALUES(invoice_number),
           type = VALUES(type),
           date = VALUES(date),
           counterpart_id = VALUES(counterpart_id),
           counterpart_name = VALUES(counterpart_name),
           counterpart_phone = VALUES(counterpart_phone),
           counterpart_address = VALUES(counterpart_address),
           total_amount = VALUES(total_amount),
           tax = VALUES(tax),
           deposit = VALUES(deposit),
           discount = VALUES(discount),
           payment_amount = VALUES(payment_amount),
           payment_date = VALUES(payment_date),
           description = VALUES(description),
           is_proforma = VALUES(is_proforma),
           is_urgent = VALUES(is_urgent),
           urgent_type = VALUES(urgent_type),
           shipping_method = VALUES(shipping_method),
           acquaintance_method = VALUES(acquaintance_method),
           doc_id = VALUES(doc_id),
           cogs_doc_id = VALUES(cogs_doc_id),
           cogs_total = VALUES(cogs_total),
           is_return = VALUES(is_return),
           return_ref_invoice_id = VALUES(return_ref_invoice_id),
           is_deleted = VALUES(is_deleted),
           deleted_by = VALUES(deleted_by),
           deleted_by_id = VALUES(deleted_by_id),
           deleted_at = VALUES(deleted_at),
           custom_icons = VALUES(custom_icons),
           attachments = VALUES(attachments),
           payment_slips = VALUES(payment_slips),
           history = VALUES(history),
           allocations = VALUES(allocations),
           fiscal_year_id = VALUES(fiscal_year_id),
           updated_at = CURRENT_TIMESTAMP`,
        [
          id,
          invoiceNumber,
          type,
          date,
          counterpartId,
          counterpartName,
          counterpartPhone,
          counterpartAddress,
          totalAmount,
          tax,
          deposit,
          discount,
          paymentAmount,
          paymentDate,
          description,
          isProforma,
          isUrgent,
          urgentType,
          shippingMethod,
          acquaintanceMethod,
          docId,
          cogsDocId,
          cogsTotal,
          isReturn,
          returnRefInvoiceId,
          isDeleted,
          deletedBy,
          deletedById,
          deletedAt,
          customIcons,
          attachments,
          paymentSlips,
          history,
          allocations,
          fiscalYearId,
          createdBy,
          createdById,
          createdByPhone
        ]
      );
      const itemsArr = Array.isArray(inv.items) ? inv.items : [];
      invoiceItemsTotalSourceCount += itemsArr.length;
      for (let idx = 0; idx < itemsArr.length; idx++) {
        const item = itemsArr[idx];
        const itemIdPk = String(item.id || `${id}_item_${idx + 1}`);
        const refItemId = item.itemId || null;
        const itemName = String(item.name || "\u0631\u062F\u06CC\u0641 \u0641\u0627\u06A9\u062A\u0648\u0631");
        const itemType = item.type || "kala";
        const itemColor = item.color || null;
        const itemUnit = item.unit || null;
        const itemQty = Number(item.qty) || 1;
        const itemUnitPrice = Number(item.unitPrice) || 0;
        const itemTotalPrice = Number(item.totalPrice) || itemQty * itemUnitPrice;
        const itemCogsUnit = Number(item.cogsUnitCost) || 0;
        const itemCogsTotal = Number(item.cogsTotal) || itemQty * itemCogsUnit;
        const itemRemarks = item.remarks || null;
        await connection.query(
          `INSERT INTO invoice_items (
             id, invoice_id, item_id, name, type, color, unit, qty, unit_price,
             total_price, cogs_unit_cost, cogs_total, remarks, sort_order, fiscal_year_id, created_by
           )
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
             name = VALUES(name),
             type = VALUES(type),
             color = VALUES(color),
             unit = VALUES(unit),
             qty = VALUES(qty),
             unit_price = VALUES(unit_price),
             total_price = VALUES(total_price),
             cogs_unit_cost = VALUES(cogs_unit_cost),
             cogs_total = VALUES(cogs_total),
             remarks = VALUES(remarks),
             sort_order = VALUES(sort_order),
             fiscal_year_id = VALUES(fiscal_year_id),
             updated_at = CURRENT_TIMESTAMP`,
          [
            itemIdPk,
            id,
            refItemId,
            itemName,
            itemType,
            itemColor,
            itemUnit,
            itemQty,
            itemUnitPrice,
            itemTotalPrice,
            itemCogsUnit,
            itemCogsTotal,
            itemRemarks,
            idx,
            fiscalYearId,
            createdBy
          ]
        );
      }
    }
    await connection.commit();
    const [cInv] = await connection.query("SELECT COUNT(*) as cnt FROM invoices");
    const destInv = Number(cInv[0]?.cnt || 0);
    totalDestinationRecords += destInv;
    reports.push({
      table: "invoices",
      sourceCount: invoicesSourceCount,
      destinationCount: destInv,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${invoicesSourceCount} \u0641\u0627\u06A9\u062A\u0648\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
    const [cItems] = await connection.query("SELECT COUNT(*) as cnt FROM invoice_items");
    const destItems = Number(cItems[0]?.cnt || 0);
    totalDestinationRecords += destItems;
    totalSourceRecords += invoiceItemsTotalSourceCount;
    reports.push({
      table: "invoice_items",
      sourceCount: invoiceItemsTotalSourceCount,
      destinationCount: destItems,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${invoiceItemsTotalSourceCount} \u0631\u062F\u06CC\u0641 \u0641\u0627\u06A9\u062A\u0648\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "invoices",
      sourceCount: invoicesSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u0641\u0627\u06A9\u062A\u0648\u0631\u0647\u0627 (Rollback \u0634\u062F): ${err.message}`
    });
    reports.push({
      table: "invoice_items",
      sourceCount: invoiceItemsTotalSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u0631\u062F\u06CC\u0641\u200C\u0647\u0627\u06CC \u0641\u0627\u06A9\u062A\u0648\u0631 (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const transactionsList = getArray("transactions");
  let txSourceCount = transactionsList.length;
  totalSourceRecords += txSourceCount;
  try {
    await connection.beginTransaction();
    for (const tx of transactionsList) {
      const id = String(tx.id || `tx_${Math.random().toString(36).substring(2, 9)}`);
      const date = String(tx.date || "");
      const time = tx.time || null;
      const amount = Number(tx.amount) || 0;
      const type = tx.type || "deposit";
      const description = tx.description || null;
      const isRegistered = tx.isRegistered ? 1 : 0;
      const categoryParent = tx.categoryParent || null;
      const categoryChild = tx.categoryChild || null;
      const userDescription = tx.userDescription || null;
      const isDuplicate = tx.isDuplicate ? 1 : 0;
      const duplicateReason = tx.duplicateReason || null;
      const trackingNumber = tx.trackingNumber || null;
      const referenceCode = tx.referenceCode || null;
      const registeredDate = tx.registeredDate || null;
      const accountId = tx.accountId || null;
      const partnerId = tx.partnerId || null;
      const pendingDepositId = tx.pendingDepositId || null;
      const borrowerId = tx.borrowerId || null;
      const borrowerName = tx.borrowerName || null;
      const loanType = tx.loanType || null;
      const counterpartId = tx.counterpartId || null;
      const counterpartName = tx.counterpartName || null;
      const invoiceId = tx.invoiceId || null;
      const docId = tx.docId || null;
      const attachments = tx.attachments ? JSON.stringify(tx.attachments) : null;
      const isEdited = tx.isEdited ? 1 : 0;
      const editedBy = tx.editedBy || null;
      const editedById = tx.editedById || null;
      const editedAt = tx.editedAt || null;
      const editHistory = tx.editHistory ? JSON.stringify(tx.editHistory) : null;
      const isDeleted = tx.isDeleted ? 1 : 0;
      const deletedBy = tx.deletedBy || null;
      const deletedById = tx.deletedById || null;
      const deletedAt = tx.deletedAt || null;
      const fiscalYearId = tx.fiscalYearId || null;
      const createdBy = tx.createdBy || null;
      const createdById = tx.createdById || null;
      await connection.query(
        `INSERT INTO transactions (
           id, date, time, amount, type, description, is_registered, category_parent,
           category_child, user_description, is_duplicate, duplicate_reason, tracking_number,
           reference_code, registered_date, account_id, partner_id, pending_deposit_id,
           borrower_id, borrower_name, loan_type, counterpart_id, counterpart_name,
           invoice_id, doc_id, attachments, is_edited, edited_by, edited_by_id, edited_at,
           edit_history, is_deleted, deleted_by, deleted_by_id, deleted_at, fiscal_year_id,
           created_by, created_by_id
         )
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           date = VALUES(date),
           time = VALUES(time),
           amount = VALUES(amount),
           type = VALUES(type),
           description = VALUES(description),
           is_registered = VALUES(is_registered),
           category_parent = VALUES(category_parent),
           category_child = VALUES(category_child),
           user_description = VALUES(user_description),
           is_duplicate = VALUES(is_duplicate),
           duplicate_reason = VALUES(duplicate_reason),
           tracking_number = VALUES(tracking_number),
           reference_code = VALUES(reference_code),
           registered_date = VALUES(registered_date),
           account_id = VALUES(account_id),
           partner_id = VALUES(partner_id),
           pending_deposit_id = VALUES(pending_deposit_id),
           borrower_id = VALUES(borrower_id),
           borrower_name = VALUES(borrower_name),
           loan_type = VALUES(loan_type),
           counterpart_id = VALUES(counterpart_id),
           counterpart_name = VALUES(counterpart_name),
           invoice_id = VALUES(invoice_id),
           doc_id = VALUES(doc_id),
           attachments = VALUES(attachments),
           is_edited = VALUES(is_edited),
           edited_by = VALUES(edited_by),
           edited_by_id = VALUES(edited_by_id),
           edited_at = VALUES(edited_at),
           edit_history = VALUES(edit_history),
           is_deleted = VALUES(is_deleted),
           deleted_by = VALUES(deleted_by),
           deleted_by_id = VALUES(deleted_by_id),
           deleted_at = VALUES(deleted_at),
           fiscal_year_id = VALUES(fiscal_year_id),
           updated_at = CURRENT_TIMESTAMP`,
        [
          id,
          date,
          time,
          amount,
          type,
          description,
          isRegistered,
          categoryParent,
          categoryChild,
          userDescription,
          isDuplicate,
          duplicateReason,
          trackingNumber,
          referenceCode,
          registeredDate,
          accountId,
          partnerId,
          pendingDepositId,
          borrowerId,
          borrowerName,
          loanType,
          counterpartId,
          counterpartName,
          invoiceId,
          docId,
          attachments,
          isEdited,
          editedBy,
          editedById,
          editedAt,
          editHistory,
          isDeleted,
          deletedBy,
          deletedById,
          deletedAt,
          fiscalYearId,
          createdBy,
          createdById
        ]
      );
    }
    await connection.commit();
    const [c] = await connection.query("SELECT COUNT(*) as cnt FROM transactions");
    const dest = Number(c[0]?.cnt || 0);
    totalDestinationRecords += dest;
    reports.push({
      table: "transactions",
      sourceCount: txSourceCount,
      destinationCount: dest,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${txSourceCount} \u062A\u0631\u0627\u06A9\u0646\u0634 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "transactions",
      sourceCount: txSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u062A\u0631\u0627\u06A9\u0646\u0634\u200C\u0647\u0627 (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const docsList = getArray("docs").length > 0 ? getArray("docs") : getArray("accountingDocs");
  let docsSourceCount = docsList.length;
  let docLinesTotalSourceCount = 0;
  totalSourceRecords += docsSourceCount;
  try {
    await connection.beginTransaction();
    for (const doc of docsList) {
      const id = String(doc.id || `doc_${doc.docNumber || Math.random().toString(36).substring(2, 9)}`);
      const docNumber = Number(doc.docNumber) || 0;
      const date = String(doc.date || "");
      const description = doc.description || null;
      const isArchived = doc.isArchived ? 1 : 0;
      const isManual = doc.isManual ? 1 : 0;
      const status = doc.status || "posted";
      const operationType = doc.operationType || null;
      const invoiceId = doc.invoiceId || null;
      const txId = doc.txId || null;
      const refDocId = doc.refDocId || null;
      const idempotencyKey = doc.idempotencyKey || null;
      const actorId = doc.actorId || null;
      const actorName = doc.actorName || null;
      const isDeleted = doc.isDeleted ? 1 : 0;
      const deletedBy = doc.deletedBy || null;
      const deletedById = doc.deletedById || null;
      const deletedAt = doc.deletedAt || null;
      const fiscalYearId = doc.fiscalYearId || null;
      const createdBy = doc.createdBy || null;
      await connection.query(
        `INSERT INTO accounting_docs (
           id, doc_number, date, description, is_archived, is_manual, status,
           operation_type, invoice_id, tx_id, ref_doc_id, idempotency_key,
           actor_id, actor_name, is_deleted, deleted_by, deleted_by_id, deleted_at,
           fiscal_year_id, created_by
         )
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           doc_number = VALUES(doc_number),
           date = VALUES(date),
           description = VALUES(description),
           is_archived = VALUES(is_archived),
           is_manual = VALUES(is_manual),
           status = VALUES(status),
           operation_type = VALUES(operation_type),
           invoice_id = VALUES(invoice_id),
           tx_id = VALUES(tx_id),
           ref_doc_id = VALUES(ref_doc_id),
           idempotency_key = VALUES(idempotency_key),
           actor_id = VALUES(actor_id),
           actor_name = VALUES(actor_name),
           is_deleted = VALUES(is_deleted),
           deleted_by = VALUES(deleted_by),
           deleted_by_id = VALUES(deleted_by_id),
           deleted_at = VALUES(deleted_at),
           fiscal_year_id = VALUES(fiscal_year_id),
           updated_at = CURRENT_TIMESTAMP`,
        [
          id,
          docNumber,
          date,
          description,
          isArchived,
          isManual,
          status,
          operationType,
          invoiceId,
          txId,
          refDocId,
          idempotencyKey,
          actorId,
          actorName,
          isDeleted,
          deletedBy,
          deletedById,
          deletedAt,
          fiscalYearId,
          createdBy
        ]
      );
      const linesArr = Array.isArray(doc.lines) ? doc.lines : [];
      docLinesTotalSourceCount += linesArr.length;
      for (let idx = 0; idx < linesArr.length; idx++) {
        const line = linesArr[idx];
        const lineIdPk = String(line.id || `${id}_line_${idx + 1}`);
        const accountId = line.accountId || null;
        const accountName = line.accountName || null;
        const debit = Number(line.debit) || 0;
        const credit = Number(line.credit) || 0;
        const lineDesc = line.description || null;
        await connection.query(
          `INSERT INTO accounting_doc_lines (
             id, doc_id, account_id, account_name, debit, credit, description, line_index,
             fiscal_year_id, created_by
           )
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
             account_id = VALUES(account_id),
             account_name = VALUES(account_name),
             debit = VALUES(debit),
             credit = VALUES(credit),
             description = VALUES(description),
             line_index = VALUES(line_index),
             fiscal_year_id = VALUES(fiscal_year_id),
             updated_at = CURRENT_TIMESTAMP`,
          [lineIdPk, id, accountId, accountName, debit, credit, lineDesc, idx, fiscalYearId, createdBy]
        );
      }
    }
    await connection.commit();
    const [cDocs] = await connection.query("SELECT COUNT(*) as cnt FROM accounting_docs");
    const destDocs = Number(cDocs[0]?.cnt || 0);
    totalDestinationRecords += destDocs;
    reports.push({
      table: "accounting_docs",
      sourceCount: docsSourceCount,
      destinationCount: destDocs,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${docsSourceCount} \u0633\u0646\u062F \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
    const [cLines] = await connection.query("SELECT COUNT(*) as cnt FROM accounting_doc_lines");
    const destLines = Number(cLines[0]?.cnt || 0);
    totalDestinationRecords += destLines;
    totalSourceRecords += docLinesTotalSourceCount;
    reports.push({
      table: "accounting_doc_lines",
      sourceCount: docLinesTotalSourceCount,
      destinationCount: destLines,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${docLinesTotalSourceCount} \u0633\u0637\u0631 \u0633\u0646\u062F \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "accounting_docs",
      sourceCount: docsSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u0627\u0633\u0646\u0627\u062F \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC (Rollback \u0634\u062F): ${err.message}`
    });
    reports.push({
      table: "accounting_doc_lines",
      sourceCount: docLinesTotalSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u0633\u0637\u0631\u0647\u0627\u06CC \u0627\u0633\u0646\u0627\u062F (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const logsList = [...getArray("system_logs"), ...getArray("auditLogs"), ...getArray("logs")];
  const uniqueLogsMap = /* @__PURE__ */ new Map();
  for (const l of logsList) {
    const key = l.id || `${l.timestampMs}_${l.message}`;
    if (key && !uniqueLogsMap.has(key)) {
      uniqueLogsMap.set(key, l);
    }
  }
  const uniqueLogs = Array.from(uniqueLogsMap.values());
  let logsSourceCount = uniqueLogs.length;
  totalSourceRecords += logsSourceCount;
  try {
    await connection.beginTransaction();
    for (const log of uniqueLogs) {
      const id = String(log.id || `log_${Math.random().toString(36).substring(2, 9)}`);
      const timestamp = log.timestamp || null;
      const timestampMs = log.timestampMs ? Number(log.timestampMs) : null;
      const level = log.level || "info";
      const category = log.category || null;
      const message = String(log.message || "");
      const action = log.action || null;
      const storageLocation = log.storageLocation || null;
      const targetType = log.targetType || null;
      const targetId = log.targetId || null;
      const targetNumber = log.targetNumber || null;
      const amount = Number(log.amount) || 0;
      const userId = log.userId || log.actorId || null;
      const userName = log.userName || log.actorName || null;
      const userRole = log.userRole || log.actorRole || null;
      const ipAddress = log.ipAddress || null;
      const details = log.details ? typeof log.details === "string" ? log.details : JSON.stringify(log.details) : null;
      const fiscalYearId = log.fiscalYearId || null;
      const createdBy = log.createdBy || null;
      await connection.query(
        `INSERT INTO logs (
           id, timestamp, timestamp_ms, level, category, message, action, storage_location,
           target_type, target_id, target_number, amount, user_id, user_name, user_role,
           ip_address, details, fiscal_year_id, created_by
         )
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           level = VALUES(level),
           category = VALUES(category),
           message = VALUES(message),
           action = VALUES(action),
           storage_location = VALUES(storage_location),
           target_type = VALUES(target_type),
           target_id = VALUES(target_id),
           target_number = VALUES(target_number),
           amount = VALUES(amount),
           details = VALUES(details),
           updated_at = CURRENT_TIMESTAMP`,
        [
          id,
          timestamp,
          timestampMs,
          level,
          category,
          message,
          action,
          storageLocation,
          targetType,
          targetId,
          targetNumber,
          amount,
          userId,
          userName,
          userRole,
          ipAddress,
          details,
          fiscalYearId,
          createdBy
        ]
      );
    }
    await connection.commit();
    const [c] = await connection.query("SELECT COUNT(*) as cnt FROM logs");
    const dest = Number(c[0]?.cnt || 0);
    totalDestinationRecords += dest;
    reports.push({
      table: "logs",
      sourceCount: logsSourceCount,
      destinationCount: dest,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${logsSourceCount} \u0644\u0627\u06AF \u0633\u0627\u0645\u0627\u0646\u0647 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "logs",
      sourceCount: logsSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u0644\u0627\u06AF\u200C\u0647\u0627 (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const notifsList = getArray("notifications");
  let notifsSourceCount = notifsList.length;
  totalSourceRecords += notifsSourceCount;
  try {
    await connection.beginTransaction();
    for (const n of notifsList) {
      const id = String(n.id || `notif_${Math.random().toString(36).substring(2, 9)}`);
      const userId = String(n.userId || "system");
      const title = String(n.title || "\u0627\u0639\u0644\u0627\u0646");
      const message = n.message || null;
      const type = n.type || "info";
      const timestamp = n.timestamp || null;
      const isRead = n.isRead ? 1 : 0;
      const senderId = n.senderId || null;
      const senderName = n.senderName || null;
      const fiscalYearId = n.fiscalYearId || null;
      const createdBy = n.createdBy || null;
      await connection.query(
        `INSERT INTO notifications (id, user_id, title, message, type, timestamp, is_read, sender_id, sender_name, fiscal_year_id, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           title = VALUES(title),
           message = VALUES(message),
           type = VALUES(type),
           is_read = VALUES(is_read),
           updated_at = CURRENT_TIMESTAMP`,
        [id, userId, title, message, type, timestamp, isRead, senderId, senderName, fiscalYearId, createdBy]
      );
    }
    await connection.commit();
    const [c] = await connection.query("SELECT COUNT(*) as cnt FROM notifications");
    const dest = Number(c[0]?.cnt || 0);
    totalDestinationRecords += dest;
    reports.push({
      table: "notifications",
      sourceCount: notifsSourceCount,
      destinationCount: dest,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${notifsSourceCount} \u0627\u0639\u0644\u0627\u0646 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "notifications",
      sourceCount: notifsSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u0627\u0639\u0644\u0627\u0646\u200C\u0647\u0627 (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const checklistList = getArray("checklist");
  let chkSourceCount = checklistList.length;
  totalSourceRecords += chkSourceCount;
  try {
    await connection.beginTransaction();
    for (const item of checklistList) {
      const id = String(item.id || `chk_${Math.random().toString(36).substring(2, 9)}`);
      const task = String(item.task || "\u062A\u0633\u06A9");
      const isCompleted = item.isCompleted ? 1 : 0;
      const isPublic = item.isPublic ? 1 : 0;
      const completedAt2 = item.completedAt ? Number(item.completedAt) : null;
      const date = item.date || null;
      const fiscalYearId = item.fiscalYearId || null;
      const createdBy = item.createdBy || null;
      await connection.query(
        `INSERT INTO checklist (id, task, is_completed, is_public, completed_at, date, fiscal_year_id, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           task = VALUES(task),
           is_completed = VALUES(is_completed),
           is_public = VALUES(is_public),
           completed_at = VALUES(completed_at),
           date = VALUES(date),
           updated_at = CURRENT_TIMESTAMP`,
        [id, task, isCompleted, isPublic, completedAt2, date, fiscalYearId, createdBy]
      );
    }
    await connection.commit();
    const [c] = await connection.query("SELECT COUNT(*) as cnt FROM checklist");
    const dest = Number(c[0]?.cnt || 0);
    totalDestinationRecords += dest;
    reports.push({
      table: "checklist",
      sourceCount: chkSourceCount,
      destinationCount: dest,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${chkSourceCount} \u0645\u0648\u0631\u062F \u0686\u06A9\u200C\u0644\u06CC\u0633\u062A \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "checklist",
      sourceCount: chkSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u0686\u06A9\u200C\u0644\u06CC\u0633\u062A (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const knownCollectionKeys = /* @__PURE__ */ new Set([
    "users",
    "fiscalYears",
    "fiscal_years",
    "counterparts",
    "categories",
    "warehouses",
    "items",
    "accounts",
    "invoices",
    "invoice_items",
    "transactions",
    "accountingDocs",
    "docs",
    "accounting_doc_lines",
    "logs",
    "system_logs",
    "auditLogs",
    "notifications",
    "checklist",
    "uploads"
  ]);
  const settingsEntries = [];
  for (const [k, v] of Object.entries(stateData)) {
    if (k.startsWith("acc_app_")) continue;
    if (knownCollectionKeys.has(k)) continue;
    if (v !== void 0 && v !== null) {
      settingsEntries.push({ key: k, value: v });
    }
  }
  let settingsSourceCount = settingsEntries.length;
  totalSourceRecords += settingsSourceCount;
  try {
    await connection.beginTransaction();
    for (const entry of settingsEntries) {
      const id = `setting_${entry.key}`;
      const settingKey = entry.key;
      const settingValue = typeof entry.value === "string" ? entry.value : JSON.stringify(entry.value);
      await connection.query(
        `INSERT INTO settings (id, setting_key, setting_value, created_by)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           setting_value = VALUES(setting_value),
           updated_at = CURRENT_TIMESTAMP`,
        [id, settingKey, settingValue, "system"]
      );
    }
    await connection.commit();
    const [c] = await connection.query("SELECT COUNT(*) as cnt FROM settings");
    const dest = Number(c[0]?.cnt || 0);
    totalDestinationRecords += dest;
    reports.push({
      table: "settings",
      sourceCount: settingsSourceCount,
      destinationCount: dest,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${settingsSourceCount} \u062A\u0646\u0638\u06CC\u0645 \u0648 \u067E\u06CC\u06A9\u0631\u0628\u0646\u062F\u06CC \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "settings",
      sourceCount: settingsSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u062A\u0646\u0638\u06CC\u0645\u0627\u062A (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const uploadsList = getArray("uploads");
  let uploadsSourceCount = uploadsList.length;
  totalSourceRecords += uploadsSourceCount;
  try {
    await connection.beginTransaction();
    for (const up of uploadsList) {
      const id = String(up.id || `up_${Math.random().toString(36).substring(2, 9)}`);
      const fileName = String(up.fileName || up.name || "file");
      const originalName = up.originalName || up.fileName || null;
      const filePath = up.filePath || null;
      const fileSize = up.fileSize ? Number(up.fileSize) : null;
      const mimeType = up.mimeType || null;
      const entityType = up.entityType || null;
      const entityId = up.entityId || null;
      const dataUrl = up.dataUrl || up.url || null;
      const fiscalYearId = up.fiscalYearId || null;
      const createdBy = up.createdBy || null;
      await connection.query(
        `INSERT INTO uploads (id, file_name, original_name, file_path, file_size, mime_type, entity_type, entity_id, data_url, fiscal_year_id, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           file_name = VALUES(file_name),
           original_name = VALUES(original_name),
           file_path = VALUES(file_path),
           file_size = VALUES(file_size),
           mime_type = VALUES(mime_type),
           entity_type = VALUES(entity_type),
           entity_id = VALUES(entity_id),
           data_url = VALUES(data_url),
           updated_at = CURRENT_TIMESTAMP`,
        [id, fileName, originalName, filePath, fileSize, mimeType, entityType, entityId, dataUrl, fiscalYearId, createdBy]
      );
    }
    await connection.commit();
    const [c] = await connection.query("SELECT COUNT(*) as cnt FROM uploads");
    const dest = Number(c[0]?.cnt || 0);
    totalDestinationRecords += dest;
    reports.push({
      table: "uploads",
      sourceCount: uploadsSourceCount,
      destinationCount: dest,
      status: "success",
      message: `\u0627\u0646\u062A\u0642\u0627\u0644 ${uploadsSourceCount} \u0641\u0627\u06CC\u0644 \u0648 \u067E\u06CC\u0648\u0633\u062A \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.`
    });
  } catch (err) {
    await connection.rollback();
    reports.push({
      table: "uploads",
      sourceCount: uploadsSourceCount,
      destinationCount: 0,
      status: "error",
      message: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u067E\u06CC\u0648\u0633\u062A\u200C\u0647\u0627 (Rollback \u0634\u062F): ${err.message}`
    });
  }
  const completedAt = (/* @__PURE__ */ new Date()).toISOString();
  const hasErrors = reports.some((r) => r.status === "error");
  return {
    success: !hasErrors,
    backup: backupResult,
    totalSourceRecords,
    totalDestinationRecords,
    reports,
    startedAt,
    completedAt,
    durationMs: Date.now() - startTime
  };
}
var serverMemoryStateCache = null;
var serverStateVersion = Date.now();
var keyVersions = {};
async function populateMemoryCache() {
  const result = {};
  const now = Date.now();
  let maxTs = now;
  keyVersions = {};
  try {
    const rows = await executeMysqlQuery("SELECT state_key, state_value, UNIX_TIMESTAMP(updated_at) as updated_ts FROM app_state");
    if (Array.isArray(rows)) {
      for (const row of rows) {
        let val = safeUnwrapJson(row.state_value);
        const cleanKey = row.state_key.startsWith("acc_app_") ? row.state_key.substring(8) : row.state_key;
        if (val !== void 0 && val !== null) {
          result[cleanKey] = val;
          result[`acc_app_${cleanKey}`] = val;
        }
        const rowTs = row.updated_ts ? Number(row.updated_ts) * 1e3 : now;
        keyVersions[cleanKey] = rowTs;
        keyVersions[`acc_app_${cleanKey}`] = rowTs;
        if (rowTs > maxTs) maxTs = rowTs;
      }
    }
  } catch (err) {
    console.warn("Notice: app_state fallback read notice:", err.message);
  }
  try {
    await loadRelationalTablesIntoCache(result);
  } catch (err) {
    console.warn("Notice: relational tables load notice:", err.message);
  }
  if (result.invoices && Array.isArray(result.invoices)) {
    result.invoices = sanitizeInvoiceList(result.invoices);
    result.acc_app_invoices = result.invoices;
  }
  const relationalKeys = ["invoices", "transactions", "items", "counterparts", "accounts", "categories", "warehouses", "docs", "accountingDocuments", "notifications"];
  for (const rKey of relationalKeys) {
    keyVersions[rKey] = maxTs;
    keyVersions[`acc_app_${rKey}`] = maxTs;
  }
  serverStateVersion = maxTs;
  serverMemoryStateCache = result;
}
async function getLatestItemsList(conn) {
  const [itemRows] = await conn.execute("SELECT * FROM items ORDER BY id DESC");
  if (!Array.isArray(itemRows)) return [];
  return itemRows.map((r) => {
    let obj = {};
    if (r.raw_json) {
      try {
        obj = typeof r.raw_json === "string" ? JSON.parse(r.raw_json) : r.raw_json;
      } catch (e) {
        try {
          obj = JSON.parse(JSON.stringify(r.raw_json));
        } catch {
        }
      }
    }
    return {
      ...obj,
      id: r.id,
      name: r.name,
      code: r.code,
      type: r.type || "kala",
      qty: Number(r.qty) || 0,
      stock: Number(r.qty) || 0,
      initialQty: Number(r.initial_qty) || 0,
      purchasePrice: Number(r.last_purchase_price) || 0,
      lastPurchasePrice: Number(r.last_purchase_price) || 0,
      salePrice: Number(r.last_sale_price) || 0,
      lastSalePrice: Number(r.last_sale_price) || 0,
      minStock: Number(r.min_qty_alarm) || 0,
      minQtyAlarm: Number(r.min_qty_alarm) || 0,
      category: r.category_name,
      categoryName: r.category_name,
      parentCategory: r.parent_category,
      subCategory: r.sub_category,
      commissionPercent: Number(r.commission_percent) || 0,
      setupDate: r.setup_date,
      warehouseId: r.warehouse_id,
      fiscalYearId: r.fiscal_year_id,
      createdBy: r.created_by,
      createdAt: r.created_at,
      updatedAt: r.updated_at
    };
  });
}
async function loadRelationalTablesIntoCache(result) {
  try {
    const invRows = await executeMysqlQuery("SELECT * FROM invoices WHERE is_deleted = 0 ORDER BY id DESC");
    if (Array.isArray(invRows) && invRows.length > 0) {
      const itemRows = await executeMysqlQuery("SELECT * FROM invoice_items ORDER BY id ASC");
      const itemsMap = /* @__PURE__ */ new Map();
      if (Array.isArray(itemRows)) {
        for (const itm of itemRows) {
          const invId = String(itm.invoice_id);
          if (!itemsMap.has(invId)) itemsMap.set(invId, []);
          let itmObj = {};
          itmObj = {
            id: itm.id,
            itemId: itm.item_id,
            name: itm.name || "",
            qty: Number(itm.qty) || 0,
            quantity: Number(itm.qty) || 0,
            unit: itm.unit || "\u0639\u062F\u062F",
            unitPrice: Number(itm.unit_price) || 0,
            discount: Number(itm.discount) || 0,
            tax: Number(itm.tax) || 0,
            totalPrice: Number(itm.total_price) || 0,
            total: Number(itm.total_price) || 0,
            remarks: itm.remarks || "",
            description: itm.remarks || "",
            type: itm.type || "kala",
            color: itm.color || null,
            cogsUnitCost: Number(itm.cogs_unit_cost) || 0,
            cogsTotal: Number(itm.cogs_total) || 0,
            sortOrder: Number(itm.sort_order) || 0,
            fiscalYearId: itm.fiscal_year_id,
            createdBy: itm.created_by
          };
          itemsMap.get(invId).push(itmObj);
        }
      }
      const invList = [];
      for (const row of invRows) {
        const invId = String(row.id);
        const relatedItems = itemsMap.get(invId) || [];
        let customIcons = null;
        let attachments = null;
        let paymentSlips = null;
        let history = null;
        let allocations = null;
        try {
          if (row.custom_icons) customIcons = JSON.parse(row.custom_icons);
        } catch (_) {
        }
        try {
          if (row.attachments) attachments = JSON.parse(row.attachments);
        } catch (_) {
        }
        try {
          if (row.payment_slips) paymentSlips = JSON.parse(row.payment_slips);
        } catch (_) {
        }
        try {
          if (row.history) history = JSON.parse(row.history);
        } catch (_) {
        }
        try {
          if (row.allocations) allocations = JSON.parse(row.allocations);
        } catch (_) {
        }
        const invObj = {
          id: row.id,
          invoiceNumber: row.invoice_number,
          type: row.type || "sale",
          date: row.date,
          counterpartId: row.counterpart_id,
          counterpartName: row.counterpart_name,
          counterpartPhone: row.counterpart_phone,
          counterpartAddress: row.counterpart_address,
          totalAmount: Number(row.total_amount) || 0,
          tax: Number(row.tax) || 0,
          deposit: Number(row.deposit) || 0,
          discount: Number(row.discount) || 0,
          paymentAmount: Number(row.payment_amount) || 0,
          paymentDate: row.payment_date,
          description: row.description,
          isProforma: Boolean(row.is_proforma),
          isUrgent: Boolean(row.is_urgent),
          urgentType: row.urgent_type,
          shippingMethod: row.shipping_method,
          acquaintanceMethod: row.acquaintance_method,
          docId: row.doc_id,
          cogsDocId: row.cogs_doc_id,
          cogsTotal: Number(row.cogs_total) || 0,
          isReturn: Boolean(row.is_return),
          returnRefInvoiceId: row.return_ref_invoice_id,
          customIcons,
          attachments,
          paymentSlips,
          history,
          allocations,
          fiscalYearId: row.fiscal_year_id,
          createdBy: row.created_by,
          createdById: row.created_by_id,
          createdByPhone: row.created_by_phone,
          items: relatedItems,
          createdAt: row.created_at,
          updatedAt: row.updated_at
        };
        invList.push(invObj);
      }
      result.invoices = invList;
      result.acc_app_invoices = invList;
    }
  } catch (e) {
  }
  try {
    const txRows = await executeMysqlQuery("SELECT * FROM transactions WHERE is_deleted = 0 ORDER BY id DESC");
    if (Array.isArray(txRows) && txRows.length > 0) {
      const txList = txRows.map((r) => {
        let attachments = null;
        let editHistory = null;
        try {
          if (r.attachments) attachments = JSON.parse(r.attachments);
        } catch (_) {
        }
        try {
          if (r.edit_history) editHistory = JSON.parse(r.edit_history);
        } catch (_) {
        }
        return {
          id: r.id,
          date: r.date,
          time: r.time,
          amount: Number(r.amount) || 0,
          type: r.type,
          description: r.description,
          isRegistered: Boolean(r.is_registered),
          categoryParent: r.category_parent,
          categoryChild: r.category_child,
          categoryId: r.category_child || r.category_parent,
          category: r.category_child || r.category_parent,
          userDescription: r.user_description,
          isDuplicate: Boolean(r.is_duplicate),
          duplicateReason: r.duplicate_reason,
          trackingNumber: r.tracking_number,
          referenceCode: r.reference_code,
          registeredDate: r.registered_date,
          accountId: r.account_id,
          partnerId: r.partner_id,
          pendingDepositId: r.pending_deposit_id,
          borrowerId: r.borrower_id,
          borrowerName: r.borrower_name,
          loanType: r.loan_type,
          counterpartId: r.counterpart_id,
          counterpartName: r.counterpart_name,
          invoiceId: r.invoice_id,
          docId: r.doc_id,
          attachments,
          isEdited: Boolean(r.is_edited),
          editedBy: r.edited_by,
          editedById: r.edited_by_id,
          editedAt: r.edited_at,
          editHistory,
          isDeleted: Boolean(r.is_deleted),
          deletedBy: r.deleted_by,
          deletedById: r.deleted_by_id,
          deletedAt: r.deleted_at,
          fiscalYearId: r.fiscal_year_id,
          createdBy: r.created_by,
          createdById: r.created_by_id,
          createdAt: r.created_at,
          updatedAt: r.updated_at
        };
      });
      result.transactions = txList;
      result.acc_app_transactions = txList;
    }
  } catch (e) {
  }
  try {
    const itemRows = await executeMysqlQuery("SELECT * FROM items ORDER BY id DESC");
    if (Array.isArray(itemRows) && itemRows.length > 0) {
      const itemList = itemRows.map((r) => {
        let obj = safeUnwrapJson(r.raw_json) || {};
        return {
          ...obj,
          id: r.id,
          name: r.name,
          code: r.code,
          type: r.type || "kala",
          qty: Number(r.qty) || 0,
          stock: Number(r.qty) || 0,
          initialQty: Number(r.initial_qty) || 0,
          purchasePrice: Number(r.last_purchase_price) || 0,
          lastPurchasePrice: Number(r.last_purchase_price) || 0,
          salePrice: Number(r.last_sale_price) || 0,
          lastSalePrice: Number(r.last_sale_price) || 0,
          minStock: Number(r.min_qty_alarm) || 0,
          minQtyAlarm: Number(r.min_qty_alarm) || 0,
          category: r.category_name,
          categoryName: r.category_name,
          parentCategory: r.parent_category,
          subCategory: r.sub_category,
          commissionPercent: Number(r.commission_percent) || 0,
          setupDate: r.setup_date,
          warehouseId: r.warehouse_id,
          fiscalYearId: r.fiscal_year_id,
          createdBy: r.created_by,
          createdAt: r.created_at,
          updatedAt: r.updated_at
        };
      });
      result.items = itemList;
      result.acc_app_items = itemList;
    }
  } catch (e) {
  }
  try {
    const cpRows = await executeMysqlQuery("SELECT * FROM counterparts ORDER BY id DESC");
    if (Array.isArray(cpRows) && cpRows.length > 0) {
      const cpList = cpRows.map((r) => {
        let obj = safeUnwrapJson(r.raw_json) || {};
        return {
          ...obj,
          id: r.id,
          name: r.name,
          code: r.code,
          type: r.type,
          phone: r.phone,
          mobile: r.mobile,
          nationalId: r.national_id,
          economicCode: r.economic_code,
          address: r.address,
          postalCode: r.postal_code,
          initialBalance: Number(r.initial_balance) || 0,
          currentBalance: Number(r.current_balance) || 0,
          createdBy: r.created_by,
          createdAt: r.created_at,
          updatedAt: r.updated_at
        };
      });
      result.counterparts = cpList;
      result.acc_app_counterparts = cpList;
    }
  } catch (e) {
  }
  try {
    const accRows = await executeMysqlQuery("SELECT * FROM accounts ORDER BY id DESC");
    if (Array.isArray(accRows) && accRows.length > 0) {
      const accList = accRows.map((r) => {
        let obj = safeUnwrapJson(r.raw_json) || {};
        return {
          ...obj,
          id: r.id,
          name: r.name,
          type: r.type,
          bankName: r.bank_name,
          accountNumber: r.account_number,
          cardNumber: r.card_number,
          shabaNumber: r.shaba_number,
          balance: Number(r.balance) || 0,
          initialBalance: Number(r.initial_balance) || 0,
          createdBy: r.created_by,
          createdAt: r.created_at,
          updatedAt: r.updated_at
        };
      });
      result.accounts = accList;
      result.acc_app_accounts = accList;
    }
  } catch (e) {
  }
  try {
    const catRows = await executeMysqlQuery("SELECT * FROM categories ORDER BY id ASC");
    if (Array.isArray(catRows) && catRows.length > 0) {
      const catList = catRows.map((r) => {
        let obj = safeUnwrapJson(r.raw_json) || {};
        return {
          ...obj,
          id: r.id,
          name: r.name,
          type: r.type,
          icon: r.icon,
          color: r.color,
          parentId: r.parent_id,
          createdBy: r.created_by
        };
      });
      result.categories = catList;
      result.acc_app_categories = catList;
    }
  } catch (e) {
  }
  try {
    const whRows = await executeMysqlQuery("SELECT * FROM warehouses ORDER BY id ASC");
    if (Array.isArray(whRows) && whRows.length > 0) {
      const whList = whRows.map((r) => {
        let obj = safeUnwrapJson(r.raw_json) || {};
        return {
          ...obj,
          id: r.id,
          name: r.name,
          code: r.code,
          address: r.address,
          manager: r.manager,
          phone: r.phone,
          createdBy: r.created_by
        };
      });
      result.warehouses = whList;
      result.acc_app_warehouses = whList;
    }
  } catch (e) {
  }
  try {
    const docRows = await executeMysqlQuery("SELECT * FROM accounting_docs WHERE is_deleted = 0 ORDER BY id DESC");
    if (Array.isArray(docRows) && docRows.length > 0) {
      const lineRows = await executeMysqlQuery("SELECT * FROM accounting_doc_lines ORDER BY line_index ASC, id ASC");
      const linesMap = /* @__PURE__ */ new Map();
      if (Array.isArray(lineRows)) {
        for (const ln of lineRows) {
          const docId = String(ln.doc_id);
          if (!linesMap.has(docId)) linesMap.set(docId, []);
          const lineObj = {
            id: ln.id,
            docId: ln.doc_id,
            accountId: ln.account_id,
            accountCode: ln.account_id,
            accountName: ln.account_name,
            debit: Number(ln.debit) || 0,
            credit: Number(ln.credit) || 0,
            description: ln.description,
            lineIndex: Number(ln.line_index) || 0,
            rowOrder: Number(ln.line_index) || 0,
            fiscalYearId: ln.fiscal_year_id,
            createdBy: ln.created_by,
            createdAt: ln.created_at,
            updatedAt: ln.updated_at
          };
          linesMap.get(docId).push(lineObj);
        }
      }
      const docList = [];
      for (const row of docRows) {
        const docId = String(row.id);
        const relatedLines = linesMap.get(docId) || [];
        const totalDebit = relatedLines.reduce((sum, ln) => sum + (Number(ln.debit) || 0), 0);
        const totalCredit = relatedLines.reduce((sum, ln) => sum + (Number(ln.credit) || 0), 0);
        const docObj = {
          id: row.id,
          docNumber: Number(row.doc_number) || 0,
          date: row.date,
          description: row.description,
          isArchived: Boolean(row.is_archived),
          isManual: Boolean(row.is_manual),
          status: row.status || "posted",
          operationType: row.operation_type,
          invoiceId: row.invoice_id,
          txId: row.tx_id,
          refDocId: row.ref_doc_id,
          idempotencyKey: row.idempotency_key,
          actorId: row.actor_id,
          actorName: row.actor_name,
          isDeleted: Boolean(row.is_deleted),
          deletedBy: row.deleted_by,
          deletedById: row.deleted_by_id,
          deletedAt: row.deleted_at,
          fiscalYearId: row.fiscal_year_id,
          createdBy: row.created_by,
          lines: relatedLines,
          totalDebit,
          totalCredit,
          createdAt: row.created_at,
          updatedAt: row.updated_at
        };
        docList.push(docObj);
      }
      result.docs = docList;
      result.acc_app_docs = docList;
      result.accountingDocuments = docList;
      result.acc_app_accountingDocuments = docList;
    }
  } catch (e) {
  }
  try {
    const notifRows = await executeMysqlQuery("SELECT * FROM notifications ORDER BY id DESC LIMIT 200");
    if (Array.isArray(notifRows) && notifRows.length > 0) {
      const notifList = notifRows.map((r) => {
        let obj = safeUnwrapJson(r.raw_json) || {};
        return {
          ...obj,
          id: r.id,
          userId: r.user_id,
          title: r.title,
          message: r.message,
          type: r.type,
          isRead: Boolean(r.is_read),
          link: r.link,
          createdAt: r.created_at
        };
      });
      result.notifications = notifList;
      result.acc_app_notifications = notifList;
    }
  } catch (e) {
  }
  try {
    const chkRows = await executeMysqlQuery("SELECT * FROM checklist ORDER BY row_order ASC, id ASC");
    if (Array.isArray(chkRows) && chkRows.length > 0) {
      const chkList = chkRows.map((r) => {
        let obj = safeUnwrapJson(r.raw_json) || {};
        return {
          ...obj,
          id: r.id,
          title: r.title,
          isCompleted: Boolean(r.is_completed),
          completed: Boolean(r.is_completed),
          dueDate: r.due_date,
          rowOrder: Number(r.row_order) || 0,
          createdBy: r.created_by
        };
      });
      result.checklist = chkList;
      result.acc_app_checklist = chkList;
    }
  } catch (e) {
  }
  try {
    const setRows = await executeMysqlQuery("SELECT setting_key, setting_value FROM settings");
    if (Array.isArray(setRows) && setRows.length > 0) {
      const settingsObj = result.settings || {};
      for (const sr of setRows) {
        settingsObj[sr.setting_key] = safeUnwrapJson(sr.setting_value);
      }
      result.settings = settingsObj;
      result.acc_app_settings = settingsObj;
    }
  } catch (e) {
  }
  try {
    const userRows = await executeMysqlQuery("SELECT * FROM users ORDER BY id ASC");
    if (Array.isArray(userRows) && userRows.length > 0) {
      const userList = userRows.map((r) => {
        let obj = safeUnwrapJson(r.raw_json) || {};
        return {
          ...obj,
          id: r.id,
          username: r.username,
          name: r.name,
          role: r.role,
          phone: r.phone,
          password: r.password_hash || r.username,
          permissions: safeUnwrapJson(r.permissions) || obj.permissions || []
        };
      });
      result.users = userList;
      result.acc_app_users = userList;
    }
  } catch (e) {
  }
  try {
    const fyRows = await executeMysqlQuery("SELECT * FROM fiscal_years ORDER BY id DESC");
    if (Array.isArray(fyRows) && fyRows.length > 0) {
      const fy = fyRows[0];
      let obj = safeUnwrapJson(fy.raw_json) || {};
      const fyObj = {
        ...obj,
        id: fy.id,
        year: fy.year_title,
        startDate: fy.start_date,
        endDate: fy.end_date,
        registered: !Boolean(fy.is_closed),
        createdBy: fy.created_by
      };
      result.fiscalYear = fyObj;
      result.acc_app_fiscalYear = fyObj;
    }
  } catch (e) {
  }
  try {
    const logRows = await executeMysqlQuery("SELECT * FROM logs ORDER BY id DESC LIMIT 500");
    if (Array.isArray(logRows) && logRows.length > 0) {
      const logList = logRows.map((r) => {
        let obj = safeUnwrapJson(r.raw_json) || {};
        return {
          ...obj,
          id: r.id,
          level: r.level,
          category: r.category,
          action: r.action,
          message: r.message,
          userId: r.user_id,
          createdAt: r.created_at
        };
      });
      result.system_logs = logList;
      result.acc_app_system_logs = logList;
    }
  } catch (e) {
  }
}
async function getKeyData(key) {
  const cleanKey = key.startsWith("acc_app_") ? key.substring(8) : key;
  if (!serverMemoryStateCache) {
    await populateMemoryCache();
  }
  if (serverMemoryStateCache) {
    if (cleanKey in serverMemoryStateCache) return serverMemoryStateCache[cleanKey];
    if (`acc_app_${cleanKey}` in serverMemoryStateCache) return serverMemoryStateCache[`acc_app_${cleanKey}`];
  }
  return null;
}
async function executeMysqlQuery(sql, params = []) {
  const config = getAppConfig();
  if (!mysqlPool) {
    mysqlPool = import_promise.default.createPool({
      host: config.DB_HOST || "localhost",
      port: Number(config.DB_PORT) || 3306,
      user: config.DB_USER,
      password: config.DB_PASSWORD,
      database: config.DB_NAME,
      waitForConnections: true,
      connectionLimit: 15,
      queueLimit: 0,
      enableKeepAlive: true,
      keepAliveInitialDelay: 1e4,
      connectTimeout: 1e4,
      charset: "utf8mb4"
    });
  }
  try {
    const [result] = await mysqlPool.query(sql, params);
    mysqlError = null;
    return result;
  } catch (err) {
    const errCode = err.code || "";
    if (errCode === "PROTOCOL_CONNECTION_LOST" || errCode === "ECONNRESET" || errCode === "ETIMEDOUT" || errCode === "PROTOCOL_ENQUEUE_AFTER_FATAL_ERROR") {
      console.warn(`[MySQL] Connection lost (${errCode}). Reconnecting...`);
      try {
        if (mysqlPool) {
          try {
            await mysqlPool.end();
          } catch (_) {
          }
        }
        mysqlPool = import_promise.default.createPool({
          host: config.DB_HOST || "localhost",
          port: Number(config.DB_PORT) || 3306,
          user: config.DB_USER,
          password: config.DB_PASSWORD,
          database: config.DB_NAME,
          waitForConnections: true,
          connectionLimit: 15,
          queueLimit: 0,
          enableKeepAlive: true,
          keepAliveInitialDelay: 1e4,
          connectTimeout: 1e4,
          charset: "utf8mb4"
        });
        const [retryResult] = await mysqlPool.query(sql, params);
        mysqlError = null;
        return retryResult;
      } catch (retryErr) {
        mysqlError = retryErr.message;
        throw retryErr;
      }
    }
    mysqlError = err.message;
    throw err;
  }
}
var stateMutationMutex = Promise.resolve();
function withStateMutationMutex(action) {
  const prev = stateMutationMutex;
  let resolveLock = () => {
  };
  stateMutationMutex = new Promise((resolve) => {
    resolveLock = resolve;
  });
  return prev.then(action).finally(() => {
    resolveLock();
  });
}
var COLLECTION_ENTITY_KEYS = /* @__PURE__ */ new Set([
  "invoices",
  "transactions",
  "items",
  "counterparts",
  "accounts",
  "partners",
  "categories",
  "checklist",
  "docs",
  "bankSmsMessages",
  "paymentAllocations",
  "inventoryMovements",
  "auditLogs",
  "system_logs",
  "pendingDeposits",
  "loanBorrowers",
  "warehouse_categories_list",
  "warehouse_stock_adjustment_logs"
]);
function getEntityIdentifier(item) {
  if (!item || typeof item !== "object") return null;
  if (item.id !== void 0 && item.id !== null && String(item.id).trim() !== "") {
    return String(item.id).trim();
  }
  if (item.invoiceNumber !== void 0 && item.invoiceNumber !== null && String(item.invoiceNumber).trim() !== "") {
    const isPf = Boolean(item.isProforma || typeof item.invoiceNumber === "string" && item.invoiceNumber.startsWith("PF-") || item.type === "proforma");
    return isPf ? `pf_num_${String(item.invoiceNumber).trim()}` : `inv_num_${String(item.invoiceNumber).trim()}`;
  }
  if (item.docNumber !== void 0 && item.docNumber !== null && String(item.docNumber).trim() !== "") {
    return `doc-${String(item.docNumber).trim()}`;
  }
  if (item.code !== void 0 && item.code !== null && String(item.code).trim() !== "") {
    return `code-${String(item.code).trim()}`;
  }
  if (item.username !== void 0 && item.username !== null && String(item.username).trim() !== "") {
    return `user-${String(item.username).trim()}`;
  }
  if (item.refCode !== void 0 && item.refCode !== null && String(item.refCode).trim() !== "") {
    return `ref-${String(item.refCode).trim()}`;
  }
  return null;
}
function getEntityTimestamp(item) {
  if (!item || typeof item !== "object") return 0;
  if (typeof item.updatedAt === "number") return item.updatedAt;
  if (typeof item.updatedAt === "string") {
    const t = new Date(item.updatedAt).getTime();
    if (!isNaN(t)) return t;
  }
  if (typeof item.timestampMs === "number") return item.timestampMs;
  if (item.timestamp) {
    const t = new Date(item.timestamp).getTime();
    if (!isNaN(t)) return t;
  }
  if (item.postedAt) {
    const t = new Date(item.postedAt).getTime();
    if (!isNaN(t)) return t;
  }
  if (item.createdAt) {
    const t = new Date(item.createdAt).getTime();
    if (!isNaN(t)) return t;
  }
  return 0;
}
function sanitizeInvoiceList(invoicesList) {
  if (!Array.isArray(invoicesList)) return [];
  const map = /* @__PURE__ */ new Map();
  for (const inv of invoicesList) {
    if (!inv || typeof inv !== "object") continue;
    const id = inv.id ? String(inv.id).trim() : null;
    if (id) {
      const existing = map.get(id);
      if (existing) {
        if (existing.isProforma && !inv.isProforma) {
          map.set(id, inv);
        } else if (!existing.isProforma && inv.isProforma) {
        } else {
          const existingTs = getEntityTimestamp(existing);
          const invTs = getEntityTimestamp(inv);
          if (invTs >= existingTs) {
            map.set(id, inv);
          }
        }
      } else {
        map.set(id, inv);
      }
    } else {
      map.set(`unkeyed_${Math.random()}`, inv);
    }
  }
  return Array.from(map.values());
}
function smartMergeEntityArray(existingList, incomingList) {
  if (!Array.isArray(existingList) || existingList.length === 0) return incomingList;
  if (!Array.isArray(incomingList) || incomingList.length === 0) return existingList;
  const mergedMap = /* @__PURE__ */ new Map();
  const unkeyed = [];
  for (const item of existingList) {
    const id = getEntityIdentifier(item);
    if (id) {
      mergedMap.set(id, item);
    } else {
      unkeyed.push(item);
    }
  }
  for (const item of incomingList) {
    const id = getEntityIdentifier(item);
    if (id) {
      const existing = mergedMap.get(id);
      if (existing) {
        const existingTs = getEntityTimestamp(existing);
        const incomingTs = getEntityTimestamp(item);
        if (incomingTs >= existingTs) {
          mergedMap.set(id, item);
        } else {
          mergedMap.set(id, { ...item, ...existing });
        }
      } else {
        mergedMap.set(id, item);
      }
    } else {
      unkeyed.push(item);
    }
  }
  const result = [...Array.from(mergedMap.values()), ...unkeyed];
  if (result.some((it) => it && (it.invoiceNumber !== void 0 || it.isProforma !== void 0))) {
    return sanitizeInvoiceList(result);
  }
  return result;
}
function safeUnwrapJson(val) {
  if (val === null || val === void 0) return val;
  let parsed = val;
  while (typeof parsed === "string") {
    const trimmed = parsed.trim();
    if (trimmed.startsWith("{") && trimmed.endsWith("}") || trimmed.startsWith("[") && trimmed.endsWith("]") || trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed === "null" || trimmed === "true" || trimmed === "false") {
      try {
        const next = JSON.parse(parsed);
        if (next === parsed) break;
        parsed = next;
      } catch (_) {
        break;
      }
    } else {
      break;
    }
  }
  return parsed;
}
async function loadAllData() {
  if (serverMemoryStateCache && Object.keys(serverMemoryStateCache).length > 0) {
    return { ...serverMemoryStateCache };
  }
  await populateMemoryCache();
  return { ...serverMemoryStateCache || {} };
}
function ensureUploadsSecurityNode(baseDir = process.cwd()) {
  const uploadsDir = import_path.default.join(baseDir, "uploads");
  if (!import_fs.default.existsSync(uploadsDir)) {
    try {
      import_fs.default.mkdirSync(uploadsDir, { recursive: true });
    } catch (_) {
    }
  }
  const htaccessPath = import_path.default.join(uploadsDir, ".htaccess");
  const htaccessContent = `# Disable PHP execution in uploads directory for security
<FilesMatch "(?i)\\.(php|php3|php4|php5|php7|phtml|phar|pl|py|cgi|sh|exe|shtml)$">
    Order Deny,Allow
    Deny from all
</FilesMatch>
Options -ExecCGI
<IfModule mod_php7.c>
    php_flag engine off
</IfModule>
<IfModule mod_php8.c>
    php_flag engine off
</IfModule>
`;
  if (!import_fs.default.existsSync(htaccessPath)) {
    try {
      import_fs.default.writeFileSync(htaccessPath, htaccessContent, "utf8");
    } catch (_) {
    }
  }
}
function extractAndSaveBase64ImagesNode(data, category = "general") {
  if (!data) return data;
  if (typeof data === "string") {
    const trimmed = data.trim();
    const match = trimmed.match(/^data:image\/([a-zA-Z0-9+]+);base64,([A-Za-z0-9+/=\s]+)$/i);
    if (match) {
      let ext = match[1].toLowerCase();
      if (ext === "jpeg") ext = "jpg";
      if (ext === "svg+xml") ext = "svg";
      if (!["jpg", "jpeg", "png", "webp", "gif", "svg"].includes(ext)) {
        ext = "png";
      }
      try {
        const cleanBase64 = match[2].replace(/\s+/g, "");
        const buf = Buffer.from(cleanBase64, "base64");
        if (buf.length > 0) {
          const now = /* @__PURE__ */ new Date();
          const year = now.getFullYear().toString();
          const month = String(now.getMonth() + 1).padStart(2, "0");
          const day = String(now.getDate()).padStart(2, "0");
          const uploadsBase = import_path.default.join(process.cwd(), "uploads", year, month);
          if (!import_fs.default.existsSync(uploadsBase)) {
            import_fs.default.mkdirSync(uploadsBase, { recursive: true });
          }
          ensureUploadsSecurityNode();
          const cleanPrefix = (category || "img").replace(/[^a-zA-Z0-9_-]/g, "");
          const timestamp = `${year}${month}${day}_${String(now.getHours()).padStart(2, "0")}${String(now.getMinutes()).padStart(2, "0")}${String(now.getSeconds()).padStart(2, "0")}`;
          const randomHex = Math.random().toString(36).substring(2, 8);
          const generatedFileName = `${cleanPrefix}_${timestamp}_${randomHex}.${ext}`;
          const fullPath = import_path.default.join(uploadsBase, generatedFileName);
          import_fs.default.writeFileSync(fullPath, buf);
          return `/uploads/${year}/${month}/${generatedFileName}`;
        }
      } catch (e) {
        console.warn("Notice extracting Base64 image to uploads:", e);
      }
    }
    return data;
  }
  if (Array.isArray(data)) {
    return data.map((item) => extractAndSaveBase64ImagesNode(item, category));
  }
  if (typeof data === "object") {
    const newObj = {};
    for (const key of Object.keys(data)) {
      newObj[key] = extractAndSaveBase64ImagesNode(data[key], key || category);
    }
    return newObj;
  }
  return data;
}
function validateEntityAndPermission(key, item, userContext, action = "create") {
  const cleanKey = key.startsWith("acc_app_") ? key.substring(8) : key;
  if (userContext && userContext.role === "seller") {
    if (["accounting_docs", "docs", "accountingDocuments"].includes(cleanKey)) {
      return { isValid: false, error: "\u06A9\u0627\u0631\u0628\u0631 \u0628\u0627 \u0646\u0642\u0634 \u0641\u0631\u0648\u0634\u0646\u062F\u0647 \u0645\u062C\u0627\u0632 \u0628\u0647 \u062B\u0628\u062A\u060C \u0648\u06CC\u0631\u0627\u06CC\u0634 \u06CC\u0627 \u062D\u0630\u0641 \u0627\u0633\u0646\u0627\u062F \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0646\u0645\u06CC\u200C\u0628\u0627\u0634\u062F." };
    }
    if (cleanKey === "settings") {
      return { isValid: false, error: "\u06A9\u0627\u0631\u0628\u0631 \u0628\u0627 \u0646\u0642\u0634 \u0641\u0631\u0648\u0634\u0646\u062F\u0647 \u0645\u062C\u0627\u0632 \u0628\u0647 \u062A\u063A\u06CC\u06CC\u0631 \u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u067E\u0627\u06CC\u0647\u200C\u0627\u06CC \u0633\u06CC\u0633\u062A\u0645 \u0646\u06CC\u0633\u062A." };
    }
    if (cleanKey === "users") {
      return { isValid: false, error: "\u06A9\u0627\u0631\u0628\u0631 \u0628\u0627 \u0646\u0642\u0634 \u0641\u0631\u0648\u0634\u0646\u062F\u0647 \u0645\u062C\u0627\u0632 \u0628\u0647 \u062A\u063A\u06CC\u06CC\u0631 \u0645\u0634\u062E\u0635\u0627\u062A \u06A9\u0627\u0631\u0628\u0631\u0627\u0646 \u0648 \u067E\u0631\u0633\u0646\u0644 \u0646\u06CC\u0633\u062A." };
    }
    if (["fiscal_years", "fiscalYear"].includes(cleanKey)) {
      return { isValid: false, error: "\u06A9\u0627\u0631\u0628\u0631 \u0628\u0627 \u0646\u0642\u0634 \u0641\u0631\u0648\u0634\u0646\u062F\u0647 \u0645\u062C\u0627\u0632 \u0628\u0647 \u062A\u063A\u06CC\u06CC\u0631 \u0633\u0627\u0644 \u0645\u0627\u0644\u06CC \u0646\u06CC\u0633\u062A." };
    }
    if (["accounts"].includes(cleanKey) && action !== "create") {
      return { isValid: false, error: "\u06A9\u0627\u0631\u0628\u0631 \u0628\u0627 \u0646\u0642\u0634 \u0641\u0631\u0648\u0634\u0646\u062F\u0647 \u0645\u062C\u0627\u0632 \u0628\u0647 \u062A\u063A\u06CC\u06CC\u0631 \u06CC\u0627 \u062D\u0630\u0641 \u062D\u0633\u0627\u0628\u200C\u0647\u0627\u06CC \u0628\u0627\u0646\u06A9\u06CC \u0646\u06CC\u0633\u062A." };
    }
  }
  if (action === "delete") {
    return { isValid: true };
  }
  if (!item || typeof item !== "object") {
    return { isValid: false, error: "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0627\u0631\u0633\u0627\u0644\u06CC \u0628\u0631\u0627\u06CC \u0630\u062E\u06CC\u0631\u0647\u200C\u0633\u0627\u0632\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A." };
  }
  if (Array.isArray(item)) {
    return { isValid: true };
  }
  switch (cleanKey) {
    case "invoices":
    case "proformas": {
      if (item.totalAmount !== void 0 && (isNaN(Number(item.totalAmount)) || Number(item.totalAmount) < 0)) {
        return { isValid: false, error: "\u0645\u0628\u0644\u063A \u06A9\u0644 \u0641\u0627\u06A9\u062A\u0648\u0631 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A." };
      }
      if (item.items !== void 0 && !Array.isArray(item.items)) {
        return { isValid: false, error: "\u0627\u0642\u0644\u0627\u0645 \u0641\u0627\u06A9\u062A\u0648\u0631 \u0628\u0627\u06CC\u062F \u0628\u0647 \u0635\u0648\u0631\u062A \u0622\u0631\u0627\u06CC\u0647 \u0627\u0631\u0633\u0627\u0644 \u0634\u0648\u0646\u062F." };
      }
      break;
    }
    case "transactions": {
      if (item.amount === void 0 || isNaN(Number(item.amount))) {
        return { isValid: false, error: "\u0645\u0628\u0644\u063A \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0644\u0632\u0627\u0645\u06CC \u0648 \u0628\u0627\u06CC\u062F \u0639\u062F\u062F \u0628\u0627\u0634\u062F." };
      }
      break;
    }
    case "items": {
      if (!item.name || String(item.name).trim() === "") {
        return { isValid: false, error: "\u0646\u0627\u0645 \u06A9\u0627\u0644\u0627 \u06CC\u0627 \u062E\u062F\u0645\u062A \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A." };
      }
      break;
    }
    case "counterparts": {
      if (!item.name || String(item.name).trim() === "") {
        return { isValid: false, error: "\u0646\u0627\u0645 \u0637\u0631\u0641\u200C\u062D\u0633\u0627\u0628 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A." };
      }
      break;
    }
    case "accounts": {
      if (!item.name || String(item.name).trim() === "") {
        return { isValid: false, error: "\u0639\u0646\u0648\u0627\u0646 \u062D\u0633\u0627\u0628 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A." };
      }
      break;
    }
    case "docs":
    case "accounting_docs":
    case "accountingDocuments": {
      if (item.lines !== void 0 && !Array.isArray(item.lines)) {
        return { isValid: false, error: "\u0631\u062F\u06CC\u0641\u200C\u0647\u0627\u06CC \u0633\u0646\u062F \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0628\u0627\u06CC\u062F \u0628\u0647 \u0635\u0648\u0631\u062A \u0622\u0631\u0627\u06CC\u0647 \u0627\u0631\u0633\u0627\u0644 \u0634\u0648\u0646\u062F." };
      }
      break;
    }
    case "users": {
      if (!item.username || String(item.username).trim() === "") {
        return { isValid: false, error: "\u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A." };
      }
      break;
    }
  }
  return { isValid: true };
}
async function saveOrUpdateItemStockRelational(conn, itemId, qtyChange, itmDetails, isPurchase) {
  const [rows] = await conn.execute("SELECT * FROM items WHERE id = ?", [itemId]);
  let existingItem = null;
  if (Array.isArray(rows) && rows.length > 0) {
    existingItem = rows[0];
  }
  const name = existingItem ? existingItem.name : String(itmDetails.name || itmDetails.title || "\u06A9\u0627\u0644\u0627").trim();
  const code = existingItem ? existingItem.code : itmDetails.code ? String(itmDetails.code).trim() : null;
  const type = existingItem ? existingItem.type : itmDetails.type || "kala";
  const color = existingItem ? existingItem.color : itmDetails.color || null;
  const unit = existingItem ? existingItem.unit : itmDetails.unit || "\u0639\u062F\u062F";
  const oldQty = existingItem ? Number(existingItem.qty) : 0;
  const newQty = oldQty + qtyChange;
  const initialQty = existingItem ? Number(existingItem.initial_qty) : 0;
  let lastPurchasePrice = existingItem ? Number(existingItem.last_purchase_price) : 0;
  let lastSalePrice = existingItem ? Number(existingItem.last_sale_price) : 0;
  if (isPurchase) {
    lastPurchasePrice = Number(itmDetails.unitPrice || itmDetails.unit_price || itmDetails.price) || lastPurchasePrice;
  } else {
    lastSalePrice = Number(itmDetails.unitPrice || itmDetails.unit_price || itmDetails.price) || lastSalePrice;
  }
  const minQtyAlarm = existingItem ? Number(existingItem.min_qty_alarm) : 0;
  const categoryName = existingItem ? existingItem.category_name : null;
  const parentCategory = existingItem ? existingItem.parent_category : null;
  const subCategory = existingItem ? existingItem.sub_category : null;
  const commissionPercent = existingItem ? Number(existingItem.commission_percent) : 0;
  const setupDate = existingItem ? existingItem.setup_date : null;
  const warehouseId = existingItem ? existingItem.warehouse_id : null;
  const fiscalYearId = existingItem ? existingItem.fiscal_year_id : null;
  const createdBy = existingItem ? existingItem.created_by : "system";
  const itemSql = `
    INSERT INTO items (
      id, warehouse_id, name, code, type, color, unit, qty, initial_qty, last_purchase_price, last_sale_price,
      min_qty_alarm, category_name, parent_category, sub_category, commission_percent, setup_date,
      fiscal_year_id, created_by, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?, ?,
      ?, ?, CURRENT_TIMESTAMP
    ) ON DUPLICATE KEY UPDATE
      warehouse_id = VALUES(warehouse_id),
      name = VALUES(name),
      code = VALUES(code),
      type = VALUES(type),
      color = VALUES(color),
      unit = VALUES(unit),
      qty = VALUES(qty),
      initial_qty = VALUES(initial_qty),
      last_purchase_price = VALUES(last_purchase_price),
      last_sale_price = VALUES(last_sale_price),
      min_qty_alarm = VALUES(min_qty_alarm),
      category_name = VALUES(category_name),
      parent_category = VALUES(parent_category),
      sub_category = VALUES(sub_category),
      commission_percent = VALUES(commission_percent),
      setup_date = VALUES(setup_date),
      fiscal_year_id = VALUES(fiscal_year_id),
      created_by = VALUES(created_by),
      updated_at = CURRENT_TIMESTAMP
  `;
  await conn.execute(itemSql, [
    itemId,
    warehouseId,
    name,
    code,
    type,
    color,
    unit,
    newQty,
    initialQty,
    lastPurchasePrice,
    lastSalePrice,
    minQtyAlarm,
    categoryName,
    parentCategory,
    subCategory,
    commissionPercent,
    setupDate,
    fiscalYearId,
    createdBy
  ]);
}
async function adjustInventoryForInvoice(conn, invoiceId, isDeleted = false, incomingInvoiceObj) {
  const [oldInvRows] = await conn.execute("SELECT type, is_proforma, is_deleted FROM invoices WHERE id = ?", [invoiceId]);
  let oldType = null;
  let oldIsProforma = false;
  let oldIsDeleted = false;
  if (Array.isArray(oldInvRows) && oldInvRows.length > 0) {
    const oldInv = oldInvRows[0];
    oldType = oldInv.type || "sale";
    oldIsProforma = oldInv.is_proforma === 1 || oldInv.is_proforma === true || String(oldInv.is_proforma) === "1";
    oldIsDeleted = oldInv.is_deleted === 1 || oldInv.is_deleted === true || String(oldInv.is_deleted) === "1";
  }
  const [oldItemRows] = await conn.execute("SELECT item_id, qty, type FROM invoice_items WHERE invoice_id = ?", [invoiceId]);
  const oldItems = Array.isArray(oldItemRows) ? oldItemRows : [];
  const newType = incomingInvoiceObj ? incomingInvoiceObj.type || "sale" : oldType;
  const newIsProforma = incomingInvoiceObj ? incomingInvoiceObj.isProforma ? true : false : oldIsProforma;
  const newIsDeleted = isDeleted;
  if (oldType !== null) {
    const isOldActive = !oldIsDeleted && !oldIsProforma && (oldType === "buy" || oldType === "purchase" || oldType === "sale");
    const isNewActive = !newIsDeleted && !newIsProforma && (newType === "buy" || newType === "purchase" || newType === "sale");
    if (isOldActive === isNewActive && oldType === newType) {
      if (!isOldActive) {
        return;
      }
      const oldItemMap = /* @__PURE__ */ new Map();
      for (const itm of oldItems) {
        const itemId = itm.item_id;
        const qty = Number(itm.qty) || 0;
        const itemType = itm.type || "kala";
        if (itemId && qty > 0 && itemType === "kala") {
          oldItemMap.set(itemId, (oldItemMap.get(itemId) || 0) + qty);
        }
      }
      const newItemMap = /* @__PURE__ */ new Map();
      if (incomingInvoiceObj && Array.isArray(incomingInvoiceObj.items)) {
        for (const itm of incomingInvoiceObj.items) {
          if (!itm || typeof itm !== "object") continue;
          const itemId = itm.itemId || itm.id || null;
          const qty = Number(itm.qty !== void 0 ? itm.qty : itm.quantity !== void 0 ? itm.quantity : 1) || 0;
          const itemType = itm.type || "kala";
          if (itemId && qty > 0 && itemType === "kala") {
            newItemMap.set(itemId, (newItemMap.get(itemId) || 0) + qty);
          }
        }
      }
      let isSame = oldItemMap.size === newItemMap.size;
      if (isSame) {
        for (const [k, v] of oldItemMap.entries()) {
          if (newItemMap.get(k) !== v) {
            isSame = false;
            break;
          }
        }
      }
      if (isSame) {
        return;
      }
    }
  }
  if (oldType && !oldIsProforma && !oldIsDeleted) {
    for (const oldItm of oldItems) {
      const itemId = oldItm.item_id;
      const qty = Number(oldItm.qty) || 0;
      const itemType = oldItm.type || "kala";
      if (itemId && qty > 0 && itemType === "kala") {
        if (oldType === "buy" || oldType === "purchase") {
          await saveOrUpdateItemStockRelational(conn, itemId, -qty, oldItm, false);
        } else if (oldType === "sale") {
          await saveOrUpdateItemStockRelational(conn, itemId, qty, oldItm, false);
        }
      }
    }
  }
  if (newType && !newIsProforma && !newIsDeleted && incomingInvoiceObj && Array.isArray(incomingInvoiceObj.items)) {
    for (const itm of incomingInvoiceObj.items) {
      if (!itm || typeof itm !== "object") continue;
      const itemId = itm.itemId || itm.id || null;
      const qty = Number(itm.qty !== void 0 ? itm.qty : itm.quantity !== void 0 ? itm.quantity : 1) || 0;
      const itemType = itm.type || "kala";
      if (itemId && qty > 0 && itemType === "kala") {
        const isPurchase = newType === "buy" || newType === "purchase";
        if (isPurchase) {
          await saveOrUpdateItemStockRelational(conn, itemId, qty, itm, true);
        } else if (newType === "sale") {
          await saveOrUpdateItemStockRelational(conn, itemId, -qty, itm, false);
        }
      }
    }
  }
  try {
    const [itemRows] = await conn.execute("SELECT * FROM items ORDER BY id DESC");
    if (Array.isArray(itemRows)) {
      const itemList = itemRows.map((r) => {
        let obj = {};
        if (r.raw_json) {
          try {
            obj = typeof r.raw_json === "string" ? JSON.parse(r.raw_json) : r.raw_json;
          } catch (e) {
            try {
              obj = JSON.parse(JSON.stringify(r.raw_json));
            } catch {
            }
          }
        }
        return {
          ...obj,
          id: r.id,
          name: r.name,
          code: r.code,
          type: r.type || "kala",
          qty: Number(r.qty) || 0,
          stock: Number(r.qty) || 0,
          initialQty: Number(r.initial_qty) || 0,
          purchasePrice: Number(r.last_purchase_price) || 0,
          lastPurchasePrice: Number(r.last_purchase_price) || 0,
          salePrice: Number(r.last_sale_price) || 0,
          lastSalePrice: Number(r.last_sale_price) || 0,
          minStock: Number(r.min_qty_alarm) || 0,
          minQtyAlarm: Number(r.min_qty_alarm) || 0,
          category: r.category_name,
          categoryName: r.category_name,
          parentCategory: r.parent_category,
          subCategory: r.sub_category,
          commissionPercent: Number(r.commission_percent) || 0,
          setupDate: r.setup_date,
          warehouseId: r.warehouse_id,
          fiscalYearId: r.fiscal_year_id,
          createdBy: r.created_by,
          createdAt: r.created_at,
          updatedAt: r.updated_at
        };
      });
      if (serverMemoryStateCache) {
        serverMemoryStateCache.items = itemList;
        serverMemoryStateCache.acc_app_items = itemList;
      }
      const jsonStr = JSON.stringify(itemList);
      await conn.execute(
        "INSERT INTO app_state (state_key, state_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE state_value = VALUES(state_value), updated_at = CURRENT_TIMESTAMP",
        ["items", jsonStr]
      );
      await conn.execute(
        "INSERT INTO app_state (state_key, state_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE state_value = VALUES(state_value), updated_at = CURRENT_TIMESTAMP",
        ["acc_app_items", jsonStr]
      );
    }
  } catch (err) {
    console.error("Error syncing items cache and app_state:", err.message);
  }
}
async function saveSingleInvoiceRelational(conn, inv, userContext) {
  if (!inv || typeof inv !== "object") return;
  const id = String(inv.id || `inv-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`);
  await adjustInventoryForInvoice(conn, id, false, inv);
  const invoiceNumber = inv.invoiceNumber ? String(inv.invoiceNumber).trim() : id;
  const type = inv.type || "sale";
  const isProforma = inv.isProforma ? 1 : 0;
  const counterpartId = inv.counterpartId || inv.customerId || null;
  const counterpartName = inv.counterpartName || inv.customerName || null;
  const invoiceDate = inv.date || (/* @__PURE__ */ new Date()).toISOString().substring(0, 10);
  const dueDate = inv.dueDate || inv.paymentDate || null;
  const subtotal = Number(inv.subtotal) || 0;
  const discountAmount = Number(inv.discount || inv.discountAmount) || 0;
  const taxAmount = Number(inv.tax || inv.taxAmount) || 0;
  const totalAmount = Number(inv.totalAmount || inv.total) || subtotal - discountAmount + taxAmount;
  const paidAmount = Number(inv.paidAmount || inv.deposit || inv.paymentAmount) || 0;
  const notes = inv.notes || inv.description || null;
  const isUrgent = inv.isUrgent ? 1 : 0;
  const urgentType = inv.urgentType || null;
  const shippingMethod = inv.shippingMethod || inv.paymentMethod || "cash";
  const acquaintanceMethod = inv.acquaintanceMethod || null;
  const docId = inv.docId || null;
  const cogsDocId = inv.cogsDocId || null;
  const cogsTotal = Number(inv.cogsTotal) || 0;
  const isReturn = inv.isReturn ? 1 : 0;
  const returnRefInvoiceId = inv.returnRefInvoiceId || null;
  const customIcons = inv.customIcons ? JSON.stringify(inv.customIcons) : null;
  const attachments = inv.attachments ? JSON.stringify(inv.attachments) : null;
  const paymentSlips = inv.paymentSlips ? JSON.stringify(inv.paymentSlips) : null;
  const history = inv.history ? JSON.stringify(inv.history) : null;
  const allocations = inv.allocations ? JSON.stringify(inv.allocations) : null;
  const createdBy = inv.createdBy || (userContext?.username || "system");
  const createdById = userContext?.userId || null;
  const createdByPhone = userContext?.phone || null;
  const fiscalYearId = inv.fiscalYearId || null;
  const invoiceSql = `
    INSERT INTO invoices (
      id, invoice_number, type, date, counterpart_id, counterpart_name, counterpart_phone,
      counterpart_address, total_amount, tax, deposit, discount, payment_amount, payment_date,
      description, is_proforma, is_urgent, urgent_type, shipping_method, acquaintance_method,
      doc_id, cogs_doc_id, cogs_total, is_return, return_ref_invoice_id, is_deleted,
      custom_icons, attachments, payment_slips, history, allocations, fiscal_year_id,
      created_by, created_by_id, created_by_phone, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?, 0,
      ?, ?, ?, ?, ?, ?,
      ?, ?, ?, CURRENT_TIMESTAMP
    ) ON DUPLICATE KEY UPDATE
      invoice_number = VALUES(invoice_number),
      type = VALUES(type),
      date = VALUES(date),
      counterpart_id = VALUES(counterpart_id),
      counterpart_name = VALUES(counterpart_name),
      counterpart_phone = VALUES(counterpart_phone),
      counterpart_address = VALUES(counterpart_address),
      total_amount = VALUES(total_amount),
      tax = VALUES(tax),
      deposit = VALUES(deposit),
      discount = VALUES(discount),
      payment_amount = VALUES(payment_amount),
      payment_date = VALUES(payment_date),
      description = VALUES(description),
      is_proforma = VALUES(is_proforma),
      is_urgent = VALUES(is_urgent),
      urgent_type = VALUES(urgent_type),
      shipping_method = VALUES(shipping_method),
      acquaintance_method = VALUES(acquaintance_method),
      doc_id = VALUES(doc_id),
      cogs_doc_id = VALUES(cogs_doc_id),
      cogs_total = VALUES(cogs_total),
      is_return = VALUES(is_return),
      return_ref_invoice_id = VALUES(return_ref_invoice_id),
      is_deleted = 0,
      custom_icons = VALUES(custom_icons),
      attachments = VALUES(attachments),
      payment_slips = VALUES(payment_slips),
      history = VALUES(history),
      allocations = VALUES(allocations),
      fiscal_year_id = VALUES(fiscal_year_id),
      created_by = VALUES(created_by),
      created_by_id = VALUES(created_by_id),
      created_by_phone = VALUES(created_by_phone),
      updated_at = CURRENT_TIMESTAMP
  `;
  await conn.execute(invoiceSql, [
    id,
    invoiceNumber,
    type,
    invoiceDate,
    counterpartId,
    counterpartName,
    inv.buyerPhone || inv.customerPhone || null,
    inv.buyerAddress || inv.customerAddress || null,
    totalAmount,
    taxAmount,
    paidAmount,
    discountAmount,
    paidAmount,
    dueDate,
    notes,
    isProforma,
    isUrgent,
    urgentType,
    shippingMethod,
    acquaintanceMethod,
    docId,
    cogsDocId,
    cogsTotal,
    isReturn,
    returnRefInvoiceId,
    customIcons,
    attachments,
    paymentSlips,
    history,
    allocations,
    fiscalYearId,
    createdBy,
    createdById,
    createdByPhone
  ]);
  const existingRows = await conn.execute("SELECT id FROM invoice_items WHERE invoice_id = ?", [id]);
  const existingItemIds = /* @__PURE__ */ new Set();
  if (Array.isArray(existingRows) && Array.isArray(existingRows[0])) {
    for (const r of existingRows[0]) {
      if (r && r.id) existingItemIds.add(String(r.id));
    }
  }
  const incomingItemIds = /* @__PURE__ */ new Set();
  if (Array.isArray(inv.items) && inv.items.length > 0) {
    const itemInsertSql = `
      INSERT INTO invoice_items (
        id, invoice_id, item_id, name, type, color, unit, qty,
        unit_price, total_price, remarks, sort_order, fiscal_year_id, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const itemUpdateSql = `
      UPDATE invoice_items SET
        item_id = ?, name = ?, type = ?, color = ?, unit = ?, qty = ?,
        unit_price = ?, total_price = ?, remarks = ?, sort_order = ?,
        fiscal_year_id = ?, created_by = ?
      WHERE id = ? AND invoice_id = ?
    `;
    for (let idx = 0; idx < inv.items.length; idx++) {
      const itm = inv.items[idx];
      if (!itm || typeof itm !== "object") continue;
      const itmId = String(itm.id || `${id}-itm-${idx + 1}`);
      incomingItemIds.add(itmId);
      const itemId = itm.itemId || itm.id || null;
      const itemName = itm.name || itm.title || itm.itemName || "\u06A9\u0627\u0644\u0627/\u062E\u062F\u0645\u062A";
      const itemType = itm.type || "kala";
      const itemColor = itm.color || null;
      const itemUnit = itm.unit || "\u0639\u062F\u062F";
      const itemQty = Number(itm.qty !== void 0 ? itm.qty : itm.quantity !== void 0 ? itm.quantity : 1) || 1;
      const itemUnitPrice = Number(itm.unitPrice || itm.unit_price || itm.price) || 0;
      const itemTotalPrice = Number(itm.totalPrice || itm.total_price || itm.total) || itemQty * itemUnitPrice;
      const itemRemarks = itm.remarks || itm.description || null;
      if (existingItemIds.has(itmId)) {
        await conn.execute(itemUpdateSql, [
          itemId,
          itemName,
          itemType,
          itemColor,
          itemUnit,
          itemQty,
          itemUnitPrice,
          itemTotalPrice,
          itemRemarks,
          idx,
          fiscalYearId,
          createdBy,
          itmId,
          id
        ]);
      } else {
        await conn.execute(itemInsertSql, [
          itmId,
          id,
          itemId,
          itemName,
          itemType,
          itemColor,
          itemUnit,
          itemQty,
          itemUnitPrice,
          itemTotalPrice,
          itemRemarks,
          idx,
          fiscalYearId,
          createdBy
        ]);
      }
    }
  }
  for (const oldId of existingItemIds) {
    if (!incomingItemIds.has(oldId)) {
      await conn.execute("DELETE FROM invoice_items WHERE id = ? AND invoice_id = ?", [oldId, id]);
    }
  }
}
async function deleteSingleInvoiceRelational(conn, id) {
  const cleanId = String(id).trim();
  await adjustInventoryForInvoice(conn, cleanId, true);
  await conn.execute("UPDATE invoices SET is_deleted = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ? OR invoice_number = ?", [cleanId, cleanId]);
}
async function saveSingleTransactionRelational(conn, tx, userContext) {
  if (!tx || typeof tx !== "object") return;
  const id = String(tx.id || `tx-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`);
  const txDate = tx.date || (/* @__PURE__ */ new Date()).toISOString().substring(0, 10);
  const type = tx.type || "deposit";
  const amount = Number(tx.amount) || 0;
  const accountId = tx.accountId || null;
  const counterpartId = tx.counterpartId || null;
  const categoryId = tx.categoryId || tx.category || null;
  const description = tx.description || null;
  const trackingNumber = tx.trackingNumber || tx.refCode || null;
  const fiscalYearId = tx.fiscalYearId || null;
  const createdBy = tx.createdBy || (userContext?.username || "system");
  const txSql = `
    INSERT INTO transactions (
      id, date, time, amount, type, description, is_registered, category_parent,
      category_child, user_description, is_duplicate, duplicate_reason, tracking_number,
      reference_code, registered_date, account_id, partner_id, pending_deposit_id,
      borrower_id, borrower_name, loan_type, counterpart_id, counterpart_name,
      invoice_id, doc_id, attachments, is_edited, edited_by, edited_by_id, edited_at,
      edit_history, is_deleted, fiscal_year_id, created_by, created_by_id, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?, ?, ?,
      ?, 0, ?, ?, ?, CURRENT_TIMESTAMP
    ) ON DUPLICATE KEY UPDATE
      date = VALUES(date),
      time = VALUES(time),
      amount = VALUES(amount),
      type = VALUES(type),
      description = VALUES(description),
      is_registered = VALUES(is_registered),
      category_parent = VALUES(category_parent),
      category_child = VALUES(category_child),
      user_description = VALUES(user_description),
      is_duplicate = VALUES(is_duplicate),
      duplicate_reason = VALUES(duplicate_reason),
      tracking_number = VALUES(tracking_number),
      reference_code = VALUES(reference_code),
      registered_date = VALUES(registered_date),
      account_id = VALUES(account_id),
      partner_id = VALUES(partner_id),
      pending_deposit_id = VALUES(pending_deposit_id),
      borrower_id = VALUES(borrower_id),
      borrower_name = VALUES(borrower_name),
      loan_type = VALUES(loan_type),
      counterpart_id = VALUES(counterpart_id),
      counterpart_name = VALUES(counterpart_name),
      invoice_id = VALUES(invoice_id),
      doc_id = VALUES(doc_id),
      attachments = VALUES(attachments),
      is_edited = VALUES(is_edited),
      edited_by = VALUES(edited_by),
      edited_by_id = VALUES(edited_by_id),
      edited_at = VALUES(edited_at),
      edit_history = VALUES(edit_history),
      is_deleted = 0,
      fiscal_year_id = VALUES(fiscal_year_id),
      updated_at = CURRENT_TIMESTAMP
  `;
  const time = tx.time || null;
  const isRegistered = tx.isRegistered ? 1 : 0;
  const categoryParent = tx.categoryParent || tx.category_parent || categoryId || null;
  const categoryChild = tx.categoryChild || tx.category_child || null;
  const userDescription = tx.userDescription || tx.user_description || null;
  const isDuplicate = tx.isDuplicate ? 1 : 0;
  const duplicateReason = tx.duplicateReason || tx.duplicate_reason || null;
  const referenceCode = tx.referenceCode || tx.reference_code || tx.refCode || null;
  const registeredDate = tx.registeredDate || tx.registered_date || null;
  const partnerId = tx.partnerId || tx.partner_id || null;
  const pendingDepositId = tx.pendingDepositId || tx.pending_deposit_id || null;
  const borrowerId = tx.borrowerId || tx.borrower_id || null;
  const borrowerName = tx.borrowerName || tx.borrower_name || null;
  const loanType = tx.loanType || tx.loan_type || null;
  const counterpartName = tx.counterpartName || tx.counterpart_name || null;
  const invoiceId = tx.invoiceId || tx.invoice_id || null;
  const docId = tx.docId || tx.doc_id || null;
  const attachments = tx.attachments ? JSON.stringify(tx.attachments) : null;
  const isEdited = tx.isEdited ? 1 : 0;
  const editedBy = tx.editedBy || tx.edited_by || null;
  const editedById = tx.editedById || tx.edited_by_id || null;
  const editedAt = tx.editedAt || tx.edited_at || null;
  const editHistory = tx.editHistory ? JSON.stringify(tx.editHistory) : null;
  const createdById = tx.createdById || tx.created_by_id || userContext?.userId || null;
  await conn.execute(txSql, [
    id,
    txDate,
    time,
    amount,
    type,
    description,
    isRegistered,
    categoryParent,
    categoryChild,
    userDescription,
    isDuplicate,
    duplicateReason,
    trackingNumber,
    referenceCode,
    registeredDate,
    accountId,
    partnerId,
    pendingDepositId,
    borrowerId,
    borrowerName,
    loanType,
    counterpartId,
    counterpartName,
    invoiceId,
    docId,
    attachments,
    isEdited,
    editedBy,
    editedById,
    editedAt,
    editHistory,
    fiscalYearId,
    createdBy,
    createdById
  ]);
}
async function deleteSingleTransactionRelational(conn, id) {
  const cleanId = String(id).trim();
  await conn.execute("UPDATE transactions SET is_deleted = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [cleanId]);
}
async function saveSingleItemRelational(conn, it, userContext) {
  if (!it || typeof it !== "object") return;
  const id = String(it.id || `item-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`);
  const name = String(it.name || it.title || "\u06A9\u0627\u0644\u0627").trim();
  const code = it.code ? String(it.code).trim() : null;
  const type = it.type || "kala";
  const color = it.color || null;
  const unit = it.unit || "\u0639\u062F\u062F";
  const qty = Number(it.qty !== void 0 ? it.qty : it.stock !== void 0 ? it.stock : it.quantity) || 0;
  const initialQty = Number(it.initialQty || it.initial_qty) || 0;
  const lastPurchasePrice = Number(it.lastPurchasePrice || it.last_purchase_price || it.purchasePrice || it.buyPrice) || 0;
  const lastSalePrice = Number(it.lastSalePrice || it.last_sale_price || it.salePrice || it.price) || 0;
  const minQtyAlarm = Number(it.minQtyAlarm || it.min_qty_alarm || it.minStock) || 0;
  const categoryName = it.categoryName || it.category_name || it.category || null;
  const parentCategory = it.parentCategory || it.parent_category || null;
  const subCategory = it.subCategory || it.sub_category || null;
  const commissionPercent = Number(it.commissionPercent || it.commission_percent) || 0;
  const setupDate = it.setupDate || it.setup_date || null;
  const warehouseId = it.warehouseId || null;
  const fiscalYearId = it.fiscalYearId || null;
  const createdBy = it.createdBy || (userContext?.username || "system");
  const itemSql = `
    INSERT INTO items (
      id, warehouse_id, name, code, type, color, unit, qty, initial_qty, last_purchase_price, last_sale_price,
      min_qty_alarm, category_name, parent_category, sub_category, commission_percent, setup_date,
      fiscal_year_id, created_by, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?, ?,
      ?, ?, CURRENT_TIMESTAMP
    ) ON DUPLICATE KEY UPDATE
      warehouse_id = VALUES(warehouse_id),
      name = VALUES(name),
      code = VALUES(code),
      type = VALUES(type),
      color = VALUES(color),
      unit = VALUES(unit),
      qty = qty + (VALUES(initial_qty) - initial_qty),
      initial_qty = VALUES(initial_qty),
      last_purchase_price = VALUES(last_purchase_price),
      last_sale_price = VALUES(last_sale_price),
      min_qty_alarm = VALUES(min_qty_alarm),
      category_name = VALUES(category_name),
      parent_category = VALUES(parent_category),
      sub_category = VALUES(sub_category),
      commission_percent = VALUES(commission_percent),
      setup_date = VALUES(setup_date),
      fiscal_year_id = VALUES(fiscal_year_id),
      created_by = VALUES(created_by),
      updated_at = CURRENT_TIMESTAMP
  `;
  await conn.execute(itemSql, [
    id,
    warehouseId,
    name,
    code,
    type,
    color,
    unit,
    qty,
    initialQty,
    lastPurchasePrice,
    lastSalePrice,
    minQtyAlarm,
    categoryName,
    parentCategory,
    subCategory,
    commissionPercent,
    setupDate,
    fiscalYearId,
    createdBy
  ]);
}
async function deleteSingleItemRelational(conn, id) {
  const cleanId = String(id).trim();
  await conn.execute("DELETE FROM items WHERE id = ? OR code = ?", [cleanId, cleanId]);
}
async function saveSingleCounterpartRelational(conn, cp, userContext) {
  if (!cp || typeof cp !== "object") return;
  const id = String(cp.id || `cp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`);
  const name = String(cp.name || cp.title || "\u0637\u0631\u0641\u200C\u062D\u0633\u0627\u0628").trim();
  const code = cp.code ? String(cp.code).trim() : null;
  const type = cp.type || "customer";
  const phone = cp.phone || null;
  const mobile = cp.mobile || null;
  const nationalId = cp.nationalId || null;
  const economicCode = cp.economicCode || null;
  const address = cp.address || null;
  const postalCode = cp.postalCode || null;
  const initialBalance = Number(cp.initialBalance) || 0;
  const currentBalance = Number(cp.currentBalance || cp.balance) || 0;
  const createdBy = cp.createdBy || (userContext?.username || "system");
  const rawJson = JSON.stringify(cp);
  const cpSql = `
    INSERT INTO counterparts (
      id, name, code, type, phone, mobile, national_id, economic_code,
      address, postal_code, initial_balance, current_balance, created_by,
      raw_json, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?,
      ?, CURRENT_TIMESTAMP
    ) ON DUPLICATE KEY UPDATE
      name = VALUES(name),
      code = VALUES(code),
      type = VALUES(type),
      phone = VALUES(phone),
      mobile = VALUES(mobile),
      national_id = VALUES(national_id),
      economic_code = VALUES(economic_code),
      address = VALUES(address),
      postal_code = VALUES(postal_code),
      initial_balance = VALUES(initial_balance),
      current_balance = VALUES(current_balance),
      created_by = VALUES(created_by),
      raw_json = VALUES(raw_json),
      updated_at = CURRENT_TIMESTAMP
  `;
  await conn.execute(cpSql, [
    id,
    name,
    code,
    type,
    phone,
    mobile,
    nationalId,
    economicCode,
    address,
    postalCode,
    initialBalance,
    currentBalance,
    createdBy,
    rawJson
  ]);
}
async function deleteSingleCounterpartRelational(conn, id) {
  const cleanId = String(id).trim();
  await conn.execute("DELETE FROM counterparts WHERE id = ? OR code = ?", [cleanId, cleanId]);
}
async function saveSingleAccountRelational(conn, acc, userContext) {
  if (!acc || typeof acc !== "object") return;
  const id = String(acc.id || `acc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`);
  const name = String(acc.name || acc.title || "\u062D\u0633\u0627\u0628").trim();
  const type = acc.type || "bank";
  const bankName = acc.bankName || null;
  const accountNumber = acc.accountNumber || null;
  const cardNumber = acc.cardNumber || null;
  const shabaNumber = acc.shabaNumber || null;
  const balance = Number(acc.balance) || 0;
  const initialBalance = Number(acc.initialBalance) || 0;
  const createdBy = acc.createdBy || (userContext?.username || "system");
  const rawJson = JSON.stringify(acc);
  const accSql = `
    INSERT INTO accounts (
      id, name, type, bank_name, account_number, card_number, shaba_number,
      balance, initial_balance, created_by, raw_json, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, CURRENT_TIMESTAMP
    ) ON DUPLICATE KEY UPDATE
      name = VALUES(name),
      type = VALUES(type),
      bank_name = VALUES(bank_name),
      account_number = VALUES(account_number),
      card_number = VALUES(card_number),
      shaba_number = VALUES(shaba_number),
      balance = VALUES(balance),
      initial_balance = VALUES(initial_balance),
      created_by = VALUES(created_by),
      raw_json = VALUES(raw_json),
      updated_at = CURRENT_TIMESTAMP
  `;
  await conn.execute(accSql, [
    id,
    name,
    type,
    bankName,
    accountNumber,
    cardNumber,
    shabaNumber,
    balance,
    initialBalance,
    createdBy,
    rawJson
  ]);
}
async function deleteSingleAccountRelational(conn, id) {
  const cleanId = String(id).trim();
  await conn.execute("DELETE FROM accounts WHERE id = ?", [cleanId]);
}
async function saveSingleWarehouseRelational(conn, wh, userContext) {
  if (!wh || typeof wh !== "object") return;
  const id = String(wh.id || `wh-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`);
  const name = String(wh.name || wh.title || "\u0627\u0646\u0628\u0627\u0631").trim();
  const code = wh.code ? String(wh.code).trim() : null;
  const address = wh.address || null;
  const manager = wh.manager || null;
  const phone = wh.phone || null;
  const createdBy = wh.createdBy || (userContext?.username || "system");
  const rawJson = JSON.stringify(wh);
  const whSql = `
    INSERT INTO warehouses (
      id, name, code, address, manager, phone, created_by, raw_json, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP
    ) ON DUPLICATE KEY UPDATE
      name = VALUES(name),
      code = VALUES(code),
      address = VALUES(address),
      manager = VALUES(manager),
      phone = VALUES(phone),
      created_by = VALUES(created_by),
      raw_json = VALUES(raw_json),
      updated_at = CURRENT_TIMESTAMP
  `;
  await conn.execute(whSql, [id, name, code, address, manager, phone, createdBy, rawJson]);
}
async function deleteSingleWarehouseRelational(conn, id) {
  const cleanId = String(id).trim();
  await conn.execute("DELETE FROM warehouses WHERE id = ?", [cleanId]);
}
async function saveSingleCategoryRelational(conn, cat, userContext) {
  if (!cat || typeof cat !== "object") return;
  const id = String(cat.id || `cat-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`);
  const name = String(cat.name || cat.title || "\u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC").trim();
  const type = cat.type || "general";
  const icon = cat.icon || null;
  const color = cat.color || null;
  const parentId = cat.parentId || null;
  const createdBy = cat.createdBy || (userContext?.username || "system");
  const rawJson = JSON.stringify(cat);
  const catSql = `
    INSERT INTO categories (
      id, name, type, icon, color, parent_id, created_by, raw_json, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP
    ) ON DUPLICATE KEY UPDATE
      name = VALUES(name),
      type = VALUES(type),
      icon = VALUES(icon),
      color = VALUES(color),
      parent_id = VALUES(parent_id),
      created_by = VALUES(created_by),
      raw_json = VALUES(raw_json),
      updated_at = CURRENT_TIMESTAMP
  `;
  await conn.execute(catSql, [id, name, type, icon, color, parentId, createdBy, rawJson]);
}
async function deleteSingleCategoryRelational(conn, id) {
  const cleanId = String(id).trim();
  await conn.execute("DELETE FROM categories WHERE id = ?", [cleanId]);
}
async function saveSingleAccountingDocRelational(conn, doc, userContext) {
  if (!doc || typeof doc !== "object") return;
  const id = String(doc.id || `doc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`);
  const docNumber = doc.docNumber ? Number(doc.docNumber) : doc.doc_number ? Number(doc.doc_number) : Math.floor(Date.now() / 1e3);
  const docDate = doc.date || doc.doc_date || (/* @__PURE__ */ new Date()).toISOString().substring(0, 10);
  const description = doc.description || null;
  const isArchived = doc.isArchived ? 1 : 0;
  const isManual = doc.isManual ? 1 : 0;
  const status = doc.status || "posted";
  const operationType = doc.operationType || doc.operation_type || null;
  const invoiceId = doc.invoiceId || doc.invoice_id || null;
  const txId = doc.txId || doc.tx_id || null;
  const refDocId = doc.refDocId || doc.ref_doc_id || null;
  const idempotencyKey = doc.idempotencyKey || doc.idempotency_key || null;
  const actorId = doc.actorId || doc.actor_id || null;
  const actorName = doc.actorName || doc.actor_name || null;
  const createdBy = doc.createdBy || (userContext?.username || "system");
  const fiscalYearId = doc.fiscalYearId || null;
  let calculatedDebit = 0;
  let calculatedCredit = 0;
  if (Array.isArray(doc.lines) && doc.lines.length > 0) {
    for (const ln of doc.lines) {
      calculatedDebit += Number(ln.debit) || 0;
      calculatedCredit += Number(ln.credit) || 0;
    }
  } else {
    calculatedDebit = Number(doc.totalDebit) || 0;
    calculatedCredit = Number(doc.totalCredit) || 0;
  }
  if (Math.abs(calculatedDebit - calculatedCredit) > 0.01) {
    throw new Error(`\u0633\u0646\u062F \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0646\u0627\u0645\u062A\u0648\u0627\u0632\u0646 \u0627\u0633\u062A: \u0645\u062C\u0645\u0648\u0639 \u0628\u062F\u0647\u06A9\u0627\u0631 (${calculatedDebit.toLocaleString("fa-IR")}) \u0628\u0627 \u0645\u062C\u0645\u0648\u0639 \u0628\u0633\u062A\u0627\u0646\u06A9\u0627\u0631 (${calculatedCredit.toLocaleString("fa-IR")}) \u0628\u0631\u0627\u0628\u0631 \u0646\u06CC\u0633\u062A.`);
  }
  const docSql = `
    INSERT INTO accounting_docs (
      id, doc_number, date, description, is_archived, is_manual, status,
      operation_type, invoice_id, tx_id, ref_doc_id, idempotency_key,
      actor_id, actor_name, is_deleted, fiscal_year_id, created_by, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?,
      ?, ?, 0, ?, ?, CURRENT_TIMESTAMP
    ) ON DUPLICATE KEY UPDATE
      doc_number = VALUES(doc_number),
      date = VALUES(date),
      description = VALUES(description),
      is_archived = VALUES(is_archived),
      is_manual = VALUES(is_manual),
      status = VALUES(status),
      operation_type = VALUES(operation_type),
      invoice_id = VALUES(invoice_id),
      tx_id = VALUES(tx_id),
      ref_doc_id = VALUES(ref_doc_id),
      idempotency_key = VALUES(idempotency_key),
      actor_id = VALUES(actor_id),
      actor_name = VALUES(actor_name),
      is_deleted = 0,
      fiscal_year_id = VALUES(fiscal_year_id),
      updated_at = CURRENT_TIMESTAMP
  `;
  await conn.execute(docSql, [
    id,
    docNumber,
    docDate,
    description,
    isArchived,
    isManual,
    status,
    operationType,
    invoiceId,
    txId,
    refDocId,
    idempotencyKey,
    actorId,
    actorName,
    fiscalYearId,
    createdBy
  ]);
  const existingLineRows = await conn.execute("SELECT id FROM accounting_doc_lines WHERE doc_id = ?", [id]);
  const existingLineIds = /* @__PURE__ */ new Set();
  if (Array.isArray(existingLineRows) && Array.isArray(existingLineRows[0])) {
    for (const r of existingLineRows[0]) {
      if (r && r.id) existingLineIds.add(String(r.id));
    }
  }
  const incomingLineIds = /* @__PURE__ */ new Set();
  if (Array.isArray(doc.lines) && doc.lines.length > 0) {
    const lineInsertSql = `
      INSERT INTO accounting_doc_lines (
        id, doc_id, account_id, account_name, debit, credit,
        description, line_index, fiscal_year_id, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const lineUpdateSql = `
      UPDATE accounting_doc_lines SET
        account_id = ?, account_name = ?, debit = ?, credit = ?,
        description = ?, line_index = ?, fiscal_year_id = ?, created_by = ?
      WHERE id = ? AND doc_id = ?
    `;
    for (let idx = 0; idx < doc.lines.length; idx++) {
      const ln = doc.lines[idx];
      if (!ln || typeof ln !== "object") continue;
      const lnId = String(ln.id || `${id}-ln-${idx + 1}`);
      incomingLineIds.add(lnId);
      const accountId = ln.accountId || ln.accountCode || "";
      const accountName = ln.accountName || "";
      const lnDesc = ln.description || null;
      const debit = Number(ln.debit) || 0;
      const credit = Number(ln.credit) || 0;
      const lineIndex = ln.lineIndex !== void 0 ? Number(ln.lineIndex) : ln.rowOrder !== void 0 ? Number(ln.rowOrder) : idx + 1;
      if (existingLineIds.has(lnId)) {
        await conn.execute(lineUpdateSql, [
          accountId,
          accountName,
          debit,
          credit,
          lnDesc,
          lineIndex,
          fiscalYearId,
          createdBy,
          lnId,
          id
        ]);
      } else {
        await conn.execute(lineInsertSql, [
          lnId,
          id,
          accountId,
          accountName,
          debit,
          credit,
          lnDesc,
          lineIndex,
          fiscalYearId,
          createdBy
        ]);
      }
    }
  }
  for (const oldId of existingLineIds) {
    if (!incomingLineIds.has(oldId)) {
      await conn.execute("DELETE FROM accounting_doc_lines WHERE id = ? AND doc_id = ?", [oldId, id]);
    }
  }
}
async function deleteSingleAccountingDocRelational(conn, id) {
  const cleanId = String(id).trim();
  await conn.execute("UPDATE accounting_docs SET is_deleted = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ? OR doc_number = ?", [cleanId, cleanId]);
}
async function saveSingleNotificationRelational(conn, notif, userContext) {
  if (!notif || typeof notif !== "object") return;
  const id = String(notif.id || `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`);
  const userId = notif.userId || null;
  const title = notif.title || "\u0627\u0639\u0644\u0627\u0646 \u062C\u062F\u06CC\u062F";
  const message = notif.message || "";
  const type = notif.type || "info";
  const isRead = notif.isRead ? 1 : 0;
  const link = notif.link || null;
  const rawJson = JSON.stringify(notif);
  const notifSql = `
    INSERT INTO notifications (
      id, user_id, title, message, type, is_read, link, raw_json, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP
    ) ON DUPLICATE KEY UPDATE
      user_id = VALUES(user_id),
      title = VALUES(title),
      message = VALUES(message),
      type = VALUES(type),
      is_read = VALUES(is_read),
      link = VALUES(link),
      raw_json = VALUES(raw_json),
      updated_at = CURRENT_TIMESTAMP
  `;
  await conn.execute(notifSql, [id, userId, title, message, type, isRead, link, rawJson]);
}
async function deleteSingleNotificationRelational(conn, id) {
  const cleanId = String(id).trim();
  await conn.execute("DELETE FROM notifications WHERE id = ?", [cleanId]);
}
async function saveSingleChecklistItemRelational(conn, item, userContext) {
  if (!item || typeof item !== "object") return;
  const id = String(item.id || `chk-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`);
  const title = item.title || "\u0645\u0648\u0631\u062F \u0686\u06A9\u200C\u0644\u06CC\u0633\u062A";
  const isCompleted = item.isCompleted || item.completed ? 1 : 0;
  const dueDate = item.dueDate || null;
  const rowOrder = Number(item.rowOrder) || 0;
  const createdBy = item.createdBy || (userContext?.username || "system");
  const rawJson = JSON.stringify(item);
  const chkSql = `
    INSERT INTO checklist (
      id, title, is_completed, due_date, row_order, created_by, raw_json, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP
    ) ON DUPLICATE KEY UPDATE
      title = VALUES(title),
      is_completed = VALUES(is_completed),
      due_date = VALUES(due_date),
      row_order = VALUES(row_order),
      created_by = VALUES(created_by),
      raw_json = VALUES(raw_json),
      updated_at = CURRENT_TIMESTAMP
  `;
  await conn.execute(chkSql, [id, title, isCompleted, dueDate, rowOrder, createdBy, rawJson]);
}
async function deleteSingleChecklistItemRelational(conn, id) {
  const cleanId = String(id).trim();
  await conn.execute("DELETE FROM checklist WHERE id = ?", [cleanId]);
}
async function saveSingleSettingRelational(conn, settingKey, settingValue, userContext) {
  const sKey = String(settingKey).trim();
  const serialized = typeof settingValue === "string" ? settingValue : JSON.stringify(settingValue);
  const createdBy = userContext?.username || "system";
  const setSql = `
    INSERT INTO settings (id, setting_key, setting_value, created_by, updated_at)
    VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
    ON DUPLICATE KEY UPDATE
      setting_key = VALUES(setting_key),
      setting_value = VALUES(setting_value),
      updated_at = CURRENT_TIMESTAMP
  `;
  await conn.execute(setSql, [sKey, sKey, serialized, createdBy]);
}
async function saveSingleUserRelational(conn, user, userContext) {
  if (!user || typeof user !== "object") return;
  const id = String(user.id || `user-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`);
  const username = String(user.username || user.name || "user").trim();
  const name = user.name || username;
  const role = user.role || "seller";
  const phone = user.phone || null;
  const passwordHash = user.password || user.passwordHash || username;
  const permissions = Array.isArray(user.permissions) ? JSON.stringify(user.permissions) : JSON.stringify([]);
  const rawJson = JSON.stringify(user);
  const userSql = `
    INSERT INTO users (
      id, username, password_hash, name, role, phone, permissions, raw_json, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP
    ) ON DUPLICATE KEY UPDATE
      name = VALUES(name),
      role = VALUES(role),
      phone = VALUES(phone),
      password_hash = VALUES(password_hash),
      permissions = VALUES(permissions),
      raw_json = VALUES(raw_json),
      updated_at = CURRENT_TIMESTAMP
  `;
  await conn.execute(userSql, [id, username, passwordHash, name, role, phone, permissions, rawJson]);
}
async function deleteSingleUserRelational(conn, id) {
  const cleanId = String(id).trim();
  await conn.execute("DELETE FROM users WHERE id = ? OR username = ?", [cleanId, cleanId]);
}
async function saveSingleFiscalYearRelational(conn, fy, userContext) {
  if (!fy || typeof fy !== "object") return;
  const id = String(fy.id || `fy-${Date.now()}`);
  const yearTitle = String(fy.year || fy.yearTitle || "1405").trim();
  const startDate = fy.startDate || "1405/01/01";
  const endDate = fy.endDate || "1405/12/29";
  const isClosed = fy.registered === false || fy.isClosed ? 1 : 0;
  const createdBy = fy.createdBy || (userContext?.username || "system");
  const rawJson = JSON.stringify(fy);
  const fySql = `
    INSERT INTO fiscal_years (
      id, year_title, start_date, end_date, is_closed, created_by, raw_json, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP
    ) ON DUPLICATE KEY UPDATE
      year_title = VALUES(year_title),
      start_date = VALUES(start_date),
      end_date = VALUES(end_date),
      is_closed = VALUES(is_closed),
      created_by = VALUES(created_by),
      raw_json = VALUES(raw_json),
      updated_at = CURRENT_TIMESTAMP
  `;
  await conn.execute(fySql, [id, yearTitle, startDate, endDate, isClosed, createdBy, rawJson]);
}
async function saveSingleLogRelational(conn, log, userContext) {
  if (!log || typeof log !== "object") return;
  const id = String(log.id || `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`);
  const level = log.level || "info";
  const category = log.category || "system";
  const action = log.action || "operation";
  const message = log.message || "";
  const userId = log.userId || (userContext?.id || null);
  const rawJson = JSON.stringify(log);
  const logSql = `
    INSERT INTO logs (id, level, category, action, message, user_id, raw_json, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
  `;
  await conn.execute(logSql, [id, level, category, action, message, userId, rawJson]);
}
async function routeEntityWriteToRelational(conn, cleanKey, data, userContext) {
  switch (cleanKey) {
    case "invoices":
    case "proformas": {
      if (Array.isArray(data)) {
        for (const itm of data) await saveSingleInvoiceRelational(conn, itm, userContext);
      } else {
        await saveSingleInvoiceRelational(conn, data, userContext);
      }
      break;
    }
    case "transactions": {
      if (Array.isArray(data)) {
        for (const itm of data) await saveSingleTransactionRelational(conn, itm, userContext);
      } else {
        await saveSingleTransactionRelational(conn, data, userContext);
      }
      break;
    }
    case "items": {
      if (Array.isArray(data)) {
        for (const itm of data) await saveSingleItemRelational(conn, itm, userContext);
      } else {
        await saveSingleItemRelational(conn, data, userContext);
      }
      break;
    }
    case "counterparts": {
      if (Array.isArray(data)) {
        for (const itm of data) await saveSingleCounterpartRelational(conn, itm, userContext);
      } else {
        await saveSingleCounterpartRelational(conn, data, userContext);
      }
      break;
    }
    case "accounts": {
      if (Array.isArray(data)) {
        for (const itm of data) await saveSingleAccountRelational(conn, itm, userContext);
      } else {
        await saveSingleAccountRelational(conn, data, userContext);
      }
      break;
    }
    case "warehouses": {
      if (Array.isArray(data)) {
        for (const itm of data) await saveSingleWarehouseRelational(conn, itm, userContext);
      } else {
        await saveSingleWarehouseRelational(conn, data, userContext);
      }
      break;
    }
    case "categories": {
      if (Array.isArray(data)) {
        for (const itm of data) await saveSingleCategoryRelational(conn, itm, userContext);
      } else {
        await saveSingleCategoryRelational(conn, data, userContext);
      }
      break;
    }
    case "docs":
    case "accounting_docs":
    case "accountingDocuments": {
      if (Array.isArray(data)) {
        for (const itm of data) await saveSingleAccountingDocRelational(conn, itm, userContext);
      } else {
        await saveSingleAccountingDocRelational(conn, data, userContext);
      }
      break;
    }
    case "notifications": {
      if (Array.isArray(data)) {
        for (const itm of data) await saveSingleNotificationRelational(conn, itm, userContext);
      } else {
        await saveSingleNotificationRelational(conn, data, userContext);
      }
      break;
    }
    case "checklist": {
      if (Array.isArray(data)) {
        for (const itm of data) await saveSingleChecklistItemRelational(conn, itm, userContext);
      } else {
        await saveSingleChecklistItemRelational(conn, data, userContext);
      }
      break;
    }
    case "settings": {
      if (data && typeof data === "object") {
        for (const sKey of Object.keys(data)) {
          await saveSingleSettingRelational(conn, sKey, data[sKey], userContext);
        }
      }
      break;
    }
    case "users": {
      if (Array.isArray(data)) {
        for (const itm of data) await saveSingleUserRelational(conn, itm, userContext);
      } else {
        await saveSingleUserRelational(conn, data, userContext);
      }
      break;
    }
    case "fiscalYear":
    case "fiscal_years": {
      await saveSingleFiscalYearRelational(conn, data, userContext);
      break;
    }
    case "system_logs":
    case "logs": {
      if (Array.isArray(data)) {
        for (const itm of data) await saveSingleLogRelational(conn, itm, userContext);
      } else {
        await saveSingleLogRelational(conn, data, userContext);
      }
      break;
    }
    default: {
      await saveSingleSettingRelational(conn, cleanKey, data, userContext);
      break;
    }
  }
}
async function saveKeyData(key, data, options = {}) {
  return withStateMutationMutex(async () => {
    const cleanKey = key.startsWith("acc_app_") ? key.substring(8) : key;
    const fullKey = `acc_app_${cleanKey}`;
    const now = Date.now();
    const validation = validateEntityAndPermission(cleanKey, data, options.userContext, "update");
    if (!validation.isValid) {
      return { success: false, error: validation.error || "\u062F\u0633\u062A\u0631\u0633\u06CC \u06CC\u0627 \u0633\u0627\u062E\u062A\u0627\u0631 \u062F\u0627\u062F\u0647 \u0627\u0631\u0633\u0627\u0644\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A.", version: now };
    }
    const processedData = extractAndSaveBase64ImagesNode(data, cleanKey);
    if (!serverMemoryStateCache) {
      await populateMemoryCache();
    }
    if (!serverMemoryStateCache) serverMemoryStateCache = {};
    if (!keyVersions) keyVersions = {};
    let finalData = processedData;
    if (options.forceMerge && COLLECTION_ENTITY_KEYS.has(cleanKey) && Array.isArray(processedData)) {
      const existing = serverMemoryStateCache[cleanKey] || serverMemoryStateCache[fullKey];
      if (Array.isArray(existing) && existing.length > 0) {
        finalData = smartMergeEntityArray(existing, processedData);
      }
    }
    serverStateVersion = now;
    keyVersions[cleanKey] = now;
    keyVersions[fullKey] = now;
    serverMemoryStateCache[cleanKey] = finalData;
    serverMemoryStateCache[fullKey] = finalData;
    let conn = null;
    try {
      conn = await mysqlPool.getConnection();
      await conn.beginTransaction();
      await routeEntityWriteToRelational(conn, cleanKey, finalData, options.userContext);
      let serialized = typeof finalData === "string" ? finalData : JSON.stringify(finalData);
      if (cleanKey === "items" || cleanKey === "acc_app_items") {
        const latestItems = await getLatestItemsList(conn);
        serverMemoryStateCache["items"] = latestItems;
        serverMemoryStateCache["acc_app_items"] = latestItems;
        serialized = JSON.stringify(latestItems);
        await conn.execute(
          "INSERT INTO app_state (state_key, state_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE state_value = VALUES(state_value), updated_at = CURRENT_TIMESTAMP",
          ["items", serialized]
        );
        await conn.execute(
          "INSERT INTO app_state (state_key, state_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE state_value = VALUES(state_value), updated_at = CURRENT_TIMESTAMP",
          ["acc_app_items", serialized]
        );
      } else {
        await conn.execute(
          "INSERT INTO app_state (state_key, state_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE state_value = VALUES(state_value), updated_at = CURRENT_TIMESTAMP",
          [cleanKey, serialized]
        );
      }
      await conn.commit();
      return { success: true, version: now };
    } catch (err) {
      if (conn) {
        try {
          await conn.rollback();
        } catch (_) {
        }
      }
      console.error(`Failed to save key '${cleanKey}' to relational MySQL tables:`, err.message);
      return {
        success: false,
        error: `\u062E\u0637\u0627 \u062F\u0631 \u062B\u0628\u062A \u0646\u0647\u0627\u06CC\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u062F\u0631 \u062C\u062F\u0627\u0648\u0644 \u062A\u0641\u06A9\u06CC\u06A9\u06CC MySQL: ${err.message || "\u067E\u0627\u0633\u062E\u06CC \u0627\u0632 \u067E\u0627\u06CC\u06AF\u0627\u0647\u200C\u062F\u0627\u062F\u0647 \u062F\u0631\u06CC\u0627\u0641\u062A \u0646\u06AF\u0631\u062F\u06CC\u062F."}`,
        version: now
      };
    } finally {
      if (conn) conn.release();
    }
  });
}
async function saveAllData(allData, options = {}) {
  return withStateMutationMutex(async () => {
    const now = Date.now();
    serverStateVersion = now;
    if (!keyVersions) keyVersions = {};
    if (!serverMemoryStateCache) {
      await populateMemoryCache();
    }
    if (!serverMemoryStateCache) serverMemoryStateCache = {};
    const keys = Object.keys(allData);
    if (keys.length === 0) {
      return { success: true, count: 0, version: now };
    }
    for (const key of keys) {
      const cleanKey = key.startsWith("acc_app_") ? key.substring(8) : key;
      const fullKey = `acc_app_${cleanKey}`;
      let val = extractAndSaveBase64ImagesNode(allData[key], cleanKey);
      if (!options.forceOverwrite && COLLECTION_ENTITY_KEYS.has(cleanKey) && Array.isArray(val)) {
        const existing = serverMemoryStateCache[cleanKey] || serverMemoryStateCache[fullKey];
        if (Array.isArray(existing) && existing.length > 0) {
          val = smartMergeEntityArray(existing, val);
        }
      }
      serverMemoryStateCache[cleanKey] = val;
      serverMemoryStateCache[fullKey] = val;
      keyVersions[cleanKey] = now;
      keyVersions[fullKey] = now;
    }
    let conn = null;
    try {
      conn = await mysqlPool.getConnection();
      await conn.beginTransaction();
      let hasItemsUpdate = false;
      for (const rawKey of keys) {
        const cleanKey = rawKey.startsWith("acc_app_") ? rawKey.substring(8) : rawKey;
        const currentVal = serverMemoryStateCache[cleanKey];
        await routeEntityWriteToRelational(conn, cleanKey, currentVal, options.userContext);
        if (cleanKey === "items" || cleanKey === "acc_app_items") {
          hasItemsUpdate = true;
        } else {
          const serialized = typeof currentVal === "string" ? currentVal : JSON.stringify(currentVal);
          await conn.execute(
            "INSERT INTO app_state (state_key, state_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE state_value = VALUES(state_value), updated_at = CURRENT_TIMESTAMP",
            [cleanKey, serialized]
          );
        }
      }
      if (hasItemsUpdate) {
        const latestItems = await getLatestItemsList(conn);
        serverMemoryStateCache["items"] = latestItems;
        serverMemoryStateCache["acc_app_items"] = latestItems;
        const serialized = JSON.stringify(latestItems);
        await conn.execute(
          "INSERT INTO app_state (state_key, state_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE state_value = VALUES(state_value), updated_at = CURRENT_TIMESTAMP",
          ["items", serialized]
        );
        await conn.execute(
          "INSERT INTO app_state (state_key, state_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE state_value = VALUES(state_value), updated_at = CURRENT_TIMESTAMP",
          ["acc_app_items", serialized]
        );
      }
      await conn.commit();
      return { success: true, count: keys.length, version: now };
    } catch (err) {
      if (conn) {
        try {
          await conn.rollback();
        } catch (_) {
        }
      }
      console.error("Failed to batch save to relational MySQL database:", err.message);
      return {
        success: false,
        error: `\u062E\u0637\u0627 \u062F\u0631 \u062B\u0628\u062A \u06AF\u0631\u0648\u0647\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u062F\u0631 \u062C\u062F\u0627\u0648\u0644 MySQL: ${err.message || "\u0639\u062F\u0645 \u067E\u0627\u0633\u062E\u06AF\u0648\u06CC\u06CC \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633 \u0647\u0627\u0633\u062A"}`,
        count: 0,
        version: now
      };
    } finally {
      if (conn) conn.release();
    }
  });
}
function validateDatabaseSchema(dbData) {
  if (!dbData || typeof dbData !== "object" || Array.isArray(dbData)) {
    return { isValid: false, reason: "\u0633\u0627\u062E\u062A\u0627\u0631 \u062F\u0627\u062F\u0647 \u0627\u0631\u0633\u0627\u0644\u200C\u0634\u062F\u0647 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A (\u0628\u0627\u06CC\u062F \u0622\u0628\u062C\u06A9\u062A \u0628\u0627\u0634\u062F)." };
  }
  const keys = Object.keys(dbData);
  if (keys.length === 0) {
    return { isValid: false, reason: "\u0645\u062D\u062A\u0648\u0627\u06CC \u0628\u06A9\u0627\u067E \u06CC\u0627 \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633 \u06A9\u0627\u0645\u0644\u0627\u064B \u062E\u0627\u0644\u06CC \u0627\u0633\u062A." };
  }
  const normalizedKeys = keys.map((k) => k.startsWith("acc_app_") ? k.substring(8) : k);
  const knownKeys = [
    "users",
    "invoices",
    "transactions",
    "items",
    "counterparts",
    "accounts",
    "categories",
    "docs",
    "checklist",
    "fiscalYear",
    "settings",
    "partners",
    "loanBorrowers",
    "pendingDeposits",
    "bankSmsMessages",
    "paymentAllocations",
    "inventoryMovements",
    "auditLogs",
    "system_logs",
    "commissionTags",
    "warehouse_categories_list",
    "warehouse_stock_adjustment_logs"
  ];
  const hasKnownKey = normalizedKeys.some((k) => knownKeys.includes(k) || k.startsWith("settings") || k.startsWith("theme") || k.includes("custom"));
  if (!hasKnownKey && keys.length < 1) {
    return { isValid: false, reason: "\u0641\u0627\u06CC\u0644 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646 \u0641\u0627\u0642\u062F \u0622\u0631\u0627\u06CC\u0647\u200C\u0647\u0627 \u0648 \u06A9\u0644\u06CC\u062F\u0647\u0627\u06CC \u0627\u0635\u0644\u06CC \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0627\u0633\u062A." };
  }
  return { isValid: true };
}
async function startServer() {
  await initDatabase();
  const app = (0, import_express.default)();
  app.use((0, import_compression.default)({
    level: 6,
    threshold: 1024
    // Compress any response > 1KB
  }));
  const config = getAppConfig();
  const PORT = Number(process.env.PORT) || config.PORT || 3e3;
  app.use(import_express.default.json({ limit: "500mb" }));
  app.use(import_express.default.urlencoded({ limit: "500mb", extended: true }));
  app.use(import_express.default.raw({ type: ["application/octet-stream", "application/zip", "application/x-zip-compressed", "application/*"], limit: "500mb" }));
  app.use(import_express.default.text({ limit: "50mb", type: ["text/plain", "text/*", "application/text"] }));
  app.use((err, req, res, next) => {
    if (err) {
      console.error("Express request parsing error:", err.message || err);
      if (err.type === "entity.too.large" || err.status === 413) {
        return res.status(413).json({
          status: "error",
          code: "ENTITY_TOO_LARGE",
          error: "\u062D\u062C\u0645 \u062F\u0627\u062F\u0647\u200C\u0647\u0627\u06CC \u0627\u0631\u0633\u0627\u0644\u06CC \u0628\u06CC\u0634 \u0627\u0632 \u062D\u062F \u0645\u062C\u0627\u0632 \u067E\u0631\u0627\u06A9\u0633\u06CC \u0633\u0631\u0648\u0631 \u0627\u0633\u062A."
        });
      }
      return res.status(400).json({
        status: "error",
        error: `\u062E\u0637\u0627 \u062F\u0631 \u062F\u0631\u06CC\u0627\u0641\u062A \u0648 \u067E\u0631\u062F\u0627\u0632\u0634 \u062F\u0627\u062F\u0647\u200C\u0647\u0627: ${err.message || "\u0641\u0631\u0645\u062A \u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A"}`
      });
    }
    next();
  });
  app.use((req, res, next) => {
    if (req.path === "/api.php" || req.path === "/index.php") {
      const action = req.query.action || req.query.route;
      if (action && typeof action === "string") {
        const cleanAction = action.replace(/^\/?(api\/)?/, "");
        req.url = `/api/${cleanAction}`;
      }
    }
    next();
  });
  app.get("/api/db/version", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      if (!serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({
        status: "success",
        version: serverStateVersion,
        keyVersions: keyVersions || {},
        lastUpdated: serverStateVersion
      });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/db/sync-delta", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      if (!serverMemoryStateCache) {
        await populateMemoryCache();
      }
      const { clientVersion, clientKeyVersions } = req.body || {};
      if (clientVersion && Number(clientVersion) === Number(serverStateVersion)) {
        return res.json({ status: "not_modified", version: serverStateVersion });
      }
      const allData = serverMemoryStateCache || {};
      if (clientKeyVersions && typeof clientKeyVersions === "object") {
        const updatedKeys = {};
        let diffCount = 0;
        for (const rawKey of Object.keys(allData)) {
          const cleanKey = rawKey.startsWith("acc_app_") ? rawKey.substring(8) : rawKey;
          const sVer = keyVersions[cleanKey] || serverStateVersion;
          const cVer = clientKeyVersions[cleanKey] || clientKeyVersions[`acc_app_${cleanKey}`] || 0;
          if (sVer > cVer || !cVer) {
            if (allData[cleanKey] !== void 0) {
              updatedKeys[cleanKey] = allData[cleanKey];
              diffCount++;
            }
          }
        }
        if (diffCount === 0 && clientVersion) {
          return res.json({ status: "not_modified", version: serverStateVersion });
        }
        return res.json({
          status: "delta",
          version: serverStateVersion,
          updatedKeys,
          keyVersions: keyVersions || {}
        });
      }
      return res.json({
        status: "full",
        version: serverStateVersion,
        allData,
        keyVersions: keyVersions || {}
      });
    } catch (err) {
      console.error("API error during delta sync:", err);
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get(["/api/db/key", "/api/db/load-key"], async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      const key = String(req.query.key || "");
      if (!key) {
        return res.status(400).json({ status: "error", error: "\u0634\u0646\u0627\u0633\u0647 \u06A9\u0644\u06CC\u062F \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      const data = await getKeyData(key);
      return res.json({ status: "success", key, data });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get("/api/db/load-all", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      if (!serverMemoryStateCache) {
        await populateMemoryCache();
      }
      const etag = `W/"v-${serverStateVersion}"`;
      res.setHeader("ETag", etag);
      res.setHeader("X-DB-Version", String(serverStateVersion));
      if (req.headers["if-none-match"] === etag) {
        return res.status(304).end();
      }
      const state = await loadAllData();
      return res.json(state);
    } catch (err) {
      console.error("API error loading database state:", err);
      return res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/db/save-key", async (req, res) => {
    try {
      const { key, data, forceOverwrite = false } = req.body;
      if (!key) {
        return res.status(400).json({ status: "error", error: "\u0634\u0646\u0627\u0633\u0647 \u06A9\u0644\u06CC\u062F \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      const result = await saveKeyData(key, data, { forceOverwrite: Boolean(forceOverwrite) });
      if (!result.success) {
        return res.status(500).json({
          status: "error",
          key,
          error: result.error || "\u062E\u0637\u0627 \u062F\u0631 \u062B\u0628\u062A \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u062F\u0631 \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633",
          dbType,
          version: result.version || serverStateVersion
        });
      }
      return res.json({
        status: "success",
        key,
        dbType,
        version: result.version || serverStateVersion,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (err) {
      console.error("API error saving key:", err);
      return res.status(500).json({ status: "error", error: `\u062E\u0637\u0627 \u062F\u0631 \u0630\u062E\u06CC\u0631\u0647\u200C\u0633\u0627\u0632\u06CC \u062F\u0627\u062F\u0647: ${err.message}`, dbType });
    }
  });
  async function deleteEntityRecordFromRelational(conn, cleanKey, deleteId, userContext) {
    const targetId = String(deleteId).trim();
    switch (cleanKey) {
      case "invoices":
      case "proformas":
        await deleteSingleInvoiceRelational(conn, targetId);
        break;
      case "transactions":
        await deleteSingleTransactionRelational(conn, targetId);
        break;
      case "items":
        await deleteSingleItemRelational(conn, targetId);
        break;
      case "counterparts":
        await deleteSingleCounterpartRelational(conn, targetId);
        break;
      case "accounts":
        await deleteSingleAccountRelational(conn, targetId);
        break;
      case "warehouses":
        await deleteSingleWarehouseRelational(conn, targetId);
        break;
      case "categories":
        await deleteSingleCategoryRelational(conn, targetId);
        break;
      case "docs":
      case "accounting_docs":
      case "accountingDocuments":
        await deleteSingleAccountingDocRelational(conn, targetId);
        break;
      case "notifications":
        await deleteSingleNotificationRelational(conn, targetId);
        break;
      case "checklist":
        await deleteSingleChecklistItemRelational(conn, targetId);
        break;
      case "users":
        await deleteSingleUserRelational(conn, targetId);
        break;
    }
  }
  app.post("/api/db/merge-entity", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const { key, item, items, deleteId, userContext } = req.body || {};
      if (!key) {
        return res.status(400).json({ status: "error", error: "\u0634\u0646\u0627\u0633\u0647 \u0645\u0648\u062C\u0648\u062F\u06CC\u062A \u0645\u0634\u062E\u0635 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      const cleanKey = key.startsWith("acc_app_") ? key.substring(8) : key;
      const fullKey = `acc_app_${cleanKey}`;
      const incomingItems = items && Array.isArray(items) ? items : item ? [item] : [];
      if (deleteId) {
        const valDel = validateEntityAndPermission(cleanKey, { id: deleteId }, userContext, "delete");
        if (!valDel.isValid) {
          return res.status(403).json({ status: "error", error: valDel.error });
        }
      }
      for (const itm of incomingItems) {
        const valItm = validateEntityAndPermission(cleanKey, itm, userContext, "update");
        if (!valItm.isValid) {
          return res.status(400).json({ status: "error", error: valItm.error });
        }
      }
      const mergeResult = await withStateMutationMutex(async () => {
        if (!serverMemoryStateCache) {
          await populateMemoryCache();
        }
        if (!serverMemoryStateCache) serverMemoryStateCache = {};
        const rawList = serverMemoryStateCache[cleanKey] || serverMemoryStateCache[fullKey] || [];
        let list = Array.isArray(rawList) ? [...rawList] : [];
        let conn = null;
        try {
          conn = await mysqlPool.getConnection();
          await conn.beginTransaction();
          if (deleteId) {
            const targetId = String(deleteId).trim();
            list = list.filter((it) => {
              const itId = getEntityIdentifier(it);
              return itId !== targetId && itId !== `inv-${targetId}` && itId !== `doc-${targetId}` && itId !== `code-${targetId}` && itId !== `user-${targetId}`;
            });
            await deleteEntityRecordFromRelational(conn, cleanKey, targetId, userContext);
          }
          if (incomingItems.length > 0) {
            list = smartMergeEntityArray(list, incomingItems);
            for (const itm of incomingItems) {
              const processed = extractAndSaveBase64ImagesNode(itm, cleanKey);
              await routeEntityWriteToRelational(conn, cleanKey, processed, userContext);
            }
          }
          await conn.commit();
        } catch (err) {
          if (conn) {
            try {
              await conn.rollback();
            } catch (_) {
            }
          }
          throw err;
        } finally {
          if (conn) conn.release();
        }
        const now = Date.now();
        serverStateVersion = now;
        if (!keyVersions) keyVersions = {};
        keyVersions[cleanKey] = now;
        keyVersions[fullKey] = now;
        serverMemoryStateCache[cleanKey] = list;
        serverMemoryStateCache[fullKey] = list;
        return { count: list.length, version: now };
      });
      return res.json({
        status: "success",
        key: cleanKey,
        count: mergeResult.count,
        version: mergeResult.version,
        dbType,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (err) {
      console.error("API error merging entity to relational table:", err);
      return res.status(500).json({ status: "error", error: `\u062E\u0637\u0627 \u062F\u0631 \u062B\u0628\u062A \u0627\u062A\u0645\u06CC\u06A9 \u0631\u062F\u06CC\u0641 \u062F\u0631 \u062C\u062F\u0648\u0644 \u0631\u0627\u0628\u0637\u0647\u200C\u0627\u06CC: ${err.message}`, dbType });
    }
  });
  app.post("/api/db/save-all", async (req, res) => {
    try {
      const { stateData, forceOverwrite = false } = req.body;
      if (!stateData || typeof stateData !== "object") {
        return res.status(400).json({ status: "error", error: "\u0641\u0631\u0645\u062A \u062F\u0627\u062F\u0647\u200C\u0647\u0627\u06CC \u0627\u0631\u0633\u0627\u0644\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A." });
      }
      const sanitizedData = {};
      for (const rawKey of Object.keys(stateData)) {
        const cleanKey = rawKey.startsWith("acc_app_") ? rawKey.substring(8) : rawKey;
        let parsedValue = stateData[rawKey];
        if (typeof parsedValue === "string") {
          try {
            parsedValue = JSON.parse(parsedValue);
          } catch (_) {
          }
        }
        sanitizedData[cleanKey] = parsedValue;
      }
      const result = await saveAllData(sanitizedData, { forceOverwrite: Boolean(forceOverwrite) });
      if (!result.success) {
        return res.status(500).json({
          status: "error",
          error: result.error || "\u062E\u0637\u0627 \u062F\u0631 \u062B\u0628\u062A \u062F\u0633\u062A\u0647\u200C\u0627\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u062F\u0631 \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633",
          dbType,
          version: result.version || serverStateVersion
        });
      }
      return res.json({
        status: "success",
        count: result.count,
        dbType,
        version: result.version || serverStateVersion,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (err) {
      console.error("API error during bulk save:", err);
      return res.status(500).json({ status: "error", error: `\u062E\u0637\u0627 \u062F\u0631 \u0630\u062E\u06CC\u0631\u0647\u200C\u0633\u0627\u0632\u06CC \u062F\u0633\u062A\u0647\u200C\u0627\u06CC: ${err.message}`, dbType });
    }
  });
  app.get(["/api/db/migrate", "/api/migrate"], async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const shouldMigrateData = req.query.data === "true" || req.query.data === "1";
      const conn = await mysqlPool.getConnection();
      try {
        const schemaRes = await runDatabaseMigrations(conn);
        if (shouldMigrateData) {
          const migrationRes = await migrateAppStateDataToRelationalTables(conn);
          return res.json({
            status: "success",
            message: "\u0645\u0627\u06CC\u06AF\u0631\u06CC\u0634\u0646 \u0633\u0627\u062E\u062A\u0627\u0631 \u0648 \u0627\u0646\u062A\u0642\u0627\u0644 \u0627\u0645\u0646 \u062A\u0645\u0627\u0645 \u062F\u0627\u062F\u0647\u200C\u0647\u0627\u06CC JSON \u0628\u0647 \u062C\u062F\u0627\u0648\u0644 \u0631\u0627\u0628\u0637\u0647\u200C\u0627\u06CC \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.",
            schema: schemaRes,
            migration: migrationRes
          });
        }
        return res.json({
          status: "success",
          message: "\u062A\u0645\u0627\u0645 \u06F1\u06F7 \u062C\u062F\u0648\u0644 \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F MySQL \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u0639\u062A\u0628\u0627\u0631\u0633\u0646\u062C\u06CC \u0648 \u0633\u0627\u062E\u062A\u0647 \u0634\u062F\u0646\u062F.",
          schema: schemaRes
        });
      } finally {
        conn.release();
      }
    } catch (err) {
      console.error("Migration endpoint error:", err);
      return res.status(500).json({ status: "error", error: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u062C\u0631\u0627\u06CC \u0645\u0627\u06CC\u06AF\u0631\u06CC\u0634\u0646: ${err.message}` });
    }
  });
  app.all(["/api/db/migrate-data", "/api/migrate-data"], async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const conn = await mysqlPool.getConnection();
      try {
        const migrationRes = await migrateAppStateDataToRelationalTables(conn);
        return res.json({
          status: "success",
          message: "\u0627\u0646\u062A\u0642\u0627\u0644 \u0627\u0645\u0646\u060C \u062A\u0631\u0627\u06A9\u0646\u0634\u06CC \u0648 \u062A\u06A9\u0631\u0627\u0631\u067E\u0630\u06CC\u0631 \u062F\u0627\u062F\u0647\u200C\u0647\u0627\u06CC JSON \u0645\u0648\u062C\u0648\u062F \u062F\u0631 app_state \u0628\u0647 \u062C\u062F\u0627\u0648\u0644 \u062A\u0641\u06A9\u06CC\u06A9\u06CC MySQL \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.",
          migration: migrationRes
        });
      } finally {
        conn.release();
      }
    } catch (err) {
      console.error("Data migration endpoint error:", err);
      return res.status(500).json({ status: "error", error: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u062F\u0627\u062F\u0647\u200C\u0647\u0627 \u0628\u0647 \u062C\u062F\u0627\u0648\u0644 \u0631\u0627\u0628\u0637\u0647\u200C\u0627\u06CC: ${err.message}` });
    }
  });
  app.get("/api/invoices", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const type = req.query.type;
      let sql = "SELECT * FROM invoices WHERE is_deleted = 0";
      const params = [];
      if (type) {
        sql += " AND type = ?";
        params.push(type);
      }
      sql += " ORDER BY id DESC";
      const rows = await executeMysqlQuery(sql, params);
      const items = await executeMysqlQuery("SELECT * FROM invoice_items ORDER BY sort_order ASC, id ASC");
      const itemsMap = /* @__PURE__ */ new Map();
      if (Array.isArray(items)) {
        for (const itm of items) {
          const invId = String(itm.invoice_id);
          if (!itemsMap.has(invId)) itemsMap.set(invId, []);
          itemsMap.get(invId).push({
            id: itm.id,
            itemId: itm.item_id,
            name: itm.name,
            qty: Number(itm.qty) || 0,
            quantity: Number(itm.qty) || 0,
            unit: itm.unit,
            unitPrice: Number(itm.unit_price) || 0,
            discount: Number(itm.discount) || 0,
            tax: Number(itm.tax) || 0,
            totalPrice: Number(itm.total_price) || 0,
            total: Number(itm.total_price) || 0,
            remarks: itm.remarks,
            description: itm.remarks,
            type: itm.type || "kala",
            color: itm.color || null,
            cogsUnitCost: Number(itm.cogs_unit_cost) || 0,
            cogsTotal: Number(itm.cogs_total) || 0,
            sortOrder: Number(itm.sort_order) || 0,
            fiscalYearId: itm.fiscal_year_id,
            createdBy: itm.created_by
          });
        }
      }
      const data = (rows || []).map((r) => {
        let customIcons = null;
        let attachments = null;
        let paymentSlips = null;
        let history = null;
        let allocations = null;
        try {
          if (r.custom_icons) customIcons = JSON.parse(r.custom_icons);
        } catch (_) {
        }
        try {
          if (r.attachments) attachments = JSON.parse(r.attachments);
        } catch (_) {
        }
        try {
          if (r.payment_slips) paymentSlips = JSON.parse(r.payment_slips);
        } catch (_) {
        }
        try {
          if (r.history) history = JSON.parse(r.history);
        } catch (_) {
        }
        try {
          if (r.allocations) allocations = JSON.parse(r.allocations);
        } catch (_) {
        }
        return {
          id: r.id,
          invoiceNumber: r.invoice_number,
          type: r.type || "sale",
          date: r.date,
          counterpartId: r.counterpart_id,
          counterpartName: r.counterpart_name,
          counterpartPhone: r.counterpart_phone,
          counterpartAddress: r.counterpart_address,
          totalAmount: Number(r.total_amount) || 0,
          tax: Number(r.tax) || 0,
          deposit: Number(r.deposit) || 0,
          discount: Number(r.discount) || 0,
          paymentAmount: Number(r.payment_amount) || 0,
          paymentDate: r.payment_date,
          description: r.description,
          isProforma: Boolean(r.is_proforma),
          isUrgent: Boolean(r.is_urgent),
          urgentType: r.urgent_type,
          shippingMethod: r.shipping_method,
          acquaintanceMethod: r.acquaintance_method,
          docId: r.doc_id,
          cogsDocId: r.cogs_doc_id,
          cogsTotal: Number(r.cogs_total) || 0,
          isReturn: Boolean(r.is_return),
          returnRefInvoiceId: r.return_ref_invoice_id,
          customIcons,
          attachments,
          paymentSlips,
          history,
          allocations,
          fiscalYearId: r.fiscal_year_id,
          createdBy: r.created_by,
          createdById: r.created_by_id,
          createdByPhone: r.created_by_phone,
          items: itemsMap.get(String(r.id)) || [],
          createdAt: r.created_at,
          updatedAt: r.updated_at
        };
      });
      return res.json({ status: "success", count: data.length, data });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/invoices", async (req, res) => {
    try {
      const invoiceData = req.body;
      const userContext = req.body.userContext;
      const validation = validateEntityAndPermission("invoices", invoiceData, userContext, "create");
      if (!validation.isValid) {
        return res.status(400).json({ status: "error", error: validation.error });
      }
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        const processed = extractAndSaveBase64ImagesNode(invoiceData, "invoices");
        await saveSingleInvoiceRelational(conn, processed, userContext);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: "\u0641\u0627\u06A9\u062A\u0648\u0631 \u0648 \u0627\u0642\u0644\u0627\u0645 \u0648\u0627\u0628\u0633\u062A\u0647 \u0628\u0627 Transaction \u062F\u0631 \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633 \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F\u0646\u062F." });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.delete("/api/invoices/:id", async (req, res) => {
    try {
      const invId = req.params.id;
      const userContext = req.body?.userContext;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        await deleteSingleInvoiceRelational(conn, invId);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: `\u0641\u0627\u06A9\u062A\u0648\u0631 ${invId} \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062D\u0630\u0641 \u0634\u062F.` });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get("/api/transactions", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const rows = await executeMysqlQuery("SELECT * FROM transactions WHERE is_deleted = 0 ORDER BY id DESC");
      const data = (rows || []).map((r) => {
        let attachments = null;
        let editHistory = null;
        try {
          if (r.attachments) attachments = JSON.parse(r.attachments);
        } catch (_) {
        }
        try {
          if (r.edit_history) editHistory = JSON.parse(r.edit_history);
        } catch (_) {
        }
        return {
          id: r.id,
          date: r.date,
          time: r.time,
          amount: Number(r.amount) || 0,
          type: r.type,
          description: r.description,
          isRegistered: Boolean(r.is_registered),
          categoryParent: r.category_parent,
          categoryChild: r.category_child,
          categoryId: r.category_child || r.category_parent,
          category: r.category_child || r.category_parent,
          userDescription: r.user_description,
          isDuplicate: Boolean(r.is_duplicate),
          duplicateReason: r.duplicate_reason,
          trackingNumber: r.tracking_number,
          referenceCode: r.reference_code,
          registeredDate: r.registered_date,
          accountId: r.account_id,
          partnerId: r.partner_id,
          pendingDepositId: r.pending_deposit_id,
          borrowerId: r.borrower_id,
          borrowerName: r.borrower_name,
          loanType: r.loan_type,
          counterpartId: r.counterpart_id,
          counterpartName: r.counterpart_name,
          invoiceId: r.invoice_id,
          docId: r.doc_id,
          attachments,
          isEdited: Boolean(r.is_edited),
          editedBy: r.edited_by,
          editedById: r.edited_by_id,
          editedAt: r.edited_at,
          editHistory,
          isDeleted: Boolean(r.is_deleted),
          deletedBy: r.deleted_by,
          deletedById: r.deleted_by_id,
          deletedAt: r.deleted_at,
          fiscalYearId: r.fiscal_year_id,
          createdBy: r.created_by,
          createdById: r.created_by_id,
          createdAt: r.created_at,
          updatedAt: r.updated_at
        };
      });
      return res.json({ status: "success", count: data.length, data });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/transactions", async (req, res) => {
    try {
      const txData = req.body;
      const userContext = req.body.userContext;
      const validation = validateEntityAndPermission("transactions", txData, userContext, "create");
      if (!validation.isValid) {
        return res.status(400).json({ status: "error", error: validation.error });
      }
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        const processed = extractAndSaveBase64ImagesNode(txData, "transactions");
        await saveSingleTransactionRelational(conn, processed, userContext);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: "\u062A\u0631\u0627\u06A9\u0646\u0634 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062C\u062F\u0648\u0644 transactions \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F." });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.delete("/api/transactions/:id", async (req, res) => {
    try {
      const txId = req.params.id;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        await deleteSingleTransactionRelational(conn, txId);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: `\u062A\u0631\u0627\u06A9\u0646\u0634 ${txId} \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062D\u0630\u0641 \u0634\u062F.` });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get("/api/items", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const rows = await executeMysqlQuery("SELECT * FROM items ORDER BY id DESC");
      const data = (rows || []).map((r) => ({
        id: r.id,
        warehouseId: r.warehouse_id,
        name: r.name,
        code: r.code,
        type: r.type || "kala",
        color: r.color || null,
        unit: r.unit || "\u0639\u062F\u062F",
        qty: Number(r.qty) || 0,
        stock: Number(r.qty) || 0,
        quantity: Number(r.qty) || 0,
        initialQty: Number(r.initial_qty) || 0,
        lastPurchasePrice: Number(r.last_purchase_price) || 0,
        purchasePrice: Number(r.last_purchase_price) || 0,
        lastSalePrice: Number(r.last_sale_price) || 0,
        salePrice: Number(r.last_sale_price) || 0,
        minQtyAlarm: Number(r.min_qty_alarm) || 0,
        minStock: Number(r.min_qty_alarm) || 0,
        categoryName: r.category_name,
        parentCategory: r.parent_category,
        subCategory: r.sub_category,
        commissionPercent: Number(r.commission_percent) || 0,
        setupDate: r.setup_date,
        fiscalYearId: r.fiscal_year_id,
        createdBy: r.created_by,
        createdAt: r.created_at,
        updatedAt: r.updated_at
      }));
      return res.json({ status: "success", count: data.length, data });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/items", async (req, res) => {
    try {
      const itemData = req.body;
      const userContext = req.body.userContext;
      const validation = validateEntityAndPermission("items", itemData, userContext, "create");
      if (!validation.isValid) {
        return res.status(400).json({ status: "error", error: validation.error });
      }
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        const processed = extractAndSaveBase64ImagesNode(itemData, "items");
        await saveSingleItemRelational(conn, processed, userContext);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: "\u06A9\u0627\u0644\u0627 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062C\u062F\u0648\u0644 items \u062B\u0628\u062A \u0634\u062F." });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.delete("/api/items/:id", async (req, res) => {
    try {
      const itemId = req.params.id;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        await deleteSingleItemRelational(conn, itemId);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: `\u06A9\u0627\u0644\u0627 ${itemId} \u062D\u0630\u0641 \u0634\u062F.` });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get("/api/counterparts", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const rows = await executeMysqlQuery("SELECT * FROM counterparts ORDER BY id DESC");
      return res.json({ status: "success", count: (rows || []).length, data: rows || [] });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/counterparts", async (req, res) => {
    try {
      const cpData = req.body;
      const userContext = req.body.userContext;
      const validation = validateEntityAndPermission("counterparts", cpData, userContext, "create");
      if (!validation.isValid) {
        return res.status(400).json({ status: "error", error: validation.error });
      }
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        const processed = extractAndSaveBase64ImagesNode(cpData, "counterparts");
        await saveSingleCounterpartRelational(conn, processed, userContext);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: "\u0637\u0631\u0641\u200C\u062D\u0633\u0627\u0628 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062C\u062F\u0648\u0644 counterparts \u062B\u0628\u062A \u0634\u062F." });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.delete("/api/counterparts/:id", async (req, res) => {
    try {
      const cpId = req.params.id;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        await deleteSingleCounterpartRelational(conn, cpId);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: `\u0637\u0631\u0641\u200C\u062D\u0633\u0627\u0628 ${cpId} \u062D\u0630\u0641 \u0634\u062F.` });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get("/api/accounts", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const rows = await executeMysqlQuery("SELECT * FROM accounts ORDER BY id DESC");
      return res.json({ status: "success", count: (rows || []).length, data: rows || [] });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/accounts", async (req, res) => {
    try {
      const accData = req.body;
      const userContext = req.body.userContext;
      const validation = validateEntityAndPermission("accounts", accData, userContext, "create");
      if (!validation.isValid) {
        return res.status(400).json({ status: "error", error: validation.error });
      }
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        const processed = extractAndSaveBase64ImagesNode(accData, "accounts");
        await saveSingleAccountRelational(conn, processed, userContext);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: "\u062D\u0633\u0627\u0628 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062C\u062F\u0648\u0644 accounts \u062B\u0628\u062A \u0634\u062F." });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.delete("/api/accounts/:id", async (req, res) => {
    try {
      const accId = req.params.id;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        await deleteSingleAccountRelational(conn, accId);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: `\u062D\u0633\u0627\u0628 ${accId} \u062D\u0630\u0641 \u0634\u062F.` });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get("/api/docs", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const rows = await executeMysqlQuery("SELECT * FROM accounting_docs WHERE is_deleted = 0 ORDER BY id DESC");
      const lines = await executeMysqlQuery("SELECT * FROM accounting_doc_lines ORDER BY line_index ASC, id ASC");
      const linesMap = /* @__PURE__ */ new Map();
      if (Array.isArray(lines)) {
        for (const ln of lines) {
          const docId = String(ln.doc_id);
          if (!linesMap.has(docId)) linesMap.set(docId, []);
          linesMap.get(docId).push({
            id: ln.id,
            docId: ln.doc_id,
            accountId: ln.account_id,
            accountCode: ln.account_id,
            accountName: ln.account_name,
            debit: Number(ln.debit) || 0,
            credit: Number(ln.credit) || 0,
            description: ln.description,
            lineIndex: Number(ln.line_index) || 0,
            rowOrder: Number(ln.line_index) || 0,
            fiscalYearId: ln.fiscal_year_id,
            createdBy: ln.created_by,
            createdAt: ln.created_at,
            updatedAt: ln.updated_at
          });
        }
      }
      const data = (rows || []).map((r) => {
        const relatedLines = linesMap.get(String(r.id)) || [];
        const totalDebit = relatedLines.reduce((sum, ln) => sum + (Number(ln.debit) || 0), 0);
        const totalCredit = relatedLines.reduce((sum, ln) => sum + (Number(ln.credit) || 0), 0);
        return {
          id: r.id,
          docNumber: Number(r.doc_number) || 0,
          date: r.date,
          description: r.description,
          isArchived: Boolean(r.is_archived),
          isManual: Boolean(r.is_manual),
          status: r.status || "posted",
          operationType: r.operation_type,
          invoiceId: r.invoice_id,
          txId: r.tx_id,
          refDocId: r.ref_doc_id,
          idempotencyKey: r.idempotency_key,
          actorId: r.actor_id,
          actorName: r.actor_name,
          isDeleted: Boolean(r.is_deleted),
          deletedBy: r.deleted_by,
          deletedById: r.deleted_by_id,
          deletedAt: r.deleted_at,
          fiscalYearId: r.fiscal_year_id,
          createdBy: r.created_by,
          lines: relatedLines,
          totalDebit,
          totalCredit,
          createdAt: r.created_at,
          updatedAt: r.updated_at
        };
      });
      return res.json({ status: "success", count: data.length, data });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/docs", async (req, res) => {
    try {
      const docData = req.body;
      const userContext = req.body.userContext;
      const validation = validateEntityAndPermission("docs", docData, userContext, "create");
      if (!validation.isValid) {
        return res.status(400).json({ status: "error", error: validation.error });
      }
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        const processed = extractAndSaveBase64ImagesNode(docData, "docs");
        await saveSingleAccountingDocRelational(conn, processed, userContext);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: "\u0633\u0646\u062F \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F." });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.delete("/api/docs/:id", async (req, res) => {
    try {
      const docId = req.params.id;
      const userContext = req.body?.userContext;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        await deleteSingleAccountingDocRelational(conn, docId);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: `\u0633\u0646\u062F ${docId} \u062D\u0630\u0641 \u0634\u062F.` });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get("/api/warehouses", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const rows = await executeMysqlQuery("SELECT * FROM warehouses ORDER BY id ASC");
      return res.json({ status: "success", count: (rows || []).length, data: rows || [] });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/warehouses", async (req, res) => {
    try {
      const whData = req.body;
      const userContext = req.body.userContext;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        const processed = extractAndSaveBase64ImagesNode(whData, "warehouses");
        await saveSingleWarehouseRelational(conn, processed, userContext);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: "\u0627\u0646\u0628\u0627\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F." });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.delete("/api/warehouses/:id", async (req, res) => {
    try {
      const whId = req.params.id;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        await deleteSingleWarehouseRelational(conn, whId);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: `\u0627\u0646\u0628\u0627\u0631 ${whId} \u062D\u0630\u0641 \u0634\u062F.` });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get("/api/categories", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const rows = await executeMysqlQuery("SELECT * FROM categories ORDER BY id ASC");
      return res.json({ status: "success", count: (rows || []).length, data: rows || [] });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/categories", async (req, res) => {
    try {
      const catData = req.body;
      const userContext = req.body.userContext;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        const processed = extractAndSaveBase64ImagesNode(catData, "categories");
        await saveSingleCategoryRelational(conn, processed, userContext);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: "\u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F." });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.delete("/api/categories/:id", async (req, res) => {
    try {
      const catId = req.params.id;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        await deleteSingleCategoryRelational(conn, catId);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: `\u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC ${catId} \u062D\u0630\u0641 \u0634\u062F.` });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get("/api/checklist", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const rows = await executeMysqlQuery("SELECT * FROM checklist ORDER BY row_order ASC, id ASC");
      const data = (rows || []).map((r) => ({
        id: r.id,
        title: r.title,
        isCompleted: Boolean(r.is_completed),
        completed: Boolean(r.is_completed),
        dueDate: r.due_date,
        rowOrder: Number(r.row_order) || 0,
        createdBy: r.created_by
      }));
      return res.json({ status: "success", count: data.length, data });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/checklist", async (req, res) => {
    try {
      const chkData = req.body;
      const userContext = req.body.userContext;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        await saveSingleChecklistItemRelational(conn, chkData, userContext);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: "\u0645\u0648\u0631\u062F \u0686\u06A9\u200C\u0644\u06CC\u0633\u062A \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F." });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.delete("/api/checklist/:id", async (req, res) => {
    try {
      const chkId = req.params.id;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        await deleteSingleChecklistItemRelational(conn, chkId);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: `\u0645\u0648\u0631\u062F \u0686\u06A9\u200C\u0644\u06CC\u0633\u062A ${chkId} \u062D\u0630\u0641 \u0634\u062F.` });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get("/api/notifications", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const rows = await executeMysqlQuery("SELECT * FROM notifications ORDER BY id DESC LIMIT 200");
      const data = (rows || []).map((r) => ({
        id: r.id,
        userId: r.user_id,
        title: r.title,
        message: r.message,
        type: r.type,
        isRead: Boolean(r.is_read),
        link: r.link,
        createdAt: r.created_at
      }));
      return res.json({ status: "success", count: data.length, data });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/notifications", async (req, res) => {
    try {
      const notifData = req.body;
      const userContext = req.body.userContext;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        await saveSingleNotificationRelational(conn, notifData, userContext);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: "\u0627\u0639\u0644\u0627\u0646 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F." });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get("/api/settings", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const rows = await executeMysqlQuery("SELECT setting_key, setting_value FROM settings");
      const result = {};
      if (Array.isArray(rows)) {
        for (const row of rows) {
          result[row.setting_key] = safeUnwrapJson(row.setting_value);
        }
      }
      return res.json({ status: "success", data: result });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/settings", async (req, res) => {
    try {
      const settingsData = req.body;
      const userContext = req.body.userContext;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        if (settingsData && typeof settingsData === "object") {
          for (const k of Object.keys(settingsData)) {
            await saveSingleSettingRelational(conn, k, settingsData[k], userContext);
          }
        }
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: "\u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062C\u062F\u0648\u0644 settings \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F\u0646\u062F." });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get(["/api/system/web-messengers", "/api/web-messengers"], async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      let data = null;
      try {
        const rows = await executeMysqlQuery(
          "SELECT setting_value FROM settings_store WHERE setting_key = ? LIMIT 1",
          ["acc_system_web_messengers"]
        );
        if (Array.isArray(rows) && rows.length > 0 && rows[0]?.setting_value) {
          data = safeUnwrapJson(rows[0].setting_value);
        }
      } catch (_) {
      }
      if (!data || !Array.isArray(data) || data.length === 0) {
        const stateRows = await executeMysqlQuery(
          "SELECT state_value FROM app_state WHERE state_key = ? OR state_key = ? LIMIT 1",
          ["acc_system_web_messengers", "acc_app_acc_system_web_messengers"]
        );
        if (Array.isArray(stateRows) && stateRows.length > 0 && stateRows[0]?.state_value) {
          data = safeUnwrapJson(stateRows[0].state_value);
        }
      }
      return res.json({
        status: "success",
        key: "acc_system_web_messengers",
        source: "mysql",
        data: Array.isArray(data) && data.length > 0 ? data : []
      });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post(["/api/system/web-messengers", "/api/web-messengers"], async (req, res) => {
    try {
      let rawList = req.body?.messengers || req.body?.data || req.body;
      if (typeof rawList === "string") {
        try {
          rawList = JSON.parse(rawList);
        } catch (_) {
        }
      }
      if (!Array.isArray(rawList)) {
        return res.status(400).json({ status: "error", error: "\u0642\u0627\u0644\u0628 \u062F\u0627\u062F\u0647 \u0627\u0631\u0633\u0627\u0644\u200C\u0634\u062F\u0647 \u0628\u0631\u0627\u06CC \u067E\u06CC\u0627\u0645\u200C\u0631\u0633\u0627\u0646\u200C\u0647\u0627 \u0628\u0627\u06CC\u062F \u0622\u0631\u0627\u06CC\u0647 (Array) \u0628\u0627\u0634\u062F." });
      }
      const validated = [];
      for (let i = 0; i < rawList.length; i++) {
        const item = rawList[i];
        if (!item || typeof item !== "object") continue;
        const id = String(item.id || `wm-${Date.now()}-${i}`).trim();
        const title = String(item.title || "").trim();
        let url = String(item.url || "").trim();
        if (!title) {
          return res.status(400).json({ status: "error", error: `\u0639\u0646\u0648\u0627\u0646 \u067E\u06CC\u0627\u0645\u200C\u0631\u0633\u0627\u0646 (title) \u062F\u0631 \u0631\u062F\u06CC\u0641 ${i + 1} \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A.` });
        }
        if (!url) {
          return res.status(400).json({ status: "error", error: `\u0622\u062F\u0631\u0633 \u067E\u06CC\u0627\u0645\u200C\u0631\u0633\u0627\u0646 (url) \u062F\u0631 \u0631\u062F\u06CC\u0641 ${i + 1} \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A.` });
        }
        if (!/^https?:\/\//i.test(url)) {
          url = `https://${url}`;
        }
        const icon = String(item.icon || "globe").trim();
        const customIconUrl = String(item.customIconUrl || "").trim();
        const allowedUserIds = Array.isArray(item.allowedUserIds) ? item.allowedUserIds.map((u) => String(u)) : [];
        const windowWidth = Number(item.windowWidth) > 0 ? Number(item.windowWidth) : 1080;
        const windowHeight = Number(item.windowHeight) > 0 ? Number(item.windowHeight) : 720;
        const category = String(item.category || "\u067E\u06CC\u0627\u0645\u200C\u0631\u0633\u0627\u0646").trim();
        const description = String(item.description || "").trim();
        validated.push({
          id,
          title,
          url,
          icon,
          customIconUrl,
          allowedUserIds,
          windowWidth,
          windowHeight,
          category,
          description,
          createdBy: item.createdBy || null,
          createdById: item.createdById || null,
          createdAt: item.createdAt || null
        });
      }
      const serialized = JSON.stringify(validated);
      await executeMysqlQuery(
        `INSERT INTO settings_store (setting_key, setting_value, created_by)
         VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = CURRENT_TIMESTAMP`,
        ["acc_system_web_messengers", serialized, req.body?.userContext?.username || null]
      );
      try {
        await executeMysqlQuery(
          `INSERT INTO app_state (state_key, state_value)
           VALUES (?, ?)
           ON DUPLICATE KEY UPDATE state_value = VALUES(state_value), updated_at = CURRENT_TIMESTAMP`,
          ["acc_system_web_messengers", serialized]
        );
      } catch (_) {
      }
      return res.json({
        status: "success",
        message: "\u0644\u06CC\u0633\u062A \u067E\u06CC\u0627\u0645\u200C\u0631\u0633\u0627\u0646\u200C\u0647\u0627 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u067E\u0627\u06CC\u06AF\u0627\u0647\u200C\u062F\u0627\u062F\u0647 MySQL \u0630\u062E\u06CC\u0631\u0647 \u06AF\u0631\u062F\u06CC\u062F.",
        key: "acc_system_web_messengers",
        count: validated.length,
        data: validated
      });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get(["/api/system/user-messenger-icons", "/api/user-messenger-icons"], async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      let data = null;
      try {
        const rows = await executeMysqlQuery(
          "SELECT setting_value FROM settings_store WHERE setting_key = ? LIMIT 1",
          ["acc_system_user_messenger_icons"]
        );
        if (Array.isArray(rows) && rows.length > 0 && rows[0]?.setting_value) {
          data = safeUnwrapJson(rows[0].setting_value);
        }
      } catch (_) {
      }
      if (!data || !Array.isArray(data)) {
        const stateRows = await executeMysqlQuery(
          "SELECT state_value FROM app_state WHERE state_key = ? OR state_key = ? LIMIT 1",
          ["acc_system_user_messenger_icons", "acc_app_acc_system_user_messenger_icons"]
        );
        if (Array.isArray(stateRows) && stateRows.length > 0 && stateRows[0]?.state_value) {
          data = safeUnwrapJson(stateRows[0].state_value);
        }
      }
      let icons = Array.isArray(data) ? data : [];
      const filterUserId = req.query?.userId ? String(req.query.userId).trim() : null;
      if (filterUserId) {
        icons = icons.filter((i) => !i.userId || String(i.userId) === filterUserId);
      }
      return res.json({
        status: "success",
        key: "acc_system_user_messenger_icons",
        source: "mysql",
        data: icons
      });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post(["/api/system/user-messenger-icons", "/api/user-messenger-icons"], async (req, res) => {
    try {
      let rawList = req.body?.icons || req.body?.data || req.body;
      if (typeof rawList === "string") {
        try {
          rawList = JSON.parse(rawList);
        } catch (_) {
        }
      }
      if (!Array.isArray(rawList)) {
        return res.status(400).json({ status: "error", error: "\u0642\u0627\u0644\u0628 \u062F\u0627\u062F\u0647 \u0627\u0631\u0633\u0627\u0644\u200C\u0634\u062F\u0647 \u0628\u0631\u0627\u06CC \u0622\u06CC\u06A9\u0648\u0646\u200C\u0647\u0627\u06CC \u0633\u0641\u0627\u0631\u0634\u06CC \u0628\u0627\u06CC\u062F \u0622\u0631\u0627\u06CC\u0647 (Array) \u0628\u0627\u0634\u062F." });
      }
      const validated = [];
      for (let i = 0; i < rawList.length; i++) {
        const item = rawList[i];
        if (!item || typeof item !== "object") continue;
        const id = String(item.id || `usr-icon-${Date.now()}-${i}`).trim();
        const userId = String(item.userId || "").trim();
        const name = String(item.name || `icon-${i + 1}`).trim();
        const dataUrl = String(item.dataUrl || item.data || item.url || "").trim();
        const createdAt = String(item.createdAt || "").trim();
        if (!dataUrl) continue;
        validated.push({
          id,
          userId,
          name,
          dataUrl,
          createdAt
        });
      }
      const serialized = JSON.stringify(validated);
      await executeMysqlQuery(
        `INSERT INTO settings_store (setting_key, setting_value, created_by)
         VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = CURRENT_TIMESTAMP`,
        ["acc_system_user_messenger_icons", serialized, req.body?.userContext?.username || null]
      );
      try {
        await executeMysqlQuery(
          `INSERT INTO app_state (state_key, state_value)
           VALUES (?, ?)
           ON DUPLICATE KEY UPDATE state_value = VALUES(state_value), updated_at = CURRENT_TIMESTAMP`,
          ["acc_system_user_messenger_icons", serialized]
        );
      } catch (_) {
      }
      return res.json({
        status: "success",
        message: "\u0622\u06CC\u06A9\u0648\u0646\u200C\u0647\u0627\u06CC \u0633\u0641\u0627\u0631\u0634\u06CC \u067E\u06CC\u0627\u0645\u200C\u0631\u0633\u0627\u0646\u200C\u0647\u0627 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u067E\u0627\u06CC\u06AF\u0627\u0647\u200C\u062F\u0627\u062F\u0647 MySQL \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F\u0646\u062F.",
        key: "acc_system_user_messenger_icons",
        count: validated.length,
        data: validated
      });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get("/api/users", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const rows = await executeMysqlQuery("SELECT id, username, name, role, phone, permissions, created_at, updated_at FROM users ORDER BY id ASC");
      const data = (rows || []).map((r) => ({
        id: r.id,
        username: r.username,
        name: r.name,
        role: r.role,
        phone: r.phone,
        permissions: safeUnwrapJson(r.permissions) || []
      }));
      return res.json({ status: "success", count: data.length, data });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/users", async (req, res) => {
    try {
      const userData = req.body;
      const userContext = req.body.userContext;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        await saveSingleUserRelational(conn, userData, userContext);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: "\u06A9\u0627\u0631\u0628\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062C\u062F\u0648\u0644 users \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F." });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.delete("/api/users/:id", async (req, res) => {
    try {
      const userId = req.params.id;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        await deleteSingleUserRelational(conn, userId);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: `\u06A9\u0627\u0631\u0628\u0631 ${userId} \u062D\u0630\u0641 \u0634\u062F.` });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get("/api/fiscal-years", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const rows = await executeMysqlQuery("SELECT * FROM fiscal_years ORDER BY id DESC");
      return res.json({ status: "success", count: (rows || []).length, data: rows || [] });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/fiscal-years", async (req, res) => {
    try {
      const fyData = req.body;
      const userContext = req.body.userContext;
      const conn = await mysqlPool.getConnection();
      try {
        await conn.beginTransaction();
        await saveSingleFiscalYearRelational(conn, fyData, userContext);
        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      } finally {
        conn.release();
      }
      if (serverMemoryStateCache) {
        await populateMemoryCache();
      }
      return res.json({ status: "success", message: "\u0633\u0627\u0644 \u0645\u0627\u0644\u06CC \u062F\u0631 \u062C\u062F\u0648\u0644 fiscal_years \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F." });
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.get("/api/initial-data", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      res.setHeader("Pragma", "no-cache");
      const [
        invRows,
        invItemRows,
        txRows,
        itemRows,
        cpRows,
        accRows,
        docRows,
        docLineRows,
        whRows,
        catRows,
        chkRows,
        notifRows,
        userRows,
        setRows,
        fyRows
      ] = await Promise.all([
        executeMysqlQuery("SELECT * FROM invoices WHERE is_deleted = 0 ORDER BY id DESC"),
        executeMysqlQuery("SELECT * FROM invoice_items ORDER BY id ASC"),
        executeMysqlQuery("SELECT * FROM transactions WHERE is_deleted = 0 ORDER BY id DESC"),
        executeMysqlQuery("SELECT * FROM items ORDER BY id DESC"),
        executeMysqlQuery("SELECT * FROM counterparts ORDER BY id DESC"),
        executeMysqlQuery("SELECT * FROM accounts ORDER BY id DESC"),
        executeMysqlQuery("SELECT * FROM accounting_docs WHERE is_deleted = 0 ORDER BY id DESC"),
        executeMysqlQuery("SELECT * FROM accounting_doc_lines ORDER BY row_order ASC, id ASC"),
        executeMysqlQuery("SELECT * FROM warehouses ORDER BY id ASC"),
        executeMysqlQuery("SELECT * FROM categories ORDER BY id ASC"),
        executeMysqlQuery("SELECT * FROM checklist ORDER BY row_order ASC, id ASC"),
        executeMysqlQuery("SELECT * FROM notifications ORDER BY id DESC LIMIT 100"),
        executeMysqlQuery("SELECT id, username, name, role, phone, permissions, created_at, updated_at, raw_json FROM users ORDER BY id ASC"),
        executeMysqlQuery("SELECT setting_key, setting_value FROM settings"),
        executeMysqlQuery("SELECT * FROM fiscal_years ORDER BY id DESC")
      ]);
      const itemsMap = /* @__PURE__ */ new Map();
      if (Array.isArray(invItemRows)) {
        for (const itm of invItemRows) {
          const invId = String(itm.invoice_id);
          if (!itemsMap.has(invId)) itemsMap.set(invId, []);
          itemsMap.get(invId).push({
            id: itm.id,
            itemId: itm.item_id,
            name: itm.item_name,
            quantity: Number(itm.quantity) || 0,
            unit: itm.unit,
            unitPrice: Number(itm.unit_price) || 0,
            discount: Number(itm.discount) || 0,
            tax: Number(itm.tax) || 0,
            total: Number(itm.total_price) || 0,
            description: itm.description
          });
        }
      }
      const invoices = (invRows || []).map((r) => {
        const parsed = safeUnwrapJson(r.raw_json) || {};
        return {
          ...parsed,
          id: r.id,
          invoiceNumber: r.invoice_number,
          type: r.type,
          isProforma: Boolean(r.is_proforma),
          customerId: r.counterpart_id,
          customerName: r.counterpart_name,
          counterpartId: r.counterpart_id,
          counterpartName: r.counterpart_name,
          date: r.invoice_date,
          dueDate: r.due_date,
          status: r.status,
          subtotal: Number(r.subtotal) || 0,
          discount: Number(r.discount_amount) || 0,
          tax: Number(r.tax_amount) || 0,
          totalAmount: Number(r.total_amount) || 0,
          paidAmount: Number(r.paid_amount) || 0,
          balanceAmount: Number(r.balance_amount) || 0,
          paymentMethod: r.payment_method,
          notes: r.notes,
          officialBill: Boolean(r.official_bill || r.is_official),
          items: itemsMap.get(String(r.id)) || (Array.isArray(parsed.items) ? parsed.items : [])
        };
      });
      const docLinesMap = /* @__PURE__ */ new Map();
      if (Array.isArray(docLineRows)) {
        for (const ln of docLineRows) {
          const docId = String(ln.doc_id);
          if (!docLinesMap.has(docId)) docLinesMap.set(docId, []);
          docLinesMap.get(docId).push({
            id: ln.id,
            accountCode: ln.account_code,
            accountName: ln.account_name,
            description: ln.description,
            debit: Number(ln.debit) || 0,
            credit: Number(ln.credit) || 0,
            counterpartId: ln.counterpart_id,
            counterpartName: ln.counterpart_name,
            rowOrder: Number(ln.row_order) || 0
          });
        }
      }
      const docs = (docRows || []).map((r) => {
        const parsed = safeUnwrapJson(r.raw_json) || {};
        return {
          ...parsed,
          id: r.id,
          docNumber: r.doc_number,
          date: r.doc_date,
          description: r.description,
          status: r.status,
          totalDebit: Number(r.total_debit) || 0,
          totalCredit: Number(r.total_credit) || 0,
          fiscalYearId: r.fiscal_year_id,
          createdBy: r.created_by,
          lines: docLinesMap.get(String(r.id)) || (Array.isArray(parsed.lines) ? parsed.lines : [])
        };
      });
      const transactions = (txRows || []).map((r) => {
        const parsed = safeUnwrapJson(r.raw_json) || {};
        return {
          ...parsed,
          id: r.id,
          date: r.tx_date,
          type: r.type,
          amount: Number(r.amount) || 0,
          accountId: r.account_id,
          counterpartId: r.counterpart_id,
          categoryId: r.category_id,
          description: r.description,
          trackingNumber: r.tracking_number,
          documentNumber: r.document_number,
          fiscalYearId: r.fiscal_year_id,
          createdBy: r.created_by
        };
      });
      const items = (itemRows || []).map((r) => {
        const parsed = safeUnwrapJson(r.raw_json) || {};
        return {
          ...parsed,
          id: r.id,
          name: r.name,
          code: r.code,
          unit: r.unit,
          purchasePrice: Number(r.purchase_price) || 0,
          salePrice: Number(r.sale_price) || 0,
          stock: Number(r.stock) || 0,
          minStock: Number(r.min_stock) || 0,
          category: r.category,
          warehouseId: r.warehouse_id,
          fiscalYearId: r.fiscal_year_id
        };
      });
      const counterparts = (cpRows || []).map((r) => {
        const parsed = safeUnwrapJson(r.raw_json) || {};
        return {
          ...parsed,
          id: r.id,
          name: r.name,
          code: r.code,
          type: r.type,
          phone: r.phone,
          mobile: r.mobile,
          nationalId: r.national_id,
          economicCode: r.economic_code,
          address: r.address,
          postalCode: r.postal_code,
          initialBalance: Number(r.initial_balance) || 0,
          currentBalance: Number(r.current_balance) || 0,
          balance: Number(r.current_balance) || 0
        };
      });
      const accounts = (accRows || []).map((r) => {
        const parsed = safeUnwrapJson(r.raw_json) || {};
        return {
          ...parsed,
          id: r.id,
          name: r.name,
          type: r.type,
          bankName: r.bank_name,
          accountNumber: r.account_number,
          cardNumber: r.card_number,
          shabaNumber: r.shaba_number,
          balance: Number(r.balance) || 0,
          initialBalance: Number(r.initial_balance) || 0
        };
      });
      const warehouses = (whRows || []).map((r) => {
        const parsed = safeUnwrapJson(r.raw_json) || {};
        return {
          ...parsed,
          id: r.id,
          name: r.name,
          code: r.code,
          address: r.address,
          manager: r.manager,
          phone: r.phone
        };
      });
      const categories = (catRows || []).map((r) => {
        const parsed = safeUnwrapJson(r.raw_json) || {};
        return {
          ...parsed,
          id: r.id,
          name: r.name,
          type: r.type,
          icon: r.icon,
          color: r.color,
          parentId: r.parent_id
        };
      });
      const checklist = (chkRows || []).map((r) => {
        const parsed = safeUnwrapJson(r.raw_json) || {};
        return {
          ...parsed,
          id: r.id,
          title: r.title,
          isCompleted: Boolean(r.is_completed),
          completed: Boolean(r.is_completed),
          dueDate: r.due_date,
          rowOrder: Number(r.row_order) || 0,
          createdBy: r.created_by
        };
      });
      const notifications = (notifRows || []).map((r) => {
        const parsed = safeUnwrapJson(r.raw_json) || {};
        return {
          ...parsed,
          id: r.id,
          userId: r.user_id,
          title: r.title,
          message: r.message,
          type: r.type,
          isRead: Boolean(r.is_read),
          link: r.link,
          createdAt: r.created_at
        };
      });
      const users = (userRows || []).map((r) => {
        const parsed = safeUnwrapJson(r.raw_json) || {};
        return {
          ...parsed,
          id: r.id,
          username: r.username,
          name: r.name,
          role: r.role,
          phone: r.phone,
          permissions: safeUnwrapJson(r.permissions) || parsed.permissions || []
        };
      });
      const settings = {};
      if (Array.isArray(setRows)) {
        for (const row of setRows) {
          settings[row.setting_key] = safeUnwrapJson(row.setting_value);
        }
      }
      const fiscalYear = Array.isArray(fyRows) && fyRows.length > 0 ? {
        id: fyRows[0].id,
        year: fyRows[0].year,
        startDate: fyRows[0].start_date,
        endDate: fyRows[0].end_date,
        registered: Boolean(fyRows[0].registered),
        createdBy: fyRows[0].created_by,
        setupDate: fyRows[0].setup_date
      } : null;
      return res.json({
        status: "success",
        source: "relational_mysql_tables",
        data: {
          invoices,
          transactions,
          items,
          counterparts,
          accounts,
          docs,
          warehouses,
          categories,
          checklist,
          notifications,
          users,
          settings,
          fiscalYear
        }
      });
    } catch (err) {
      console.error("Error loading relational initial data:", err);
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/db/wipe", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const { selectedIds = [] } = req.body || {};
      if (!Array.isArray(selectedIds) || selectedIds.length === 0) {
        return res.status(400).json({ status: "error", error: "\u0647\u06CC\u0686 \u0628\u062E\u0634\u06CC \u0628\u0631\u0627\u06CC \u062A\u062E\u0644\u06CC\u0647 \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633 \u0627\u0646\u062A\u062E\u0627\u0628 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      try {
        const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
        const emergencyDir = import_path.default.join(process.cwd(), "backups");
        if (!import_fs.default.existsSync(emergencyDir)) {
          import_fs.default.mkdirSync(emergencyDir, { recursive: true });
        }
        const emergencyFile = import_path.default.join(emergencyDir, `emergency_before_wipe_${timestamp}.json`);
        const currentBackupDb = await loadAllData();
        import_fs.default.writeFileSync(
          emergencyFile,
          JSON.stringify({
            _metadata: {
              createdReason: "Emergency backup automatically created before selective database wipe",
              timestamp: (/* @__PURE__ */ new Date()).toISOString(),
              selectedIds
            },
            database: currentBackupDb
          }, null, 2),
          "utf8"
        );
      } catch (backupErr) {
        console.warn("Notice: failed to write pre-wipe emergency backup:", backupErr);
      }
      const wipeResult = await withStateMutationMutex(async () => {
        if (!serverMemoryStateCache) {
          await populateMemoryCache();
        }
        if (!serverMemoryStateCache) serverMemoryStateCache = {};
        const selectedSet = new Set(selectedIds);
        const resetLabels = [];
        const modifiedKeys = {};
        if (selectedSet.has("invoices")) {
          serverMemoryStateCache["invoices"] = [];
          serverMemoryStateCache["paymentAllocations"] = [];
          modifiedKeys["invoices"] = [];
          modifiedKeys["paymentAllocations"] = [];
          resetLabels.push("\u06A9\u0644\u06CC\u0647 \u0641\u0627\u06A9\u062A\u0648\u0631\u0647\u0627 \u0648 \u067E\u06CC\u0634\u200C\u0641\u0627\u06A9\u062A\u0648\u0631\u0647\u0627");
        } else if (selectedSet.has("invoices_sales") || selectedSet.has("invoices_purchase") || selectedSet.has("invoices_proforma")) {
          const removedInvIds = /* @__PURE__ */ new Set();
          const currentInvoices = Array.isArray(serverMemoryStateCache["invoices"]) ? serverMemoryStateCache["invoices"] : [];
          serverMemoryStateCache["invoices"] = currentInvoices.filter((inv) => {
            const isPf = Boolean(
              inv?.isProforma === true || inv?.isProforma === "true" || inv?.type === "proforma" || inv?.status === "proforma" || typeof inv?.invoiceNumber === "string" && inv.invoiceNumber.trim().toUpperCase().startsWith("PF-") || typeof inv?.title === "string" && inv.title.includes("\u067E\u06CC\u0634\u200C\u0641\u0627\u06A9\u062A\u0648\u0631")
            );
            const isPurchase = inv?.type === "purchase" && !isPf;
            const isSale = (inv?.type === "sale" || !inv?.type || inv?.type === "invoice") && !isPf;
            if (selectedSet.has("invoices_sales") && isSale) {
              if (inv.id) removedInvIds.add(String(inv.id));
              return false;
            }
            if (selectedSet.has("invoices_purchase") && isPurchase) {
              if (inv.id) removedInvIds.add(String(inv.id));
              return false;
            }
            if (selectedSet.has("invoices_proforma") && isPf) {
              if (inv.id) removedInvIds.add(String(inv.id));
              return false;
            }
            return true;
          });
          modifiedKeys["invoices"] = serverMemoryStateCache["invoices"];
          if (removedInvIds.size > 0) {
            const currentAllocations = Array.isArray(serverMemoryStateCache["paymentAllocations"]) ? serverMemoryStateCache["paymentAllocations"] : [];
            serverMemoryStateCache["paymentAllocations"] = currentAllocations.filter((pa) => !removedInvIds.has(String(pa?.invoiceId)));
            modifiedKeys["paymentAllocations"] = serverMemoryStateCache["paymentAllocations"];
          }
          resetLabels.push("\u0632\u06CC\u0631\u0645\u062C\u0645\u0648\u0639\u0647\u200C\u0647\u0627\u06CC \u0627\u0646\u062A\u062E\u0627\u0628\u06CC \u0641\u0627\u06A9\u062A\u0648\u0631\u0647\u0627");
        }
        if (selectedSet.has("shipping_methods")) {
          serverMemoryStateCache["shipping_methods"] = [];
          serverMemoryStateCache["acc_system_shipping_methods"] = [];
          modifiedKeys["shipping_methods"] = [];
          modifiedKeys["acc_system_shipping_methods"] = [];
          resetLabels.push("\u0631\u0648\u0634\u200C\u0647\u0627\u06CC \u0627\u0631\u0633\u0627\u0644 \u0633\u0641\u0627\u0631\u0634\u06CC");
        }
        if (selectedSet.has("commissionSettlements")) {
          serverMemoryStateCache["commissionSettlements"] = [];
          serverMemoryStateCache["commission_settlements_list"] = [];
          modifiedKeys["commissionSettlements"] = [];
          modifiedKeys["commission_settlements_list"] = [];
          resetLabels.push("\u0633\u0648\u0627\u0628\u0642 \u062A\u0633\u0648\u06CC\u0647 \u067E\u0648\u0631\u0633\u0627\u0646\u062A \u0628\u0627\u0632\u0627\u0631\u06CC\u0627\u0628\u06CC");
        }
        if (selectedSet.has("commissionTags")) {
          serverMemoryStateCache["commissionTags"] = [];
          serverMemoryStateCache["commission_tags_list"] = [];
          modifiedKeys["commissionTags"] = [];
          modifiedKeys["commission_tags_list"] = [];
          resetLabels.push("\u062A\u06AF\u200C\u0647\u0627 \u0648 \u062F\u0631\u0635\u062F\u200C\u0647\u0627\u06CC \u067E\u0648\u0631\u0633\u0627\u0646\u062A \u0648\u06CC\u0698\u0647");
        }
        if (selectedSet.has("items")) {
          serverMemoryStateCache["items"] = [];
          serverMemoryStateCache["inventoryMovements"] = [];
          modifiedKeys["items"] = [];
          modifiedKeys["inventoryMovements"] = [];
          resetLabels.push("\u06A9\u0644\u06CC\u0647 \u06A9\u0627\u0644\u0627\u0647\u0627 \u0648 \u062E\u062F\u0645\u0627\u062A \u0627\u0646\u0628\u0627\u0631");
        } else if (selectedSet.has("items_goods") || selectedSet.has("items_services") || selectedSet.has("items_stock_zero")) {
          const currentItems = Array.isArray(serverMemoryStateCache["items"]) ? serverMemoryStateCache["items"] : [];
          serverMemoryStateCache["items"] = currentItems.filter((it) => {
            const isService = it?.type === "khadamat" || it?.isService === true;
            if (selectedSet.has("items_goods") && !isService) return false;
            if (selectedSet.has("items_services") && isService) return false;
            if (selectedSet.has("items_stock_zero") && !isService && (Number(it?.qty) || 0) <= 0) return false;
            return true;
          });
          modifiedKeys["items"] = serverMemoryStateCache["items"];
          resetLabels.push("\u0632\u06CC\u0631\u0645\u062C\u0645\u0648\u0639\u0647\u200C\u0647\u0627\u06CC \u0627\u0646\u062A\u062E\u0627\u0628\u06CC \u06A9\u0627\u0644\u0627\u0647\u0627 \u0648 \u062E\u062F\u0645\u0627\u062A \u0627\u0646\u0628\u0627\u0631");
        }
        if (selectedSet.has("categories")) {
          serverMemoryStateCache["categories"] = [];
          serverMemoryStateCache["warehouse_categories_list"] = [];
          modifiedKeys["categories"] = [];
          modifiedKeys["warehouse_categories_list"] = [];
          resetLabels.push("\u062F\u0633\u062A\u0647\u200C\u0628\u0646\u062F\u06CC\u200C\u0647\u0627\u06CC \u06A9\u0627\u0644\u0627");
        }
        if (selectedSet.has("warehouse_stock_adjustment_logs")) {
          serverMemoryStateCache["warehouse_stock_adjustment_logs"] = [];
          modifiedKeys["warehouse_stock_adjustment_logs"] = [];
          resetLabels.push("\u0633\u0648\u0627\u0628\u0642 \u0627\u0646\u0628\u0627\u0631\u06AF\u0631\u062F\u0627\u0646\u06CC");
        }
        if (selectedSet.has("docs")) {
          serverMemoryStateCache["docs"] = [];
          modifiedKeys["docs"] = [];
          resetLabels.push("\u06A9\u0644\u06CC\u0647 \u0627\u0633\u0646\u0627\u062F \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC");
        } else if (selectedSet.has("docs_manual") || selectedSet.has("docs_auto")) {
          const currentDocs = Array.isArray(serverMemoryStateCache["docs"]) ? serverMemoryStateCache["docs"] : [];
          serverMemoryStateCache["docs"] = currentDocs.filter((d) => {
            const isManual = d?.isManual === true || d?.type === "manual" || !d?.invoiceId && !d?.cogsInvoiceId && !d?.autoGenerated;
            if (selectedSet.has("docs_manual") && isManual) return false;
            if (selectedSet.has("docs_auto") && !isManual) return false;
            return true;
          });
          modifiedKeys["docs"] = serverMemoryStateCache["docs"];
          resetLabels.push("\u0632\u06CC\u0631\u0645\u062C\u0645\u0648\u0639\u0647\u200C\u0647\u0627\u06CC \u0627\u0646\u062A\u062E\u0627\u0628\u06CC \u0627\u0633\u0646\u0627\u062F \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC");
        }
        if (selectedSet.has("transactions")) {
          serverMemoryStateCache["transactions"] = [];
          modifiedKeys["transactions"] = [];
          resetLabels.push("\u06A9\u0644\u06CC\u0647 \u0635\u0648\u0631\u062A\u062D\u0633\u0627\u0628 \u0648 \u062A\u0631\u0627\u06A9\u0646\u0634\u200C\u0647\u0627\u06CC \u0628\u0627\u0646\u06A9\u06CC");
        } else if (selectedSet.has("transactions_income") || selectedSet.has("transactions_expense")) {
          const currentTx = Array.isArray(serverMemoryStateCache["transactions"]) ? serverMemoryStateCache["transactions"] : [];
          serverMemoryStateCache["transactions"] = currentTx.filter((tx) => {
            const isIncome = tx?.type === "deposit" || tx?.type === "income" || tx?.type === "received";
            const isExpense = tx?.type === "withdrawal" || tx?.type === "expense" || tx?.type === "paid";
            if (selectedSet.has("transactions_income") && isIncome) return false;
            if (selectedSet.has("transactions_expense") && isExpense) return false;
            return true;
          });
          modifiedKeys["transactions"] = serverMemoryStateCache["transactions"];
          resetLabels.push("\u0632\u06CC\u0631\u0645\u062C\u0645\u0648\u0639\u0647\u200C\u0647\u0627\u06CC \u0627\u0646\u062A\u062E\u0627\u0628\u06CC \u062A\u0631\u0627\u06A9\u0646\u0634\u200C\u0647\u0627\u06CC \u0628\u0627\u0646\u06A9\u06CC");
        }
        if (selectedSet.has("pendingDeposits")) {
          serverMemoryStateCache["pendingDeposits"] = [];
          modifiedKeys["pendingDeposits"] = [];
          resetLabels.push("\u0648\u0627\u0631\u06CC\u0632\u06CC\u200C\u0647\u0627 \u0648 \u0628\u06CC\u0639\u0627\u0646\u0647\u200C\u0647\u0627\u06CC \u0645\u0639\u0644\u0642");
        }
        if (selectedSet.has("bankSmsMessages")) {
          serverMemoryStateCache["bankSmsMessages"] = [];
          modifiedKeys["bankSmsMessages"] = [];
          resetLabels.push("\u067E\u06CC\u0627\u0645\u06A9\u200C\u0647\u0627\u06CC \u0628\u0627\u0646\u06A9\u06CC");
        }
        if (selectedSet.has("accounts")) {
          serverMemoryStateCache["accounts"] = [];
          modifiedKeys["accounts"] = [];
          resetLabels.push("\u062D\u0633\u0627\u0628\u200C\u0647\u0627\u06CC \u0628\u0627\u0646\u06A9\u06CC \u0648 \u0635\u0646\u062F\u0648\u0642\u200C\u0647\u0627");
        }
        if (selectedSet.has("loanBorrowers")) {
          serverMemoryStateCache["loanBorrowers"] = [];
          modifiedKeys["loanBorrowers"] = [];
          resetLabels.push("\u062D\u0633\u0627\u0628 \u0648 \u0628\u062F\u0647\u06CC \u0648\u0627\u0645\u200C\u06AF\u06CC\u0631\u0646\u062F\u06AF\u0627\u0646");
        }
        if (selectedSet.has("counterparts")) {
          serverMemoryStateCache["counterparts"] = [];
          modifiedKeys["counterparts"] = [];
          resetLabels.push("\u06A9\u0644\u06CC\u0647 \u0637\u0631\u0641 \u062D\u0633\u0627\u0628\u200C\u0647\u0627 \u0648 \u0645\u0634\u062A\u0631\u06CC\u0627\u0646");
        } else if (selectedSet.has("counterparts_debtors") || selectedSet.has("counterparts_creditors")) {
          const currentCp = Array.isArray(serverMemoryStateCache["counterparts"]) ? serverMemoryStateCache["counterparts"] : [];
          serverMemoryStateCache["counterparts"] = currentCp.filter((cp) => {
            const isDebtor = cp?.type === "buyer" || cp?.type === "customer" || (Number(cp?.balance) || 0) > 0;
            const isCreditor = cp?.type === "seller" || cp?.type === "supplier" || (Number(cp?.balance) || 0) < 0;
            if (selectedSet.has("counterparts_debtors") && isDebtor) return false;
            if (selectedSet.has("counterparts_creditors") && isCreditor) return false;
            return true;
          });
          modifiedKeys["counterparts"] = serverMemoryStateCache["counterparts"];
          resetLabels.push("\u0632\u06CC\u0631\u0645\u062C\u0645\u0648\u0639\u0647\u200C\u0647\u0627\u06CC \u0627\u0646\u062A\u062E\u0627\u0628\u06CC \u0637\u0631\u0641 \u062D\u0633\u0627\u0628\u200C\u0647\u0627");
        }
        if (selectedSet.has("partners")) {
          serverMemoryStateCache["partners"] = [];
          modifiedKeys["partners"] = [];
          resetLabels.push("\u0634\u0631\u06A9\u0627 \u0648 \u0633\u0647\u0627\u0645\u062F\u0627\u0631\u0627\u0646");
        }
        if (selectedSet.has("fiscalYear")) {
          const defaultFy = { id: "fy-1403", year: "1403", startDate: "1403/01/01", endDate: "1403/12/29", registered: false, createdBy: "", setupDate: "" };
          serverMemoryStateCache["fiscalYear"] = defaultFy;
          serverMemoryStateCache["fiscalYearsList"] = [];
          serverMemoryStateCache["seq_doc_number"] = 1;
          modifiedKeys["fiscalYear"] = defaultFy;
          modifiedKeys["fiscalYearsList"] = [];
          modifiedKeys["seq_doc_number"] = 1;
          resetLabels.push("\u0633\u0627\u0644\u200C\u0647\u0627\u06CC \u0645\u0627\u0644\u06CC \u0648 \u0642\u0641\u0644 \u062F\u0641\u0627\u062A\u0631");
        }
        if (selectedSet.has("checklist")) {
          serverMemoryStateCache["checklist"] = [];
          modifiedKeys["checklist"] = [];
          resetLabels.push("\u06A9\u0644\u06CC\u0647 \u06CC\u0627\u062F\u062F\u0627\u0634\u062A\u200C\u0647\u0627 \u0648 \u0644\u06CC\u0633\u062A \u06A9\u0627\u0631\u0647\u0627");
        } else if (selectedSet.has("checklist_personal") || selectedSet.has("checklist_shared")) {
          const currentCl = Array.isArray(serverMemoryStateCache["checklist"]) ? serverMemoryStateCache["checklist"] : [];
          serverMemoryStateCache["checklist"] = currentCl.filter((c) => {
            const isShared = Boolean(c?.isPublic || c?.isShared);
            if (selectedSet.has("checklist_personal") && !isShared) return false;
            if (selectedSet.has("checklist_shared") && isShared) return false;
            return true;
          });
          modifiedKeys["checklist"] = serverMemoryStateCache["checklist"];
          resetLabels.push("\u0632\u06CC\u0631\u0645\u062C\u0645\u0648\u0639\u0647\u200C\u0647\u0627\u06CC \u0627\u0646\u062A\u062E\u0627\u0628\u06CC \u06CC\u0627\u062F\u062F\u0627\u0634\u062A\u200C\u0647\u0627");
        }
        if (selectedSet.has("notifications")) {
          serverMemoryStateCache["notifications"] = [];
          modifiedKeys["notifications"] = [];
          resetLabels.push("\u0627\u0639\u0644\u0627\u0646\u200C\u0647\u0627\u06CC \u0633\u06CC\u0633\u062A\u0645\u06CC");
        }
        if (selectedSet.has("webMessengers")) {
          serverMemoryStateCache["webMessengers"] = [];
          modifiedKeys["webMessengers"] = [];
          resetLabels.push("\u067E\u06CC\u0627\u0645\u200C\u0631\u0633\u0627\u0646\u200C\u0647\u0627\u06CC \u0648\u0628");
        }
        if (selectedSet.has("customMessengerIcons")) {
          serverMemoryStateCache["customMessengerIcons"] = [];
          serverMemoryStateCache["acc_system_custom_icons"] = [];
          modifiedKeys["customMessengerIcons"] = [];
          modifiedKeys["acc_system_custom_icons"] = [];
          resetLabels.push("\u0622\u06CC\u06A9\u0648\u0646\u200C\u0647\u0627\u06CC \u0633\u0641\u0627\u0631\u0634\u06CC \u067E\u06CC\u0627\u0645\u200C\u0631\u0633\u0627\u0646\u200C\u0647\u0627");
        }
        if (selectedSet.has("settings")) {
          const prevSettings = serverMemoryStateCache["settings"] && typeof serverMemoryStateCache["settings"] === "object" ? serverMemoryStateCache["settings"] : {};
          const cleanSettings = {
            ...prevSettings,
            sellerName: "",
            sellerAddress: "",
            sellerPhone: "",
            invoicePaperSize: "A4",
            font: "Vazirmatn",
            currency: "rial"
          };
          serverMemoryStateCache["settings"] = cleanSettings;
          modifiedKeys["settings"] = cleanSettings;
          resetLabels.push("\u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0639\u0645\u0648\u0645\u06CC \u0648 \u0645\u0634\u062E\u0635\u0627\u062A \u0641\u0631\u0648\u0634\u0646\u062F\u0647");
        }
        if (selectedSet.has("invoice_designer")) {
          serverMemoryStateCache["invoice_designer_settings"] = null;
          modifiedKeys["invoice_designer_settings"] = null;
          resetLabels.push("\u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0637\u0631\u0627\u062D \u0641\u0627\u06A9\u062A\u0648\u0631");
        }
        if (selectedSet.has("smart_assistant_chats")) {
          serverMemoryStateCache["smart_assistant_chats"] = [];
          modifiedKeys["smart_assistant_chats"] = [];
          resetLabels.push("\u062A\u0627\u0631\u06CC\u062E\u0686\u0647 \u062F\u0633\u062A\u06CC\u0627\u0631 \u0647\u0648\u0634\u0645\u0646\u062F");
        }
        if (selectedSet.has("system_logs")) {
          serverMemoryStateCache["system_logs"] = [];
          serverMemoryStateCache["auditLogs"] = [];
          modifiedKeys["system_logs"] = [];
          modifiedKeys["auditLogs"] = [];
          resetLabels.push("\u0644\u0627\u06AF\u200C\u0647\u0627 \u0648 \u0645\u0627\u0646\u06CC\u062A\u0648\u0631\u06CC\u0646\u06AF \u0633\u06CC\u0633\u062A\u0645");
        }
        if (selectedSet.has("uploaded_files")) {
          const uploadsDir = import_path.default.join(process.cwd(), "uploads");
          if (import_fs.default.existsSync(uploadsDir)) {
            try {
              import_fs.default.rmSync(uploadsDir, { recursive: true, force: true });
              import_fs.default.mkdirSync(uploadsDir, { recursive: true });
            } catch (e) {
              console.warn("Wipe uploads error:", e);
            }
          }
          resetLabels.push("\u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC \u067E\u06CC\u0648\u0633\u062A \u0648 \u0622\u067E\u0644\u0648\u062F\u0647\u0627\u06CC \u0647\u0627\u0633\u062A");
        }
        if (selectedSet.has("users")) {
          const existingUsers = Array.isArray(serverMemoryStateCache["users"]) && serverMemoryStateCache["users"].length > 0 ? serverMemoryStateCache["users"] : [];
          const sanitizedUsers = existingUsers.map((u, idx) => ({
            id: u.id || `user-${idx + 1}`,
            name: u.name || "\u06A9\u0627\u0631\u0628\u0631",
            phone: u.phone !== void 0 && u.phone !== null ? String(u.phone).trim() : "",
            username: u.username ? String(u.username).trim() : `user${idx + 1}`,
            role: u.role || "seller",
            password: u.password !== void 0 && u.password !== null ? String(u.password) : u.username ? String(u.username) : "",
            permissions: Array.isArray(u.permissions) && u.permissions.length > 0 ? [...u.permissions] : []
          }));
          serverMemoryStateCache["users"] = sanitizedUsers;
          modifiedKeys["users"] = sanitizedUsers;
          resetLabels.push("\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u067E\u0631\u0633\u0646\u0644 \u0648 \u06A9\u0627\u0631\u0628\u0631\u0627\u0646 (\u062A\u062B\u0628\u06CC\u062A \u0645\u0634\u062E\u0635\u0627\u062A \u0648\u0631\u0648\u062F)");
        }
        const now = Date.now();
        serverStateVersion = now;
        if (!keyVersions) keyVersions = {};
        for (const k of Object.keys(modifiedKeys)) {
          const cleanK = k.startsWith("acc_app_") ? k.substring(8) : k;
          const fullK = `acc_app_${cleanK}`;
          const val = modifiedKeys[k];
          serverMemoryStateCache[cleanK] = val;
          serverMemoryStateCache[fullK] = val;
          keyVersions[cleanK] = now;
          keyVersions[fullK] = now;
        }
        try {
          const keys = Object.keys(modifiedKeys);
          for (const rawKey of keys) {
            const cleanKey = rawKey.startsWith("acc_app_") ? rawKey.substring(8) : rawKey;
            const currentVal = serverMemoryStateCache[cleanKey];
            const serialized = typeof currentVal === "string" ? currentVal : JSON.stringify(currentVal);
            await executeMysqlQuery(
              "INSERT INTO app_state (state_key, state_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE state_value = VALUES(state_value), updated_at = CURRENT_TIMESTAMP",
              [cleanKey, serialized]
            );
          }
        } catch (mysqlErr) {
          console.error("MySQL wipe error:", mysqlErr.message);
          throw new Error(`\u062E\u0637\u0627 \u062F\u0631 \u062B\u0628\u062A \u062A\u063A\u06CC\u06CC\u0631\u0627\u062A \u062F\u0631 \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633 MySQL: ${mysqlErr.message}`);
        }
        return {
          status: "success",
          version: now,
          keyVersions,
          resetLabels,
          modifiedKeys
        };
      });
      return res.json({
        status: "success",
        message: "\u062A\u062E\u0644\u06CC\u0647 \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633 \u0631\u0648\u06CC \u0633\u0631\u0648\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u0646\u062C\u0627\u0645 \u0634\u062F \u0648 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0628\u0631\u0627\u06CC \u0647\u0645\u0647 \u067E\u0631\u0633\u0646\u0644 \u067E\u0627\u06A9\u0633\u0627\u0632\u06CC \u06AF\u0631\u062F\u06CC\u062F.",
        version: wipeResult.version,
        keyVersions: wipeResult.keyVersions,
        resetLabels: wipeResult.resetLabels,
        updatedKeys: wipeResult.modifiedKeys
      });
    } catch (err) {
      console.error("API error during database wipe:", err);
      return res.status(500).json({ status: "error", error: `\u062E\u0637\u0627 \u062F\u0631 \u062A\u062E\u0644\u06CC\u0647 \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633: ${err.message}` });
    }
  });
  app.all(["/api/db/migrate", "/api/migrate"], async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      if (!mysqlPool) {
        return res.status(500).json({
          status: "error",
          error: "\u0627\u062A\u0635\u0627\u0644 \u0628\u0647 \u067E\u0627\u06CC\u06AF\u0627\u0647\u200C\u062F\u0627\u062F\u0647 MySQL \u0628\u0631\u0642\u0631\u0627\u0631 \u0646\u06CC\u0633\u062A."
        });
      }
      const connection = await mysqlPool.getConnection();
      try {
        const includeData = req.query.data === "true" || req.query.data === "1" || req.body?.data === true;
        if (includeData) {
          const dataResult = await migrateAppStateDataToRelationalTables(connection);
          return res.json({
            status: dataResult.success ? "success" : "error",
            message: dataResult.success ? "\u0645\u0627\u06CC\u06AF\u0631\u06CC\u0634\u0646 \u0633\u0627\u062E\u062A\u0627\u0631 \u0648 \u0627\u0646\u062A\u0642\u0627\u0644 \u062F\u0627\u062F\u0647\u200C\u0647\u0627\u06CC JSON \u0645\u0648\u062C\u0648\u062F \u062F\u0631 app_state \u0628\u0647 \u062C\u062F\u0627\u0648\u0644 \u062A\u0641\u06A9\u06CC\u06A9\u06CC MySQL \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0648 \u0647\u0645\u0631\u0627\u0647 \u0628\u0627 \u062A\u0647\u06CC\u0647 \u0628\u06A9\u0627\u067E \u062E\u0648\u062F\u06A9\u0627\u0631 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F." : `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u062F\u0627\u062F\u0647\u200C\u0647\u0627: ${dataResult.error || "\u0628\u0631\u062E\u06CC \u062C\u062F\u0627\u0648\u0644 \u0646\u0627\u0645\u0648\u0641\u0642 \u0628\u0648\u062F\u0646\u062F"}`,
            dataResult
          });
        }
        const result = await runDatabaseMigrations(connection);
        return res.json({
          status: result.success ? "success" : "error",
          message: result.success ? "\u0645\u0627\u06CC\u06AF\u0631\u06CC\u0634\u0646 \u062C\u062F\u0627\u0648\u0644 \u067E\u0627\u06CC\u06AF\u0627\u0647\u200C\u062F\u0627\u062F\u0647 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0648 \u0628\u062F\u0648\u0646 \u062D\u0630\u0641 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0627\u062C\u0631\u0627 \u0634\u062F." : `\u062E\u0637\u0627 \u062F\u0631 \u0627\u062C\u0631\u0627\u06CC \u0645\u0627\u06CC\u06AF\u0631\u06CC\u0634\u0646: ${result.error}`,
          tables: result.tables,
          error: result.error
        });
      } finally {
        connection.release();
      }
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.all(["/api/db/migrate-data", "/api/migrate-data"], async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      if (!mysqlPool) {
        return res.status(500).json({
          status: "error",
          error: "\u0627\u062A\u0635\u0627\u0644 \u0628\u0647 \u067E\u0627\u06CC\u06AF\u0627\u0647\u200C\u062F\u0627\u062F\u0647 MySQL \u0628\u0631\u0642\u0631\u0627\u0631 \u0646\u06CC\u0633\u062A."
        });
      }
      const connection = await mysqlPool.getConnection();
      try {
        const migrationResult = await migrateAppStateDataToRelationalTables(connection);
        return res.json({
          status: migrationResult.success ? "success" : "warning",
          message: migrationResult.success ? "\u0627\u0646\u062A\u0642\u0627\u0644 \u0627\u0645\u0646\u060C \u062A\u0631\u0627\u06A9\u0646\u0634\u06CC \u0648 \u062A\u06A9\u0631\u0627\u0631\u067E\u0630\u06CC\u0631 \u062F\u0627\u062F\u0647\u200C\u0647\u0627\u06CC JSON \u0645\u0648\u062C\u0648\u062F \u062F\u0631 app_state \u0628\u0647 \u062C\u062F\u0627\u0648\u0644 \u0631\u0627\u0628\u0637\u0647\u200C\u0627\u06CC MySQL \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u0646\u062C\u0627\u0645 \u0634\u062F." : "\u0645\u0627\u06CC\u06AF\u0631\u06CC\u0634\u0646 \u062F\u0627\u062F\u0647\u200C\u0647\u0627 \u0628\u0627 \u0628\u0631\u062E\u06CC \u0647\u0634\u062F\u0627\u0631\u0647\u0627 \u06CC\u0627 \u062E\u0637\u0627\u0647\u0627 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.",
          ...migrationResult
        });
      } finally {
        connection.release();
      }
    } catch (err) {
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  let accountingSequenceMutex = Promise.resolve();
  const withAccountingMutex = (action) => {
    const prev = accountingSequenceMutex;
    let resolveLock = () => {
    };
    accountingSequenceMutex = new Promise((resolve) => {
      resolveLock = resolve;
    });
    return prev.then(action).finally(() => {
      resolveLock();
    });
  };
  app.post("/api/accounting/next-doc-number", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const result = await withAccountingMutex(async () => {
        const state = await loadAllData();
        let rawDocs = state.docs || state.acc_app_docs || [];
        if (typeof rawDocs === "string") {
          try {
            rawDocs = JSON.parse(rawDocs);
          } catch (_) {
            rawDocs = [];
          }
        }
        const docsList = Array.isArray(rawDocs) ? rawDocs : [];
        let maxExisting = 0;
        for (const doc of docsList) {
          const num = Number(doc?.docNumber);
          if (!isNaN(num) && num > maxExisting) {
            maxExisting = num;
          }
        }
        let highWaterMark = 100;
        const rawSeq = state.seq_doc_number || state.acc_app_seq_doc_number;
        if (rawSeq) {
          const parsedSeq = Number(rawSeq);
          if (!isNaN(parsedSeq) && parsedSeq > highWaterMark) {
            highWaterMark = parsedSeq;
          }
        }
        const nextDocNumber = Math.max(maxExisting, highWaterMark) + 1;
        await saveKeyData("seq_doc_number", nextDocNumber);
        return nextDocNumber;
      });
      return res.json({ status: "success", docNumber: result });
    } catch (err) {
      console.error("Error generating next doc number:", err);
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/accounting/next-invoice-number", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const { type = "sale", isProforma = false } = req.body || {};
      const result = await withAccountingMutex(async () => {
        const state = await loadAllData();
        let rawInvoices = state.invoices || state.acc_app_invoices || [];
        if (typeof rawInvoices === "string") {
          try {
            rawInvoices = JSON.parse(rawInvoices);
          } catch (_) {
            rawInvoices = [];
          }
        }
        const invoicesList = Array.isArray(rawInvoices) ? rawInvoices : [];
        let maxExistingSeq = 0;
        for (const inv of invoicesList) {
          const numStr = String(inv?.invoiceNumber || "");
          const isInvProforma = Boolean(inv?.isProforma || numStr.startsWith("PF-") || inv?.type === "proforma");
          if (isProforma) {
            if (isInvProforma) {
              const cleanNum = numStr.replace(/^[^\d]+/, "");
              const numPart = parseInt(cleanNum, 10);
              if (!isNaN(numPart) && numPart > maxExistingSeq) {
                maxExistingSeq = numPart;
              }
            }
          } else {
            if (!isInvProforma) {
              const cleanNum = numStr.replace(/^[^\d]+/, "");
              const numPart = parseInt(cleanNum, 10);
              if (!isNaN(numPart) && numPart > maxExistingSeq) {
                maxExistingSeq = numPart;
              }
            }
          }
        }
        const seqKey = isProforma ? "seq_pf_number" : "seq_inv_number";
        let highWaterMark = isProforma ? 5e3 : 1e3;
        const rawSeq = state[seqKey] || state[`acc_app_${seqKey}`];
        if (rawSeq) {
          const parsedSeq = Number(rawSeq);
          if (!isNaN(parsedSeq) && parsedSeq > highWaterMark) {
            highWaterMark = parsedSeq;
          }
        }
        const nextSeq = Math.max(maxExistingSeq, highWaterMark) + 1;
        await saveKeyData(seqKey, nextSeq);
        return isProforma ? `PF-${nextSeq}` : String(nextSeq);
      });
      return res.json({ status: "success", invoiceNumber: result });
    } catch (err) {
      console.error("Error generating next invoice number:", err);
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/accounting/post-document", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const { document, actor = {}, idempotencyKey } = req.body || {};
      if (!document || typeof document !== "object") {
        return res.status(400).json({ status: "error", error: "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0633\u0646\u062F \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      const result = await withAccountingMutex(async () => {
        const state = await loadAllData();
        let rawDocs = state.docs || state.acc_app_docs || [];
        if (typeof rawDocs === "string") {
          try {
            rawDocs = JSON.parse(rawDocs);
          } catch (_) {
            rawDocs = [];
          }
        }
        const docsList = Array.isArray(rawDocs) ? [...rawDocs] : [];
        if (idempotencyKey) {
          const existingByKey = docsList.find((d) => d && (d.idempotencyKey === idempotencyKey || d.id === idempotencyKey));
          if (existingByKey) {
            return { document: existingByKey, isIdempotentDuplicate: true };
          }
        }
        if (document.id) {
          const existingById = docsList.find((d) => d && d.id === document.id);
          if (existingById && existingById.status === "posted" && !document.isAmendment) {
            return { document: existingById, isIdempotentDuplicate: true };
          }
        }
        const rawLines = Array.isArray(document.lines) ? document.lines : [];
        if (rawLines.length < 2) {
          throw new Error("\u0633\u0646\u062F \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u0634\u0627\u0645\u0644 \u062F\u0648 \u0631\u062F\u06CC\u0641 (\u0628\u062F\u0647\u06A9\u0627\u0631 \u0648 \u0628\u0633\u062A\u0627\u0646\u06A9\u0627\u0631) \u0628\u0627\u0634\u062F.");
        }
        let debitSum = 0;
        let creditSum = 0;
        let hasDebit = false;
        let hasCredit = false;
        const cleanedLines = [];
        for (let i = 0; i < rawLines.length; i++) {
          const line = rawLines[i];
          const debit = Math.round(Number(line?.debit) || 0);
          const credit = Math.round(Number(line?.credit) || 0);
          const accountId = String(line?.accountId || "").trim();
          const accountName = String(line?.accountName || "").trim();
          if (debit < 0 || credit < 0) {
            throw new Error(`\u0645\u0628\u0644\u063A \u0631\u062F\u06CC\u0641 ${i + 1} (${accountName || accountId}) \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u0645\u0646\u0641\u06CC \u0628\u0627\u0634\u062F.`);
          }
          if (debit === 0 && credit === 0) {
            continue;
          }
          if (debit > 0 && credit > 0) {
            throw new Error(`\u0631\u062F\u06CC\u0641 ${i + 1} \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u0647\u0645\u0632\u0645\u0627\u0646 \u0628\u062F\u0647\u06A9\u0627\u0631 \u0648 \u0628\u0633\u062A\u0627\u0646\u06A9\u0627\u0631 \u0628\u0627\u0634\u062F.`);
          }
          if (!accountId && !accountName) {
            throw new Error(`\u0631\u062F\u06CC\u0641 ${i + 1} \u0641\u0627\u0642\u062F \u062D\u0633\u0627\u0628/\u0633\u0631\u0641\u0635\u0644 \u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A.`);
          }
          if (debit > 0) {
            hasDebit = true;
            debitSum += debit;
          }
          if (credit > 0) {
            hasCredit = true;
            creditSum += credit;
          }
          cleanedLines.push({
            id: line.id || `line-${Date.now()}-${i}`,
            accountId: accountId || "cost-sys",
            accountName: accountName || "\u0633\u0631\u0641\u0635\u0644 \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC",
            debit,
            credit,
            description: String(line.description || "").trim()
          });
        }
        if (cleanedLines.length < 2 || !hasDebit || !hasCredit) {
          throw new Error("\u0633\u0646\u062F \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u06CC\u06A9\u200C\u0637\u0631\u0641\u0647 \u06CC\u0627 \u0641\u0627\u0642\u062F \u0631\u062F\u06CC\u0641\u200C\u0647\u0627\u06CC \u0645\u0639\u062A\u0628\u0631 \u062F\u0627\u0631\u0627\u06CC \u0645\u0628\u0644\u063A \u0627\u0633\u062A.");
        }
        const diff = Math.abs(debitSum - creditSum);
        if (diff > 0) {
          throw new Error(`\u0633\u0646\u062F \u062A\u0631\u0627\u0632 \u0646\u06CC\u0633\u062A! \u0645\u062C\u0645\u0648\u0639 \u0628\u062F\u0647\u06A9\u0627\u0631 (${debitSum}) \u0628\u0627 \u0645\u062C\u0645\u0648\u0639 \u0628\u0633\u062A\u0627\u0646\u06A9\u0627\u0631 (${creditSum}) \u0628\u0631\u0627\u0628\u0631 \u0646\u06CC\u0633\u062A.`);
        }
        let docNumber = Number(document.docNumber);
        if (isNaN(docNumber) || docNumber <= 0) {
          let maxExisting = 0;
          for (const d of docsList) {
            const n = Number(d?.docNumber);
            if (!isNaN(n) && n > maxExisting) maxExisting = n;
          }
          let highWaterMark = 100;
          const rawSeq = state.seq_doc_number || state.acc_app_seq_doc_number;
          if (rawSeq) {
            const p = Number(rawSeq);
            if (!isNaN(p) && p > highWaterMark) highWaterMark = p;
          }
          docNumber = Math.max(maxExisting, highWaterMark) + 1;
          await saveKeyData("seq_doc_number", docNumber);
        } else {
          const isConflict = docsList.some((d) => d && d.id !== document.id && Number(d.docNumber) === docNumber && !d.isDeleted);
          if (isConflict) {
            let safeNum = docNumber;
            const existingSet = new Set(docsList.map((d) => Number(d?.docNumber) || 0));
            while (existingSet.has(safeNum)) {
              safeNum++;
            }
            docNumber = safeNum;
            await saveKeyData("seq_doc_number", docNumber);
          }
        }
        const postedDoc = {
          id: document.id || `doc-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          docNumber,
          date: document.date || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
          description: String(document.description || "").trim(),
          lines: cleanedLines,
          isArchived: Boolean(document.isArchived),
          isManual: Boolean(document.isManual),
          status: "posted",
          invoiceId: document.invoiceId,
          txId: document.txId,
          refDocId: document.refDocId,
          idempotencyKey: idempotencyKey || document.idempotencyKey,
          actorId: actor.id || actor.createdById,
          actorName: actor.name || actor.createdBy,
          operationType: document.operationType || "manual",
          postedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        const existingIdx = docsList.findIndex((d) => d && d.id === postedDoc.id);
        if (existingIdx >= 0) {
          docsList[existingIdx] = postedDoc;
        } else {
          docsList.unshift(postedDoc);
        }
        await saveKeyData("docs", docsList);
        let rawAuditLogs = state.auditLogs || state.acc_app_auditLogs || [];
        if (typeof rawAuditLogs === "string") {
          try {
            rawAuditLogs = JSON.parse(rawAuditLogs);
          } catch (_) {
            rawAuditLogs = [];
          }
        }
        const auditLogs = Array.isArray(rawAuditLogs) ? [...rawAuditLogs] : [];
        const auditEntry = {
          id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          timestampMs: Date.now(),
          actorId: actor.id || "system",
          actorName: actor.name || "\u0633\u06CC\u0633\u062A\u0645 \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC",
          actorRole: actor.role || "accountant",
          action: "POST_DOCUMENT",
          entityType: "document",
          entityId: postedDoc.id,
          entityRefNumber: String(postedDoc.docNumber),
          idempotencyKey,
          details: {
            debitSum,
            creditSum,
            linesCount: cleanedLines.length,
            operationType: postedDoc.operationType
          }
        };
        auditLogs.unshift(auditEntry);
        await saveKeyData("auditLogs", auditLogs.slice(0, 5e3));
        return { document: postedDoc, isIdempotentDuplicate: false };
      });
      return res.json({ status: "success", document: result.document, idempotent: result.isIdempotentDuplicate });
    } catch (err) {
      console.error("Error posting accounting document:", err);
      return res.status(400).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/accounting/post-allocation", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const { allocations = [], actor = {}, idempotencyKey } = req.body || {};
      const allocsList = Array.isArray(allocations) ? allocations : [allocations];
      if (allocsList.length === 0) {
        return res.status(400).json({ status: "error", error: "\u0647\u06CC\u0686 \u062A\u062E\u0635\u06CC\u0635 \u067E\u0631\u062F\u0627\u062E\u062A\u06CC \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      const result = await withAccountingMutex(async () => {
        const state = await loadAllData();
        let rawExisting = state.paymentAllocations || state.acc_app_paymentAllocations || [];
        if (typeof rawExisting === "string") {
          try {
            rawExisting = JSON.parse(rawExisting);
          } catch (_) {
            rawExisting = [];
          }
        }
        const existingAllocations = Array.isArray(rawExisting) ? [...rawExisting] : [];
        const newlyAdded = [];
        for (const alloc of allocsList) {
          if (!alloc || !alloc.invoiceId || !alloc.allocatedAmount) continue;
          const isDup = existingAllocations.some(
            (ea) => ea && (ea.id === alloc.id || ea.paymentId === alloc.paymentId && ea.invoiceId === alloc.invoiceId && Math.abs(ea.allocatedAmount - alloc.allocatedAmount) < 0.01 && ea.status === "valid")
          );
          if (isDup) continue;
          const newAlloc = {
            id: alloc.id || `alloc-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            paymentId: alloc.paymentId || `pay-${Date.now()}`,
            invoiceId: alloc.invoiceId,
            invoiceNumber: String(alloc.invoiceNumber || ""),
            counterpartId: alloc.counterpartId,
            counterpartName: alloc.counterpartName,
            allocatedAmount: Number(alloc.allocatedAmount) || 0,
            allocationDate: alloc.allocationDate || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
            paymentMethod: alloc.paymentMethod || "bank_transfer",
            accountId: alloc.accountId,
            status: "valid",
            docId: alloc.docId,
            notes: alloc.notes || "",
            createdAt: (/* @__PURE__ */ new Date()).toISOString(),
            createdBy: actor.name || "\u0633\u06CC\u0633\u062A\u0645",
            createdById: actor.id || "system"
          };
          existingAllocations.unshift(newAlloc);
          newlyAdded.push(newAlloc);
        }
        await saveKeyData("paymentAllocations", existingAllocations);
        return newlyAdded;
      });
      return res.json({ status: "success", allocations: result });
    } catch (err) {
      console.error("Error posting payment allocation:", err);
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/accounting/reverse-allocation", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const { allocationId, reason = "\u0627\u0635\u0644\u0627\u062D \u0648 \u0644\u063A\u0648 \u062A\u062E\u0635\u06CC\u0635 \u067E\u0631\u062F\u0627\u062E\u062A", actor = {} } = req.body || {};
      if (!allocationId) {
        return res.status(400).json({ status: "error", error: "\u0634\u0646\u0627\u0633\u0647 \u062A\u062E\u0635\u06CC\u0635 \u067E\u0631\u062F\u0627\u062E\u062A \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      const result = await withAccountingMutex(async () => {
        const state = await loadAllData();
        let rawExisting = state.paymentAllocations || state.acc_app_paymentAllocations || [];
        if (typeof rawExisting === "string") {
          try {
            rawExisting = JSON.parse(rawExisting);
          } catch (_) {
            rawExisting = [];
          }
        }
        const existingAllocations = Array.isArray(rawExisting) ? [...rawExisting] : [];
        const targetAlloc = existingAllocations.find((a) => a && a.id === allocationId);
        if (!targetAlloc) {
          throw new Error("\u062A\u062E\u0635\u06CC\u0635 \u067E\u0631\u062F\u0627\u062E\u062A \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F.");
        }
        targetAlloc.status = "reversed";
        targetAlloc.reversalReason = reason;
        targetAlloc.reversalDate = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
        targetAlloc.reversedBy = actor.name || "\u06A9\u0627\u0631\u0628\u0631";
        await saveKeyData("paymentAllocations", existingAllocations);
        return targetAlloc;
      });
      return res.json({ status: "success", allocation: result });
    } catch (err) {
      console.error("Error reversing allocation:", err);
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/inventory/movement", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
      const { movement, actor = {} } = req.body || {};
      if (!movement || !movement.itemId && !movement.itemName) {
        return res.status(400).json({ status: "error", error: "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u06AF\u0631\u062F\u0634 \u0627\u0646\u0628\u0627\u0631 \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      if (movement.itemType === "khadamat" || movement.type === "khadamat") {
        return res.json({ status: "success", data: { skipped: true } });
      }
      const result = await withAccountingMutex(async () => {
        const state = await loadAllData();
        let rawItems = state.items || state.acc_app_items || state.warehouseItems || state.acc_app_warehouseItems || [];
        if (typeof rawItems === "string") {
          try {
            rawItems = JSON.parse(rawItems);
          } catch (_) {
            rawItems = [];
          }
        }
        const itemsList = Array.isArray(rawItems) ? [...rawItems] : [];
        let rawMovements = state.inventoryMovements || state.acc_app_inventoryMovements || [];
        if (typeof rawMovements === "string") {
          try {
            rawMovements = JSON.parse(rawMovements);
          } catch (_) {
            rawMovements = [];
          }
        }
        const movementsList = Array.isArray(rawMovements) ? [...rawMovements] : [];
        const targetId = String(movement.itemId || "").trim().toLowerCase();
        const targetName = String(movement.itemName || "").trim().toLowerCase();
        let targetItem = itemsList.find((i) => {
          if (!i) return false;
          const itemIdStr = String(i.id || "").trim().toLowerCase();
          const itemCodeStr = String(i.code || "").trim().toLowerCase();
          const itemNameStr = String(i.name || "").trim().toLowerCase();
          return targetId && (itemIdStr === targetId || itemCodeStr === targetId) || targetName && itemNameStr === targetName || targetId && itemNameStr === targetId;
        });
        if (!targetItem) {
          targetItem = {
            id: movement.itemId || `item-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            code: `K-${Date.now().toString().slice(-4)}`,
            name: movement.itemName || "\u06A9\u0627\u0644\u0627\u06CC \u062C\u062F\u06CC\u062F",
            category: "\u0639\u0645\u0648\u0645\u06CC",
            type: "kala",
            qty: 0,
            unit: movement.unit || "\u0639\u062F\u062F",
            purchasePrice: Number(movement.unitCost) || 0,
            salePrice: Number(movement.unitCost) || 0,
            lastPurchasePrice: Number(movement.unitCost) || 0,
            minStock: 0,
            createdAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          itemsList.push(targetItem);
        }
        const isFromInvoice = Boolean(
          movement.fromInvoice || movement.referenceId || movement.invoiceId || movement.reason && movement.reason.includes("\u0641\u0627\u06A9\u062A\u0648\u0631") || movement.description && movement.description.includes("\u0641\u0627\u06A9\u062A\u0648\u0631")
        );
        const qtyChange = Number(movement.qtyChange) || 0;
        const currentQty = Number(targetItem.qty) || 0;
        let newQty;
        if (isFromInvoice) {
          newQty = movement.remainingQtyAfter !== void 0 && !isNaN(Number(movement.remainingQtyAfter)) ? Number(movement.remainingQtyAfter) : currentQty;
        } else {
          newQty = currentQty + qtyChange;
        }
        targetItem.qty = newQty;
        if (movement.unitCost && Number(movement.unitCost) > 0) {
          if (movement.movementType === "inflow_purchase" || movement.type === "purchase_in") {
            targetItem.lastPurchasePrice = Number(movement.unitCost);
          }
        }
        const movementRecord = {
          id: movement.id || `mov-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          itemId: targetItem.id,
          itemName: targetItem.name || movement.itemName || "\u06A9\u0627\u0644\u0627",
          movementType: movement.movementType || (qtyChange < 0 ? "outflow_sale" : "inflow_purchase"),
          qtyChange,
          unitCost: Number(movement.unitCost) || targetItem.lastPurchasePrice || 0,
          totalCost: (Number(movement.unitCost) || targetItem.lastPurchasePrice || 0) * Math.abs(qtyChange),
          remainingQtyAfter: newQty,
          date: movement.date || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
          time: movement.time || (/* @__PURE__ */ new Date()).toTimeString().slice(0, 5),
          referenceId: movement.referenceId,
          referenceNumber: movement.referenceNumber,
          reason: movement.reason || "",
          docId: movement.docId,
          createdBy: actor.name || "\u0633\u06CC\u0633\u062A\u0645",
          createdById: actor.id || "system",
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        movementsList.unshift(movementRecord);
        await saveKeyData("items", itemsList);
        await saveKeyData("inventoryMovements", movementsList);
        return { item: targetItem, movement: movementRecord };
      });
      return res.json({ status: "success", data: result });
    } catch (err) {
      console.error("Error recording inventory movement:", err);
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  const normalizeAuthString = (str) => {
    if (str === void 0 || str === null) return "";
    let s = String(str).trim();
    s = s.replace(/[\u200B-\u200D\uFEFF\u00A0\r\n\t]/g, "");
    const persianDigits = ["\u06F0", "\u06F1", "\u06F2", "\u06F3", "\u06F4", "\u06F5", "\u06F6", "\u06F7", "\u06F8", "\u06F9"];
    const arabicDigits = ["\u0660", "\u0661", "\u0662", "\u0663", "\u0664", "\u0665", "\u0666", "\u0667", "\u0668", "\u0669"];
    for (let i = 0; i < 10; i++) {
      s = s.replace(new RegExp(persianDigits[i], "g"), String(i));
      s = s.replace(new RegExp(arabicDigits[i], "g"), String(i));
    }
    s = s.replace(/\u064A/g, "\u06CC");
    s = s.replace(/\u0649/g, "\u06CC");
    s = s.replace(/\u0643/g, "\u06A9");
    s = s.replace(/\u0629/g, "\u0647");
    return s.trim();
  };
  const normalizeUsername = (str) => {
    return normalizeAuthString(str).toLowerCase().replace(/\s+/g, "");
  };
  app.get("/api/auth/users", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      const state = await loadAllData();
      let rawUsers = state.users || state.acc_app_users;
      const usersList = Array.isArray(rawUsers) ? rawUsers : typeof rawUsers === "string" ? JSON.parse(rawUsers) : [];
      return res.json({ status: "success", users: usersList });
    } catch (err) {
      console.error("Error fetching users for auth:", err);
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/auth/login", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      const { username, password } = req.body || {};
      if (!username || password === void 0) {
        return res.status(400).json({ status: "error", error: "\u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u0648 \u06A9\u0644\u0645\u0647 \u0639\u0628\u0648\u0631 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A." });
      }
      const inputUserNorm = normalizeUsername(username);
      const inputPassNorm = normalizeAuthString(password);
      const state = await loadAllData();
      let rawUsers = state.users || state.acc_app_users;
      if (typeof rawUsers === "string") {
        try {
          rawUsers = JSON.parse(rawUsers);
        } catch (_) {
          rawUsers = [];
        }
      }
      const usersList = Array.isArray(rawUsers) ? rawUsers : [];
      if (usersList.length === 0) {
        return res.status(401).json({
          status: "error",
          code: "NO_USERS",
          error: "\u0647\u06CC\u0686 \u06A9\u0627\u0631\u0628\u0631\u06CC \u062F\u0631 \u067E\u0627\u06CC\u06AF\u0627\u0647\u200C\u062F\u0627\u062F\u0647 \u062B\u0628\u062A \u0646\u0634\u062F\u0647 \u0627\u0633\u062A. \u0644\u0637\u0641\u0627\u064B \u0627\u0632 \u0637\u0631\u06CC\u0642 \u0641\u0631\u0645 \u0631\u0627\u0647\u200C\u0627\u0646\u062F\u0627\u0632\u06CC \u0627\u0648\u0644\u06CC\u0647\u060C \u062D\u0633\u0627\u0628 \u0645\u062F\u06CC\u0631 \u06A9\u0644 \u0631\u0627 \u0627\u06CC\u062C\u0627\u062F \u0641\u0631\u0645\u0627\u06CC\u06CC\u062F."
        });
      }
      const matchedUser = usersList.find((u) => {
        if (!u) return false;
        const uNameNorm = normalizeUsername(u.username || "");
        const uPhoneNorm = normalizeAuthString(u.phone || "");
        return uNameNorm && uNameNorm === inputUserNorm || uPhoneNorm && uPhoneNorm === inputUserNorm;
      });
      if (!matchedUser) {
        return res.status(401).json({ status: "error", error: "\u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u06CC\u0627 \u06A9\u0644\u0645\u0647 \u0639\u0628\u0648\u0631 \u0648\u0627\u0631\u062F \u0634\u062F\u0647 \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A." });
      }
      const storedPassRaw = matchedUser.password !== void 0 && matchedUser.password !== null ? String(matchedUser.password) : matchedUser.username || "";
      const storedPassNorm = normalizeAuthString(storedPassRaw);
      const isPassValid = inputPassNorm === storedPassNorm || String(password).trim() === storedPassRaw.trim() || normalizeAuthString(password).trim() === storedPassRaw.trim() || storedPassNorm === "" && inputPassNorm === normalizeUsername(matchedUser.username);
      if (!isPassValid) {
        return res.status(401).json({ status: "error", error: "\u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u06CC\u0627 \u06A9\u0644\u0645\u0647 \u0639\u0628\u0648\u0631 \u0648\u0627\u0631\u062F \u0634\u062F\u0647 \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A." });
      }
      return res.json({ status: "success", user: matchedUser, users: usersList });
    } catch (err) {
      console.error("API error during login:", err);
      return res.status(500).json({ status: "error", error: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u062D\u0631\u0627\u0632 \u0647\u0648\u06CC\u062A: ${err.message}` });
    }
  });
  app.post("/api/auth/setup-initial-admin", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      const { name, username, password, phone } = req.body || {};
      if (!name || !username || !password) {
        return res.status(400).json({ status: "error", error: "\u0646\u0627\u0645\u060C \u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u0648 \u06A9\u0644\u0645\u0647 \u0639\u0628\u0648\u0631 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A." });
      }
      const cleanUser = normalizeUsername(String(username));
      const cleanPass = normalizeAuthString(String(password));
      const cleanName = String(name).trim();
      const cleanPhone = phone ? normalizeAuthString(String(phone)) : "";
      const state = await loadAllData();
      let rawUsers = state.users || state.acc_app_users;
      if (typeof rawUsers === "string") {
        try {
          rawUsers = JSON.parse(rawUsers);
        } catch (_) {
          rawUsers = [];
        }
      }
      const usersList = Array.isArray(rawUsers) ? rawUsers : [];
      if (usersList.length > 0) {
        return res.status(400).json({ status: "error", error: "\u06A9\u0627\u0631\u0628\u0631\u0627\u0646 \u0633\u06CC\u0633\u062A\u0645 \u0642\u0628\u0644\u0627\u064B \u062F\u0631 \u067E\u0627\u06CC\u06AF\u0627\u0647\u200C\u062F\u0627\u062F\u0647 \u0627\u06CC\u062C\u0627\u062F \u0634\u062F\u0647\u200C\u0627\u0646\u062F. \u0644\u0637\u0641\u0627\u064B \u0648\u0627\u0631\u062F \u0634\u0648\u06CC\u062F." });
      }
      const newAdmin = {
        id: `user-${Date.now()}`,
        name: cleanName,
        username: cleanUser,
        password: cleanPass,
        role: "admin",
        phone: cleanPhone,
        permissions: [
          "dashboard",
          "invoices",
          "warehouse",
          "accounting",
          "counterparts",
          "reports",
          "banking",
          "users",
          "settings",
          "ai_assistant",
          "fiscal_year",
          "logs"
        ]
      };
      const updatedUsers = [newAdmin];
      await saveKeyData("users", updatedUsers, { forceOverwrite: true });
      await saveKeyData("acc_app_users", updatedUsers, { forceOverwrite: true });
      return res.json({
        status: "success",
        message: "\u062D\u0633\u0627\u0628 \u0645\u062F\u06CC\u0631 \u0627\u0631\u0634\u062F \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633 MySQL \u0627\u06CC\u062C\u0627\u062F \u0634\u062F.",
        user: newAdmin,
        users: updatedUsers
      });
    } catch (err) {
      console.error("Initial Admin Setup error:", err);
      return res.status(500).json({ status: "error", error: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u06CC\u062C\u0627\u062F \u0645\u062F\u06CC\u0631 \u0627\u0648\u0644\u06CC\u0647: ${err.message}` });
    }
  });
  app.post("/api/auth/update-credentials", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      const { updatedUsers } = req.body || {};
      if (!Array.isArray(updatedUsers) || updatedUsers.length === 0) {
        return res.status(400).json({ status: "error", error: "\u0644\u06CC\u0633\u062A \u06A9\u0627\u0631\u0628\u0631\u0627\u0646 \u0627\u0631\u0633\u0627\u0644\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A." });
      }
      const normalizedUsers = updatedUsers.map((u) => ({
        ...u,
        username: normalizeUsername(u.username || ""),
        password: normalizeAuthString(u.password !== void 0 && u.password !== null ? String(u.password) : u.username || ""),
        phone: normalizeAuthString(u.phone || "")
      }));
      await saveKeyData("users", normalizedUsers, { forceOverwrite: true });
      await saveKeyData("acc_app_users", normalizedUsers, { forceOverwrite: true });
      return res.json({ status: "success", users: normalizedUsers });
    } catch (err) {
      console.error("API error updating credentials:", err);
      return res.status(500).json({ status: "error", error: `\u062E\u0637\u0627 \u062F\u0631 \u0630\u062E\u06CC\u0631\u0647 \u0645\u0634\u062E\u0635\u0627\u062A \u067E\u0631\u0633\u0646\u0644: ${err.message}` });
    }
  });
  const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1e3;
  const purgeOldServerLogs = (logs, maxAgeMs = SEVEN_DAYS_MS) => {
    if (!Array.isArray(logs)) return { validLogs: [], purgedCount: 0 };
    const cutoffTime = Date.now() - maxAgeMs;
    const validLogs = logs.filter((l) => {
      if (!l) return false;
      const t = typeof l.timestampMs === "number" ? l.timestampMs : new Date(l.timestamp).getTime() || 0;
      return t >= cutoffTime;
    });
    return { validLogs, purgedCount: logs.length - validLogs.length };
  };
  app.get("/api/system/logs", async (req, res) => {
    try {
      const state = await loadAllData();
      let rawLogs = state.system_logs || state.acc_app_system_logs || [];
      if (typeof rawLogs === "string") {
        try {
          rawLogs = JSON.parse(rawLogs);
        } catch (_) {
          rawLogs = [];
        }
      }
      const logsArray = Array.isArray(rawLogs) ? rawLogs : [];
      const { validLogs, purgedCount } = purgeOldServerLogs(logsArray);
      if (purgedCount > 0) {
        await saveKeyData("system_logs", validLogs);
        await saveKeyData("acc_app_system_logs", validLogs);
      }
      return res.json({
        status: "success",
        logs: validLogs,
        totalCount: validLogs.length,
        autoPurgedCount: purgedCount
      });
    } catch (err) {
      console.error("Error loading system logs:", err);
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/system/logs", async (req, res) => {
    try {
      const { log, logs } = req.body || {};
      const newItems = Array.isArray(logs) ? logs : log ? [log] : [];
      if (newItems.length === 0) {
        return res.json({ status: "success", count: 0 });
      }
      const state = await loadAllData();
      let rawLogs = state.system_logs || state.acc_app_system_logs || [];
      if (typeof rawLogs === "string") {
        try {
          rawLogs = JSON.parse(rawLogs);
        } catch (_) {
          rawLogs = [];
        }
      }
      const currentLogs = Array.isArray(rawLogs) ? rawLogs : [];
      const combined = [...newItems, ...currentLogs];
      const uniqueMap = /* @__PURE__ */ new Map();
      for (const item of combined) {
        if (item && item.id && !uniqueMap.has(item.id)) {
          uniqueMap.set(item.id, item);
        }
      }
      const allUnique = Array.from(uniqueMap.values());
      const { validLogs } = purgeOldServerLogs(allUnique);
      const finalLogs = validLogs.slice(0, 3e3);
      await saveKeyData("system_logs", finalLogs);
      await saveKeyData("acc_app_system_logs", finalLogs);
      return res.json({ status: "success", totalCount: finalLogs.length });
    } catch (err) {
      console.error("Error saving system log:", err);
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/system/logs/delete", async (req, res) => {
    try {
      const { logIds, purgeAll } = req.body || {};
      if (purgeAll) {
        await saveKeyData("system_logs", []);
        await saveKeyData("acc_app_system_logs", []);
        return res.json({ status: "success", deletedCount: "all", remainingCount: 0 });
      }
      if (!Array.isArray(logIds) || logIds.length === 0) {
        return res.status(400).json({ status: "error", error: "\u0634\u0646\u0627\u0633\u0647 \u0644\u0627\u06AF\u200C\u0647\u0627\u06CC \u0645\u062F\u0646\u0638\u0631 \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      const state = await loadAllData();
      let rawLogs = state.system_logs || state.acc_app_system_logs || [];
      if (typeof rawLogs === "string") {
        try {
          rawLogs = JSON.parse(rawLogs);
        } catch (_) {
          rawLogs = [];
        }
      }
      const currentLogs = Array.isArray(rawLogs) ? rawLogs : [];
      const idSet = new Set(logIds);
      const remaining = currentLogs.filter((l) => !idSet.has(l.id));
      await saveKeyData("system_logs", remaining);
      await saveKeyData("acc_app_system_logs", remaining);
      return res.json({
        status: "success",
        deletedCount: currentLogs.length - remaining.length,
        remainingCount: remaining.length
      });
    } catch (err) {
      console.error("Error deleting system logs:", err);
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/system/logs/purge-old", async (req, res) => {
    try {
      const { maxAgeDays } = req.body || {};
      const maxAgeMs = (Number(maxAgeDays) || 7) * 24 * 60 * 60 * 1e3;
      const state = await loadAllData();
      let rawLogs = state.system_logs || state.acc_app_system_logs || [];
      if (typeof rawLogs === "string") {
        try {
          rawLogs = JSON.parse(rawLogs);
        } catch (_) {
          rawLogs = [];
        }
      }
      const currentLogs = Array.isArray(rawLogs) ? rawLogs : [];
      const { validLogs, purgedCount } = purgeOldServerLogs(currentLogs, maxAgeMs);
      if (purgedCount > 0) {
        await saveKeyData("system_logs", validLogs);
        await saveKeyData("acc_app_system_logs", validLogs);
      }
      return res.json({
        status: "success",
        purgedCount,
        remainingCount: validLogs.length
      });
    } catch (err) {
      console.error("Error purging old system logs:", err);
      return res.status(500).json({ status: "error", error: err.message });
    }
  });
  app.post("/api/backup/export", async (req, res) => {
    try {
      const { clientLocalStorage = {}, selectedSections = null } = req.body || {};
      const ALL_BACKUP_SECTION_IDS = [
        "users",
        "transactions",
        "finalInvoices",
        "proformas",
        "goods",
        "services",
        "accountingDocs",
        "counterparts",
        "accounts",
        "categories",
        "partnersLoans",
        "checklist",
        "settingsTheme",
        "uploads",
        "logs"
      ];
      const isAllSelected = !selectedSections || selectedSections === "all" || Array.isArray(selectedSections) && ALL_BACKUP_SECTION_IDS.every((s) => selectedSections.includes(s));
      const isPartial = !isAllSelected;
      const dbData = await loadAllData();
      const sanitizedDbData = { ...dbData };
      delete sanitizedDbData.geminiApiKey;
      delete sanitizedDbData.acc_app_geminiApiKey;
      const shouldIncludeUploads = !isPartial || Array.isArray(selectedSections) && selectedSections.includes("uploads");
      const uploadsMap = {};
      const uploadsDirs = [
        import_path.default.join(process.cwd(), "uploads"),
        import_path.default.join(process.cwd(), "public", "uploads"),
        import_path.default.join(process.cwd(), "data", "uploads")
      ];
      if (shouldIncludeUploads) {
        for (const dir of uploadsDirs) {
          if (import_fs.default.existsSync(dir)) {
            const scanDir = (currentDir) => {
              const files = import_fs.default.readdirSync(currentDir);
              for (const file of files) {
                const fullPath = import_path.default.join(currentDir, file);
                if (import_fs.default.statSync(fullPath).isDirectory()) {
                  scanDir(fullPath);
                } else {
                  try {
                    const fileBuf = import_fs.default.readFileSync(fullPath);
                    const relPath = import_path.default.relative(process.cwd(), fullPath).replace(/\\/g, "/");
                    uploadsMap[relPath] = fileBuf.toString("base64");
                  } catch (e) {
                    console.warn(`Could not read file ${fullPath}:`, e);
                  }
                }
              }
            };
            scanDir(dir);
          }
        }
      }
      let finalDbData = {};
      let finalLocalStorage = {};
      const SECTION_TITLES = {
        users: "\u06A9\u0627\u0631\u0628\u0631\u0627\u0646 \u0648 \u067E\u0631\u0633\u0646\u0644",
        transactions: "\u062A\u0631\u0627\u06A9\u0646\u0634\u200C\u0647\u0627 \u0648 \u0627\u0645\u0648\u0631 \u0628\u0627\u0646\u06A9\u06CC",
        finalInvoices: "\u0641\u0627\u06A9\u062A\u0648\u0631\u0647\u0627\u06CC \u0642\u0637\u0639\u06CC \u062E\u0631\u06CC\u062F \u0648 \u0641\u0631\u0648\u0634",
        proformas: "\u067E\u06CC\u0634\u200C\u0641\u0627\u06A9\u062A\u0648\u0631\u0647\u0627 \u0648 \u0633\u0641\u0627\u0631\u0634\u0627\u062A",
        goods: "\u06A9\u0627\u0644\u0627\u0647\u0627 \u0648 \u0645\u0648\u062C\u0648\u062F\u06CC \u0627\u0646\u0628\u0627\u0631",
        services: "\u062E\u062F\u0645\u0627\u062A \u0648 \u0627\u062C\u0631\u062A\u200C\u0647\u0627",
        accountingDocs: "\u0627\u0633\u0646\u0627\u062F \u062F\u0648\u0628\u0644 \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0648 \u0633\u0627\u0644 \u0645\u0627\u0644\u06CC",
        counterparts: "\u0637\u0631\u0641\u200C\u062D\u0633\u0627\u0628\u200C\u0647\u0627 \u0648 \u0645\u062E\u0627\u0637\u0628\u06CC\u0646",
        accounts: "\u062D\u0633\u0627\u0628\u200C\u0647\u0627 \u0648 \u0635\u0646\u062F\u0648\u0642\u200C\u0647\u0627",
        categories: "\u0633\u0631\u0641\u0635\u0644\u200C\u0647\u0627 \u0648 \u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u067E\u0648\u0631\u0633\u0627\u0646\u062A",
        partnersLoans: "\u0634\u0631\u06A9\u0627 \u0648 \u062A\u0633\u0647\u06CC\u0644\u0627\u062A \u0648\u0627\u0645",
        checklist: "\u06CC\u0627\u062F\u062F\u0627\u0634\u062A\u200C\u0647\u0627 \u0648 \u0686\u06A9\u200C\u0644\u06CC\u0633\u062A",
        settingsTheme: "\u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0639\u0645\u0648\u0645\u06CC \u0648 \u0638\u0627\u0647\u0631",
        uploads: "\u0641\u0627\u06CC\u0644\u200C\u0647\u0627 \u0648 \u062A\u0635\u0627\u0648\u06CC\u0631 \u067E\u06CC\u0648\u0633\u062A",
        logs: "\u0644\u0627\u06AF\u200C\u0647\u0627\u06CC \u0627\u0645\u0646\u06CC\u062A\u06CC \u0648 \u0633\u06CC\u0633\u062A\u0645\u06CC"
      };
      const isInvoiceProforma = (inv) => {
        if (!inv) return false;
        return Boolean(
          inv.isProforma === true || inv.isProforma === "true" || inv.type === "proforma" || inv.status === "proforma" || typeof inv.invoiceNumber === "string" && inv.invoiceNumber.trim().toUpperCase().startsWith("PF-") || typeof inv.title === "string" && inv.title.includes("\u067E\u06CC\u0634\u200C\u0641\u0627\u06A9\u062A\u0648\u0631")
        );
      };
      if (!isPartial) {
        finalDbData = sanitizedDbData;
        finalLocalStorage = clientLocalStorage;
      } else {
        const sectionSet = new Set(Array.isArray(selectedSections) ? selectedSections : []);
        if (sectionSet.has("users")) {
          if (sanitizedDbData.users !== void 0) finalDbData.users = sanitizedDbData.users;
          if (sanitizedDbData.acc_app_users !== void 0) finalDbData.acc_app_users = sanitizedDbData.acc_app_users;
          if (sanitizedDbData.currentUser !== void 0) finalDbData.currentUser = sanitizedDbData.currentUser;
          if (sanitizedDbData.acc_app_currentUser !== void 0) finalDbData.acc_app_currentUser = sanitizedDbData.acc_app_currentUser;
          if (sanitizedDbData.primaryUserRole !== void 0) finalDbData.primaryUserRole = sanitizedDbData.primaryUserRole;
          if (sanitizedDbData.acc_app_primaryUserRole !== void 0) finalDbData.acc_app_primaryUserRole = sanitizedDbData.acc_app_primaryUserRole;
        }
        if (sectionSet.has("transactions")) {
          if (sanitizedDbData.transactions !== void 0) finalDbData.transactions = sanitizedDbData.transactions;
          if (sanitizedDbData.acc_app_transactions !== void 0) finalDbData.acc_app_transactions = sanitizedDbData.acc_app_transactions;
          if (sanitizedDbData.pendingDeposits !== void 0) finalDbData.pendingDeposits = sanitizedDbData.pendingDeposits;
          if (sanitizedDbData.acc_app_pendingDeposits !== void 0) finalDbData.acc_app_pendingDeposits = sanitizedDbData.acc_app_pendingDeposits;
          if (sanitizedDbData.bankSmsMessages !== void 0) finalDbData.bankSmsMessages = sanitizedDbData.bankSmsMessages;
          if (sanitizedDbData.acc_app_bankSmsMessages !== void 0) finalDbData.acc_app_bankSmsMessages = sanitizedDbData.acc_app_bankSmsMessages;
          if (sanitizedDbData.paymentAllocations !== void 0) finalDbData.paymentAllocations = sanitizedDbData.paymentAllocations;
          if (sanitizedDbData.acc_app_paymentAllocations !== void 0) finalDbData.acc_app_paymentAllocations = sanitizedDbData.acc_app_paymentAllocations;
        }
        const incFinalInvoices = sectionSet.has("finalInvoices");
        const incProformas = sectionSet.has("proformas");
        if (incFinalInvoices || incProformas) {
          const rawInvoices = Array.isArray(sanitizedDbData.invoices) && sanitizedDbData.invoices.length > 0 ? sanitizedDbData.invoices : sanitizedDbData.acc_app_invoices || sanitizedDbData.invoices || [];
          const filteredInvoices = Array.isArray(rawInvoices) ? rawInvoices.filter((inv) => {
            const isPf = isInvoiceProforma(inv);
            if (incFinalInvoices && incProformas) return true;
            if (incFinalInvoices && !incProformas) return !isPf;
            if (!incFinalInvoices && incProformas) return isPf;
            return false;
          }) : [];
          finalDbData.invoices = filteredInvoices;
          finalDbData.acc_app_invoices = filteredInvoices;
        }
        const incGoods = sectionSet.has("goods");
        const incServices = sectionSet.has("services");
        if (incGoods || incServices) {
          const rawItems = Array.isArray(sanitizedDbData.items) && sanitizedDbData.items.length > 0 ? sanitizedDbData.items : sanitizedDbData.acc_app_items || sanitizedDbData.items || [];
          const filteredItems = Array.isArray(rawItems) ? rawItems.filter((item) => {
            const isService = item.type === "khadamat";
            if (incGoods && incServices) return true;
            if (incGoods && !incServices) return !isService;
            if (!incGoods && incServices) return isService;
            return false;
          }) : [];
          finalDbData.items = filteredItems;
          finalDbData.acc_app_items = filteredItems;
          if (incGoods) {
            if (sanitizedDbData.inventoryMovements !== void 0) finalDbData.inventoryMovements = sanitizedDbData.inventoryMovements;
            if (sanitizedDbData.acc_app_inventoryMovements !== void 0) finalDbData.acc_app_inventoryMovements = sanitizedDbData.acc_app_inventoryMovements;
            if (sanitizedDbData.warehouse_categories_list !== void 0) finalDbData.warehouse_categories_list = sanitizedDbData.warehouse_categories_list;
            if (sanitizedDbData.acc_app_warehouse_categories_list !== void 0) finalDbData.acc_app_warehouse_categories_list = sanitizedDbData.acc_app_warehouse_categories_list;
            if (sanitizedDbData.warehouse_stock_adjustment_logs !== void 0) finalDbData.warehouse_stock_adjustment_logs = sanitizedDbData.warehouse_stock_adjustment_logs;
            if (sanitizedDbData.acc_app_warehouse_stock_adjustment_logs !== void 0) finalDbData.acc_app_warehouse_stock_adjustment_logs = sanitizedDbData.acc_app_warehouse_stock_adjustment_logs;
          }
        }
        if (sectionSet.has("accountingDocs")) {
          if (sanitizedDbData.docs !== void 0) finalDbData.docs = sanitizedDbData.docs;
          if (sanitizedDbData.acc_app_docs !== void 0) finalDbData.acc_app_docs = sanitizedDbData.acc_app_docs;
          if (sanitizedDbData.fiscalYear !== void 0) finalDbData.fiscalYear = sanitizedDbData.fiscalYear;
          if (sanitizedDbData.acc_app_fiscalYear !== void 0) finalDbData.acc_app_fiscalYear = sanitizedDbData.acc_app_fiscalYear;
          if (sanitizedDbData.fiscalYearsList !== void 0) finalDbData.fiscalYearsList = sanitizedDbData.fiscalYearsList;
          if (sanitizedDbData.acc_app_fiscalYearsList !== void 0) finalDbData.acc_app_fiscalYearsList = sanitizedDbData.acc_app_fiscalYearsList;
          if (sanitizedDbData.seq_doc_number !== void 0) finalDbData.seq_doc_number = sanitizedDbData.seq_doc_number;
          if (sanitizedDbData.acc_app_seq_doc_number !== void 0) finalDbData.acc_app_seq_doc_number = sanitizedDbData.acc_app_seq_doc_number;
        }
        if (sectionSet.has("counterparts")) {
          if (sanitizedDbData.counterparts !== void 0) finalDbData.counterparts = sanitizedDbData.counterparts;
          if (sanitizedDbData.acc_app_counterparts !== void 0) finalDbData.acc_app_counterparts = sanitizedDbData.acc_app_counterparts;
        }
        if (sectionSet.has("accounts")) {
          if (sanitizedDbData.accounts !== void 0) finalDbData.accounts = sanitizedDbData.accounts;
          if (sanitizedDbData.acc_app_accounts !== void 0) finalDbData.acc_app_accounts = sanitizedDbData.acc_app_accounts;
        }
        if (sectionSet.has("categories")) {
          if (sanitizedDbData.categories !== void 0) finalDbData.categories = sanitizedDbData.categories;
          if (sanitizedDbData.acc_app_categories !== void 0) finalDbData.acc_app_categories = sanitizedDbData.acc_app_categories;
          if (sanitizedDbData.commissionTags !== void 0) finalDbData.commissionTags = sanitizedDbData.commissionTags;
          if (sanitizedDbData.acc_app_commissionTags !== void 0) finalDbData.acc_app_commissionTags = sanitizedDbData.acc_app_commissionTags;
          if (sanitizedDbData.commission_tags_list !== void 0) finalDbData.commission_tags_list = sanitizedDbData.commission_tags_list;
          if (sanitizedDbData.acc_app_commission_tags_list !== void 0) finalDbData.acc_app_commission_tags_list = sanitizedDbData.acc_app_commission_tags_list;
          if (sanitizedDbData.commission_settlements_list !== void 0) finalDbData.commission_settlements_list = sanitizedDbData.commission_settlements_list;
          if (sanitizedDbData.acc_app_commission_settlements_list !== void 0) finalDbData.acc_app_commission_settlements_list = sanitizedDbData.acc_app_commission_settlements_list;
          if (sanitizedDbData.global_fixed_invoice_comm !== void 0) finalDbData.global_fixed_invoice_comm = sanitizedDbData.global_fixed_invoice_comm;
          if (sanitizedDbData.urgent_fixed_invoice_comm !== void 0) finalDbData.urgent_fixed_invoice_comm = sanitizedDbData.urgent_fixed_invoice_comm;
          if (sanitizedDbData.emergency_fixed_invoice_comm !== void 0) finalDbData.emergency_fixed_invoice_comm = sanitizedDbData.emergency_fixed_invoice_comm;
          if (sanitizedDbData.fixed_invoice_commissions !== void 0) finalDbData.fixed_invoice_commissions = sanitizedDbData.fixed_invoice_commissions;
          if (sanitizedDbData.shipping_method_fixed_commissions !== void 0) finalDbData.shipping_method_fixed_commissions = sanitizedDbData.shipping_method_fixed_commissions;
        }
        if (sectionSet.has("partnersLoans")) {
          if (sanitizedDbData.partners !== void 0) finalDbData.partners = sanitizedDbData.partners;
          if (sanitizedDbData.acc_app_partners !== void 0) finalDbData.acc_app_partners = sanitizedDbData.acc_app_partners;
          if (sanitizedDbData.loanBorrowers !== void 0) finalDbData.loanBorrowers = sanitizedDbData.loanBorrowers;
          if (sanitizedDbData.acc_app_loanBorrowers !== void 0) finalDbData.acc_app_loanBorrowers = sanitizedDbData.acc_app_loanBorrowers;
        }
        if (sectionSet.has("checklist")) {
          if (sanitizedDbData.checklist !== void 0) finalDbData.checklist = sanitizedDbData.checklist;
          if (sanitizedDbData.acc_app_checklist !== void 0) finalDbData.acc_app_checklist = sanitizedDbData.acc_app_checklist;
        }
        if (sectionSet.has("settingsTheme")) {
          if (sanitizedDbData.settings !== void 0) finalDbData.settings = sanitizedDbData.settings;
          if (sanitizedDbData.acc_app_settings !== void 0) finalDbData.acc_app_settings = sanitizedDbData.acc_app_settings;
          for (const k of Object.keys(sanitizedDbData)) {
            if (k.includes("theme") || k.includes("Theme") || k.includes("Bg") || k.includes("font") || k.includes("currency") || k.includes("allow_login_restore") || k.includes("allow_login_update") || k.startsWith("acc_seller_") || k.startsWith("acc_system_") || k.startsWith("fahamacc_") || k.startsWith("settings_")) {
              finalDbData[k] = sanitizedDbData[k];
            }
          }
        }
        if (sectionSet.has("logs")) {
          if (sanitizedDbData.auditLogs !== void 0) finalDbData.auditLogs = sanitizedDbData.auditLogs;
          if (sanitizedDbData.acc_app_auditLogs !== void 0) finalDbData.acc_app_auditLogs = sanitizedDbData.acc_app_auditLogs;
          if (sanitizedDbData.system_logs !== void 0) finalDbData.system_logs = sanitizedDbData.system_logs;
          if (sanitizedDbData.acc_app_system_logs !== void 0) finalDbData.acc_app_system_logs = sanitizedDbData.acc_app_system_logs;
        }
        finalLocalStorage = {};
        for (const lsKey of Object.keys(clientLocalStorage)) {
          const clean = lsKey.startsWith("acc_app_") ? lsKey.substring(8) : lsKey;
          if (sectionSet.has("users") && (clean === "users" || clean === "currentUser" || clean === "primaryUserRole" || clean.startsWith("users_"))) {
            finalLocalStorage[lsKey] = clientLocalStorage[lsKey];
          }
          if (sectionSet.has("transactions") && (clean === "transactions" || clean === "pendingDeposits" || clean === "bankSmsMessages" || clean === "paymentAllocations" || clean.startsWith("transactions_") || clean.startsWith("pendingDeposits_") || clean.startsWith("bankSmsMessages_") || clean.startsWith("paymentAllocations_"))) {
            finalLocalStorage[lsKey] = clientLocalStorage[lsKey];
          }
          if (sectionSet.has("accountingDocs") && (clean === "docs" || clean === "fiscalYear" || clean === "fiscalYearsList" || clean === "seq_doc_number" || clean.startsWith("docs_") || clean.startsWith("fiscalYear_"))) {
            finalLocalStorage[lsKey] = clientLocalStorage[lsKey];
          }
          if (sectionSet.has("counterparts") && (clean === "counterparts" || clean.startsWith("counterparts_"))) {
            finalLocalStorage[lsKey] = clientLocalStorage[lsKey];
          }
          if (sectionSet.has("accounts") && (clean === "accounts" || clean.startsWith("accounts_"))) {
            finalLocalStorage[lsKey] = clientLocalStorage[lsKey];
          }
          if (sectionSet.has("categories") && (clean === "categories" || clean === "commissionTags" || clean.startsWith("categories_") || clean.startsWith("commissionTags_") || clean.startsWith("commission_") || clean.startsWith("global_fixed_") || clean.startsWith("urgent_fixed_") || clean.startsWith("emergency_fixed_") || clean.startsWith("fixed_invoice_") || clean.startsWith("shipping_method_fixed_"))) {
            finalLocalStorage[lsKey] = clientLocalStorage[lsKey];
          }
          if (sectionSet.has("partnersLoans") && (clean === "partners" || clean === "loanBorrowers" || clean.startsWith("partners_") || clean.startsWith("loanBorrowers_"))) {
            finalLocalStorage[lsKey] = clientLocalStorage[lsKey];
          }
          if (sectionSet.has("checklist") && (clean === "checklist" || clean.startsWith("checklist_"))) {
            finalLocalStorage[lsKey] = clientLocalStorage[lsKey];
          }
          if (sectionSet.has("settingsTheme") && (clean === "settings" || clean.startsWith("settings_") || clean.includes("Theme") || clean.includes("theme") || clean.includes("Bg") || clean.includes("font") || clean.includes("currency") || clean.includes("allow_login_restore") || clean.includes("allow_login_update") || clean.startsWith("acc_seller_") || clean.startsWith("acc_system_") || clean.startsWith("fahamacc_"))) {
            finalLocalStorage[lsKey] = clientLocalStorage[lsKey];
          }
          if (sectionSet.has("logs") && (clean === "auditLogs" || clean === "system_logs" || clean.startsWith("auditLogs_") || clean.startsWith("system_logs_"))) {
            finalLocalStorage[lsKey] = clientLocalStorage[lsKey];
          }
          if ((incFinalInvoices || incProformas) && (clean === "invoices" || clean.startsWith("invoices_"))) {
            try {
              const rawVal = clientLocalStorage[lsKey];
              const parsedArr = typeof rawVal === "string" ? JSON.parse(rawVal) : rawVal;
              if (Array.isArray(parsedArr)) {
                const filtered = parsedArr.filter((inv) => {
                  const isPf = isInvoiceProforma(inv);
                  if (incFinalInvoices && incProformas) return true;
                  if (incFinalInvoices && !incProformas) return !isPf;
                  if (!incFinalInvoices && incProformas) return isPf;
                  return false;
                });
                finalLocalStorage[lsKey] = JSON.stringify(filtered);
              }
            } catch (_) {
            }
          }
          if ((incGoods || incServices) && (clean === "items" || clean.startsWith("items_"))) {
            try {
              const rawVal = clientLocalStorage[lsKey];
              const parsedArr = typeof rawVal === "string" ? JSON.parse(rawVal) : rawVal;
              if (Array.isArray(parsedArr)) {
                const filtered = parsedArr.filter((item) => {
                  const isService = item.type === "khadamat";
                  if (incGoods && incServices) return true;
                  if (incGoods && !incServices) return !isService;
                  if (!incGoods && incServices) return isService;
                  return false;
                });
                finalLocalStorage[lsKey] = JSON.stringify(filtered);
              }
            } catch (_) {
            }
          }
        }
      }
      const activeConfig = getAppConfig();
      const sectionCount = Array.isArray(selectedSections) ? selectedSections.length : 0;
      const singleSectionTitle = isPartial && sectionCount === 1 ? SECTION_TITLES[selectedSections[0]] || selectedSections[0] : null;
      const backupPackage = {
        _metadata: {
          version: "2.0",
          system: "TICK_Accounting",
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          type: isPartial ? "CUSTOM_SELECTIVE_BACKUP" : "USER_DATA_ONLY_BACKUP",
          description: isPartial ? singleSectionTitle ? `\u0646\u0633\u062E\u0647 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646 \u0627\u062E\u062A\u0635\u0627\u0635\u06CC \u0628\u062E\u0634 ${singleSectionTitle}` : `\u0646\u0633\u062E\u0647 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646 \u0627\u0646\u062A\u062E\u0627\u0628\u06CC \u0627\u0632 ${sectionCount} \u0628\u062E\u0634 \u0645\u0634\u062E\u0635 \u0634\u062F\u0647 \u0633\u0627\u0645\u0627\u0646\u0647` : "\u0646\u0633\u062E\u0647 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646 \u06A9\u0627\u0645\u0644 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u06A9\u0627\u0631\u0628\u0631\u060C \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633\u060C \u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0647\u0648\u0634 \u0645\u0635\u0646\u0648\u0639\u06CC \u0648 \u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC \u067E\u06CC\u0648\u0633\u062A \u0628\u062F\u0648\u0646 \u06A9\u062F\u0647\u0627\u06CC \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631",
          sectionName: singleSectionTitle || (isPartial ? `${sectionCount} \u0628\u062E\u0634 \u0627\u0646\u062A\u062E\u0627\u0628\u06CC` : "\u062A\u0645\u0627\u0645\u06CC \u0628\u062E\u0634\u200C\u0647\u0627"),
          selectedSections: isPartial ? selectedSections : ALL_BACKUP_SECTION_IDS,
          isPartialBackup: isPartial
        },
        systemConfig: {
          GEMINI_API_KEY: "",
          // Excluded for security to prevent API key leakage
          GEMINI_BASE_URL: process.env.GEMINI_BASE_URL || activeConfig.GEMINI_BASE_URL || dbData.geminiBaseUrl || ""
        },
        database: finalDbData,
        localStorage: finalLocalStorage,
        uploads: uploadsMap
      };
      return res.json({
        status: "success",
        backup: backupPackage,
        message: isPartial ? singleSectionTitle ? `\u0646\u0633\u062E\u0647 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646 \u0627\u062E\u062A\u0635\u0627\u0635\u06CC \xAB${singleSectionTitle}\xBB \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062A\u0648\u0644\u06CC\u062F \u0634\u062F.` : `\u0646\u0633\u062E\u0647 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646 \u0627\u0646\u062A\u062E\u0627\u0628\u06CC (${sectionCount} \u0628\u062E\u0634) \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062A\u0648\u0644\u06CC\u062F \u0634\u062F.` : "\u0646\u0633\u062E\u0647 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646 \u06A9\u0627\u0645\u0644 \u062F\u0627\u062F\u0647\u200C\u0647\u0627\u06CC \u06A9\u0627\u0631\u0628\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062A\u0648\u0644\u06CC\u062F \u0634\u062F."
      });
    } catch (err) {
      console.error("Backup export error:", err);
      return res.status(500).json({ error: `\u062E\u0637\u0627 \u062F\u0631 \u062A\u0647\u06CC\u0647 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646: ${err?.message || "\u062E\u0637\u0627\u06CC \u0646\u0627\u0634\u0646\u0627\u062E\u062A\u0647"}` });
    }
  });
  app.post("/api/backup/restore", async (req, res) => {
    try {
      const { backupData } = req.body || {};
      if (!backupData || typeof backupData !== "object") {
        return res.status(400).json({ error: "\u0641\u0627\u06CC\u0644 \u06CC\u0627 \u0633\u0627\u062E\u062A\u0627\u0631 \u0628\u06A9\u0627\u067E \u0627\u0631\u0633\u0627\u0644\u200C\u0634\u062F\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A." });
      }
      let dbEntriesToRestore = {};
      let localStorageToRestore = {};
      let uploadsToRestore = {};
      if (backupData._metadata && backupData.database) {
        dbEntriesToRestore = backupData.database || {};
        localStorageToRestore = backupData.localStorage || {};
        uploadsToRestore = backupData.uploads || {};
      } else {
        for (const rawKey of Object.keys(backupData)) {
          if (rawKey === "_metadata") continue;
          let val = backupData[rawKey];
          if (typeof val === "string") {
            try {
              val = JSON.parse(val);
            } catch (_) {
            }
          }
          const cleanKey = rawKey.startsWith("acc_app_") ? rawKey.substring(8) : rawKey;
          dbEntriesToRestore[cleanKey] = val;
          localStorageToRestore[rawKey] = typeof backupData[rawKey] === "string" ? backupData[rawKey] : JSON.stringify(backupData[rawKey]);
        }
      }
      const schemaCheck = validateDatabaseSchema(dbEntriesToRestore);
      if (!schemaCheck.isValid) {
        return res.status(400).json({
          error: `\u0628\u0627\u0632\u06CC\u0627\u0628\u06CC \u0628\u06A9\u0627\u067E \u0645\u062A\u0648\u0642\u0641 \u0634\u062F: ${schemaCheck.reason || "\u0633\u0627\u062E\u062A\u0627\u0631 \u0641\u0627\u06CC\u0644 \u0628\u06A9\u0627\u067E \u0646\u0627\u0642\u0635 \u06CC\u0627 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A."}`
        });
      }
      const isPartialBackup = Boolean(
        backupData._metadata?.isPartialBackup || Array.isArray(backupData._metadata?.selectedSections) && backupData._metadata.selectedSections.length < 15
      );
      const isInvoiceProforma = (inv) => {
        if (!inv) return false;
        return Boolean(
          inv.isProforma === true || inv.isProforma === "true" || inv.type === "proforma" || inv.status === "proforma" || typeof inv.invoiceNumber === "string" && inv.invoiceNumber.trim().toUpperCase().startsWith("PF-") || typeof inv.title === "string" && inv.title.includes("\u067E\u06CC\u0634\u200C\u0641\u0627\u06A9\u062A\u0648\u0631")
        );
      };
      const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
      const emergencyDir = import_path.default.join(process.cwd(), "backups");
      if (!import_fs.default.existsSync(emergencyDir)) {
        import_fs.default.mkdirSync(emergencyDir, { recursive: true });
      }
      const emergencyFile = import_path.default.join(emergencyDir, `emergency_before_restore_${timestamp}.json`);
      const currentDb = await loadAllData();
      import_fs.default.writeFileSync(
        emergencyFile,
        JSON.stringify({
          _metadata: {
            createdReason: "Emergency backup automatically created before backup restoration",
            timestamp: (/* @__PURE__ */ new Date()).toISOString(),
            isPartialRestore: isPartialBackup
          },
          database: currentDb
        }, null, 2),
        "utf8"
      );
      console.log(`Emergency pre-restore backup saved at: ${emergencyFile}`);
      const uploadsDir = import_path.default.join(process.cwd(), "uploads");
      if (!isPartialBackup && Object.keys(uploadsToRestore).length > 0) {
        if (import_fs.default.existsSync(uploadsDir)) {
          try {
            import_fs.default.rmSync(uploadsDir, { recursive: true, force: true });
            import_fs.default.mkdirSync(uploadsDir, { recursive: true });
          } catch (e) {
            console.warn("Notice: clearing uploads dir warning:", e);
          }
        }
      }
      let sanitizedData = {};
      if (isPartialBackup) {
        sanitizedData = { ...currentDb };
        const secList = Array.isArray(backupData._metadata?.selectedSections) ? backupData._metadata.selectedSections : [];
        const secSet = new Set(secList);
        for (const rawKey of Object.keys(dbEntriesToRestore)) {
          const cleanKey = rawKey.startsWith("acc_app_") ? rawKey.substring(8) : rawKey;
          const val = dbEntriesToRestore[rawKey];
          if (cleanKey === "invoices") {
            const restoredInvs = Array.isArray(val) ? val : [];
            const currentInvs = Array.isArray(currentDb.invoices) ? currentDb.invoices : Array.isArray(currentDb.acc_app_invoices) ? currentDb.acc_app_invoices : [];
            const hasProformaOnly = secSet.has("proformas") && !secSet.has("finalInvoices");
            const hasFinalOnly = secSet.has("finalInvoices") && !secSet.has("proformas");
            if (hasProformaOnly) {
              const existingFinal = currentInvs.filter((inv) => !isInvoiceProforma(inv));
              const merged = [...existingFinal, ...restoredInvs];
              sanitizedData.invoices = merged;
              sanitizedData.acc_app_invoices = merged;
            } else if (hasFinalOnly) {
              const existingProformas = currentInvs.filter((inv) => isInvoiceProforma(inv));
              const merged = [...restoredInvs, ...existingProformas];
              sanitizedData.invoices = merged;
              sanitizedData.acc_app_invoices = merged;
            } else {
              sanitizedData.invoices = restoredInvs;
              sanitizedData.acc_app_invoices = restoredInvs;
            }
          } else if (cleanKey === "items") {
            const restoredItems = Array.isArray(val) ? val : [];
            const currentItems = Array.isArray(currentDb.items) ? currentDb.items : Array.isArray(currentDb.acc_app_items) ? currentDb.acc_app_items : [];
            const hasGoodsOnly = secSet.has("goods") && !secSet.has("services");
            const hasServicesOnly = secSet.has("services") && !secSet.has("goods");
            if (hasGoodsOnly) {
              const existingServices = currentItems.filter((it) => it.type === "khadamat");
              const merged = [...restoredItems, ...existingServices];
              sanitizedData.items = merged;
              sanitizedData.acc_app_items = merged;
            } else if (hasServicesOnly) {
              const existingGoods = currentItems.filter((it) => it.type !== "khadamat");
              const merged = [...existingGoods, ...restoredItems];
              sanitizedData.items = merged;
              sanitizedData.acc_app_items = merged;
            } else {
              sanitizedData.items = restoredItems;
              sanitizedData.acc_app_items = restoredItems;
            }
          } else if (cleanKey === "settings") {
            sanitizedData.settings = {
              ...currentDb.settings || {},
              ...val || {}
            };
            sanitizedData.acc_app_settings = sanitizedData.settings;
          } else {
            sanitizedData[cleanKey] = val;
            sanitizedData[`acc_app_${cleanKey}`] = val;
          }
        }
      } else {
        sanitizedData = {};
        for (const rawKey of Object.keys(dbEntriesToRestore)) {
          const cleanKey = rawKey.startsWith("acc_app_") ? rawKey.substring(8) : rawKey;
          sanitizedData[cleanKey] = dbEntriesToRestore[rawKey];
        }
        if (currentDb && currentDb.settings && typeof currentDb.settings === "object") {
          sanitizedData.settings = {
            ...currentDb.settings,
            ...sanitizedData.settings || {}
          };
        }
      }
      await saveAllData(sanitizedData);
      const restoredGeminiKey = backupData.systemConfig?.GEMINI_API_KEY || sanitizedData.geminiApiKey || (localStorageToRestore.acc_app_geminiApiKey ? JSON.parse(localStorageToRestore.acc_app_geminiApiKey) : "");
      const restoredGeminiBaseUrl = backupData.systemConfig?.GEMINI_BASE_URL || sanitizedData.geminiBaseUrl || (localStorageToRestore.acc_app_geminiBaseUrl ? JSON.parse(localStorageToRestore.acc_app_geminiBaseUrl) : "");
      if (restoredGeminiKey) {
        const configPath = import_path.default.join(process.cwd(), "wp-config.json");
        let activeCfg = {};
        if (import_fs.default.existsSync(configPath)) {
          try {
            activeCfg = JSON.parse(import_fs.default.readFileSync(configPath, "utf8"));
          } catch (_) {
          }
        }
        activeCfg.GEMINI_API_KEY = restoredGeminiKey;
        if (restoredGeminiBaseUrl !== void 0) {
          activeCfg.GEMINI_BASE_URL = restoredGeminiBaseUrl;
        }
        import_fs.default.writeFileSync(configPath, JSON.stringify(activeCfg, null, 2), "utf8");
        process.env.GEMINI_API_KEY = restoredGeminiKey;
        if (restoredGeminiBaseUrl !== void 0) {
          process.env.GEMINI_BASE_URL = restoredGeminiBaseUrl;
        }
      }
      let restoredUploadsCount = 0;
      for (const relPath of Object.keys(uploadsToRestore)) {
        try {
          const normPath = relPath.replace(/\\/g, "/");
          if (normPath.startsWith("uploads/") || normPath.startsWith("public/uploads/") || normPath.startsWith("data/uploads/")) {
            const targetFilePath = import_path.default.join(process.cwd(), normPath);
            const parentDir = import_path.default.dirname(targetFilePath);
            if (!import_fs.default.existsSync(parentDir)) {
              import_fs.default.mkdirSync(parentDir, { recursive: true });
            }
            const buf = Buffer.from(uploadsToRestore[relPath], "base64");
            import_fs.default.writeFileSync(targetFilePath, buf);
            restoredUploadsCount++;
          }
        } catch (fileRestErr) {
          console.error(`Error restoring upload file ${relPath}:`, fileRestErr);
        }
      }
      console.log(`Backup restore completed! Keys: ${Object.keys(dbEntriesToRestore).length}, Files: ${restoredUploadsCount}`);
      return res.json({
        status: "success",
        message: isPartialBackup ? "\u0628\u062E\u0634\u200C\u0647\u0627\u06CC \u0627\u0646\u062A\u062E\u0627\u0628\u06CC \u067E\u0634\u062A\u06CC\u0628\u0627\u0646 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0628\u0631 \u0631\u0648\u06CC \u0633\u06CC\u0633\u062A\u0645 \u0627\u0639\u0645\u0627\u0644 \u0648 \u0628\u0627\u0632\u06CC\u0627\u0628\u06CC \u0634\u062F\u0646\u062F." : "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u067E\u0633 \u0627\u0632 \u0627\u0639\u062A\u0628\u0627\u0631\u0633\u0646\u062C\u06CC \u0633\u0627\u062E\u062A\u0627\u0631 \u0628\u0627\u0632\u06CC\u0627\u0628\u06CC \u0634\u062F\u0646\u062F!",
        emergencyBackupFile: import_path.default.basename(emergencyFile),
        restoredKeysCount: Object.keys(dbEntriesToRestore).length,
        restoredFilesCount: restoredUploadsCount,
        localStorage: localStorageToRestore,
        database: sanitizedData,
        isPartialBackup
      });
    } catch (err) {
      console.error("Backup restore error:", err);
      return res.status(500).json({ error: `\u062E\u0637\u0627 \u062F\u0631 \u0628\u0627\u0632\u06CC\u0627\u0628\u06CC \u0646\u0633\u062E\u0647 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646: ${err?.message || "\u062E\u0637\u0627\u06CC \u0646\u0627\u0634\u0646\u0627\u062E\u062A\u0647"}` });
    }
  });
  app.get("/api/db/status", (req, res) => {
    const config2 = getAppConfig();
    return res.json({
      dbType: "mysql",
      activeType: "mysql",
      mysqlConnected: mysqlPool !== null && !mysqlError,
      mysqlError,
      databaseName: config2.DB_NAME || "wdamlpty_hesabdari-h.fahamand",
      geminiConnected: !!process.env.GEMINI_API_KEY || !!config2.GEMINI_API_KEY,
      geminiApiKey: process.env.GEMINI_API_KEY || config2.GEMINI_API_KEY || "",
      geminiBaseUrl: process.env.GEMINI_BASE_URL || config2.GEMINI_BASE_URL || "",
      nodeVersion: process.version
    });
  });
  app.all(["/api/db/migrate-items", "/api/migrate-items", "/db/migrate-items"], async (req, res) => {
    try {
      const state = await loadAllData();
      let rawItems = state.items || state.acc_app_items || [];
      if (typeof rawItems === "string") {
        try {
          rawItems = JSON.parse(rawItems);
        } catch (_) {
          rawItems = [];
        }
      }
      const itemsList = Array.isArray(rawItems) ? rawItems : [];
      let migratedCount = 0;
      if (dbType === "mysql" && mysqlPool && !mysqlError) {
        await mysqlPool.query(`
          CREATE TABLE IF NOT EXISTS items (
            id VARCHAR(100) NOT NULL PRIMARY KEY,
            warehouse_id VARCHAR(100) NULL,
            name VARCHAR(255) NOT NULL,
            code VARCHAR(100) NULL,
            type VARCHAR(50) DEFAULT 'kala',
            color VARCHAR(100) NULL,
            unit VARCHAR(50) NULL,
            qty DECIMAL(15, 4) DEFAULT 0,
            initial_qty DECIMAL(15, 4) DEFAULT 0,
            last_purchase_price DECIMAL(20, 2) DEFAULT 0,
            last_sale_price DECIMAL(20, 2) DEFAULT 0,
            min_qty_alarm DECIMAL(15, 4) DEFAULT 0,
            category_name VARCHAR(255) NULL,
            parent_category VARCHAR(255) NULL,
            sub_category VARCHAR(255) NULL,
            commission_percent DECIMAL(8, 2) DEFAULT 0,
            setup_date VARCHAR(50) NULL,
            fiscal_year_id VARCHAR(100) NULL,
            created_by VARCHAR(100) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        `);
        for (const it of itemsList) {
          if (!it || typeof it !== "object") continue;
          const id = it.id || `item_${Math.random().toString(36).substring(2, 10)}`;
          const warehouseId = it.warehouseId || it.warehouse_id || null;
          const name = it.name || "\u06A9\u0627\u0644\u0627";
          const code = it.code || null;
          const type = it.type || "kala";
          const color = it.color || null;
          const unit = it.unit || null;
          const qty = Number(it.qty) || 0;
          const initialQty = Number(it.initialQty ?? it.initial_qty) || 0;
          const lastPurchasePrice = Number(it.lastPurchasePrice ?? it.last_purchase_price) || 0;
          const lastSalePrice = Number(it.lastSalePrice ?? it.last_sale_price) || 0;
          const minQtyAlarm = Number(it.minQtyAlarm ?? it.min_qty_alarm) || 0;
          const categoryName = it.categoryName || it.category_name || it.category || null;
          const parentCategory = it.parentCategory || it.parent_category || null;
          const subCategory = it.subCategory || it.sub_category || null;
          const commissionPercent = Number(it.commissionPercent ?? it.commission_percent) || 0;
          const setupDate = it.setupDate || it.setup_date || null;
          const fiscalYearId = it.fiscalYearId || it.fiscal_year_id || null;
          const createdBy = it.createdBy || it.created_by || null;
          await mysqlPool.query(
            `INSERT INTO items (
              id, warehouse_id, name, code, type, color, unit, qty, initial_qty,
              last_purchase_price, last_sale_price, min_qty_alarm, category_name,
              parent_category, sub_category, commission_percent, setup_date, fiscal_year_id, created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
              warehouse_id = VALUES(warehouse_id),
              name = VALUES(name),
              code = VALUES(code),
              type = VALUES(type),
              color = VALUES(color),
              unit = VALUES(unit),
              qty = qty + (VALUES(initial_qty) - initial_qty),
              initial_qty = VALUES(initial_qty),
              last_purchase_price = VALUES(last_purchase_price),
              last_sale_price = VALUES(last_sale_price),
              min_qty_alarm = VALUES(min_qty_alarm),
              category_name = VALUES(category_name),
              parent_category = VALUES(parent_category),
              sub_category = VALUES(sub_category),
              commission_percent = VALUES(commission_percent),
              setup_date = VALUES(setup_date),
              fiscal_year_id = VALUES(fiscal_year_id),
              created_by = VALUES(created_by),
              updated_at = CURRENT_TIMESTAMP`,
            [
              id,
              warehouseId,
              name,
              code,
              type,
              color,
              unit,
              qty,
              initialQty,
              lastPurchasePrice,
              lastSalePrice,
              minQtyAlarm,
              categoryName,
              parentCategory,
              subCategory,
              commissionPercent,
              setupDate,
              fiscalYearId,
              createdBy
            ]
          );
          migratedCount++;
        }
      } else {
        const itemsFilePath = import_path.default.join(process.cwd(), "data", "items.json");
        const itemsDir = import_path.default.dirname(itemsFilePath);
        if (!import_fs.default.existsSync(itemsDir)) {
          import_fs.default.mkdirSync(itemsDir, { recursive: true });
        }
        let currentItems = [];
        if (import_fs.default.existsSync(itemsFilePath)) {
          try {
            currentItems = JSON.parse(import_fs.default.readFileSync(itemsFilePath, "utf8"));
          } catch (_) {
            currentItems = [];
          }
        }
        const itemMap = /* @__PURE__ */ new Map();
        for (const it of currentItems) {
          if (it && it.id) itemMap.set(String(it.id), it);
        }
        for (const it of itemsList) {
          if (!it || typeof it !== "object") continue;
          const id = String(it.id || `item_${Math.random().toString(36).substring(2, 10)}`);
          itemMap.set(id, {
            id,
            name: String(it.name || "\u06A9\u0627\u0644\u0627"),
            type: it.type || "kala",
            code: it.code ? String(it.code) : null,
            warehouseId: it.warehouseId || it.warehouse_id || null,
            color: it.color || null,
            unit: it.unit || null,
            qty: Number(it.qty) || 0,
            initialQty: Number(it.initialQty ?? it.initial_qty) || 0,
            lastPurchasePrice: Number(it.lastPurchasePrice ?? it.last_purchase_price) || 0,
            lastSalePrice: Number(it.lastSalePrice ?? it.last_sale_price) || 0,
            minQtyAlarm: Number(it.minQtyAlarm ?? it.min_qty_alarm) || 0,
            categoryName: it.categoryName || it.category_name || it.category || null,
            parentCategory: it.parentCategory || it.parent_category || null,
            subCategory: it.subCategory || it.sub_category || null,
            commissionPercent: Number(it.commissionPercent ?? it.commission_percent) || 0,
            setupDate: it.setupDate || it.setup_date || null,
            fiscalYearId: it.fiscalYearId || it.fiscal_year_id || null,
            createdBy: it.createdBy || it.created_by || null,
            createdAt: it.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
            updatedAt: (/* @__PURE__ */ new Date()).toISOString()
          });
          migratedCount++;
        }
        import_fs.default.writeFileSync(itemsFilePath, JSON.stringify(Array.from(itemMap.values()), null, 2), "utf8");
      }
      return res.json({
        status: "success",
        message: `\u062A\u0639\u062F\u0627\u062F ${migratedCount} \u06A9\u0627\u0644\u0627 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0628\u0647 \u062C\u062F\u0648\u0644 items \u0645\u0646\u062A\u0642\u0644 \u0648 \u062B\u0628\u062A/\u0628\u0647\u200C\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC \u0634\u062F.`,
        migratedCount,
        count: migratedCount
      });
    } catch (err) {
      console.error("Error migrating items:", err);
      return res.status(500).json({ status: "error", error: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0646\u062A\u0642\u0627\u0644 \u06A9\u0627\u0644\u0627\u0647\u0627: ${err.message}` });
    }
  });
  app.all(["/api/db/load-items", "/api/load-items", "/db/load-items"], async (req, res) => {
    try {
      if (dbType === "mysql" && mysqlPool && !mysqlError) {
        await mysqlPool.query(`
          CREATE TABLE IF NOT EXISTS items (
            id VARCHAR(100) NOT NULL PRIMARY KEY,
            warehouse_id VARCHAR(100) NULL,
            name VARCHAR(255) NOT NULL,
            code VARCHAR(100) NULL,
            type VARCHAR(50) DEFAULT 'kala',
            color VARCHAR(100) NULL,
            unit VARCHAR(50) NULL,
            qty DECIMAL(15, 4) DEFAULT 0,
            initial_qty DECIMAL(15, 4) DEFAULT 0,
            last_purchase_price DECIMAL(20, 2) DEFAULT 0,
            last_sale_price DECIMAL(20, 2) DEFAULT 0,
            min_qty_alarm DECIMAL(15, 4) DEFAULT 0,
            category_name VARCHAR(255) NULL,
            parent_category VARCHAR(255) NULL,
            sub_category VARCHAR(255) NULL,
            commission_percent DECIMAL(8, 2) DEFAULT 0,
            setup_date VARCHAR(50) NULL,
            fiscal_year_id VARCHAR(100) NULL,
            created_by VARCHAR(100) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        `);
        const [rows] = await mysqlPool.query(
          "SELECT * FROM items ORDER BY updated_at DESC, name ASC"
        );
        const items = (Array.isArray(rows) ? rows : []).map((row) => ({
          id: String(row.id),
          name: String(row.name || ""),
          type: row.type || "kala",
          code: row.code !== null && row.code !== void 0 ? String(row.code) : null,
          warehouseId: row.warehouse_id !== null && row.warehouse_id !== void 0 ? String(row.warehouse_id) : null,
          color: row.color !== null && row.color !== void 0 ? String(row.color) : null,
          unit: row.unit !== null && row.unit !== void 0 ? String(row.unit) : null,
          qty: row.qty !== void 0 && row.qty !== null ? Number(row.qty) : 0,
          initialQty: row.initial_qty !== void 0 && row.initial_qty !== null ? Number(row.initial_qty) : 0,
          lastPurchasePrice: row.last_purchase_price !== void 0 && row.last_purchase_price !== null ? Number(row.last_purchase_price) : 0,
          lastSalePrice: row.last_sale_price !== void 0 && row.last_sale_price !== null ? Number(row.last_sale_price) : 0,
          minQtyAlarm: row.min_qty_alarm !== void 0 && row.min_qty_alarm !== null ? Number(row.min_qty_alarm) : 0,
          categoryName: row.category_name !== null && row.category_name !== void 0 ? String(row.category_name) : null,
          parentCategory: row.parent_category !== null && row.parent_category !== void 0 ? String(row.parent_category) : null,
          subCategory: row.sub_category !== null && row.sub_category !== void 0 ? String(row.sub_category) : null,
          commissionPercent: row.commission_percent !== void 0 && row.commission_percent !== null ? Number(row.commission_percent) : 0,
          setupDate: row.setup_date !== null && row.setup_date !== void 0 ? String(row.setup_date) : null,
          fiscalYearId: row.fiscal_year_id !== null && row.fiscal_year_id !== void 0 ? String(row.fiscal_year_id) : null,
          createdBy: row.created_by !== null && row.created_by !== void 0 ? String(row.created_by) : null,
          createdAt: row.created_at ? String(row.created_at) : null,
          updatedAt: row.updated_at ? String(row.updated_at) : null
        }));
        return res.json({
          status: "success",
          data: items,
          items,
          count: items.length
        });
      } else {
        const itemsFilePath = import_path.default.join(process.cwd(), "data", "items.json");
        let itemsList = [];
        if (import_fs.default.existsSync(itemsFilePath)) {
          try {
            itemsList = JSON.parse(import_fs.default.readFileSync(itemsFilePath, "utf8"));
          } catch (_) {
            itemsList = [];
          }
        }
        return res.json({
          status: "success",
          data: itemsList,
          items: itemsList,
          count: itemsList.length
        });
      }
    } catch (err) {
      console.error("Error loading items:", err);
      return res.status(500).json({ status: "error", error: `\u062E\u0637\u0627 \u062F\u0631 \u062E\u0648\u0627\u0646\u062F\u0646 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u06A9\u0627\u0644\u0627\u0647\u0627: ${err.message}` });
    }
  });
  app.all(["/api/db/save-item", "/api/save-item", "/db/save-item"], async (req, res) => {
    if (req.method !== "POST") {
      return res.status(405).json({ status: "error", error: "\u0645\u062A\u062F \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0628\u0627\u06CC\u062F POST \u0628\u0627\u0634\u062F." });
    }
    const input = req.body;
    if (!input || typeof input !== "object") {
      return res.status(422).json({ status: "error", error: "\u0628\u062F\u0646\u0647 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A \u0648 \u0628\u0627\u06CC\u062F \u0633\u0627\u062E\u062A\u0627\u0631 JSON \u0627\u0631\u0633\u0627\u0644 \u0634\u0648\u062F." });
    }
    const id = typeof input.id === "string" ? input.id.trim() : input.id !== void 0 && input.id !== null ? String(input.id).trim() : "";
    const name = typeof input.name === "string" ? input.name.trim() : input.name !== void 0 && input.name !== null ? String(input.name).trim() : "";
    if (!id) {
      return res.status(422).json({ status: "error", error: "\u0634\u0646\u0627\u0633\u0647 \u06A9\u0627\u0644\u0627 (id) \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A \u0648 \u0646\u0628\u0627\u06CC\u062F \u062E\u0627\u0644\u06CC \u0628\u0627\u0634\u062F." });
    }
    if (!name) {
      return res.status(422).json({ status: "error", error: "\u0646\u0627\u0645 \u06A9\u0627\u0644\u0627 (name) \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A \u0648 \u0646\u0628\u0627\u06CC\u062F \u062E\u0627\u0644\u06CC \u0628\u0627\u0634\u062F." });
    }
    const numFields = {
      qty: "\u062A\u0639\u062F\u0627\u062F (qty)",
      initialQty: "\u0645\u0648\u062C\u0648\u062F\u06CC \u0627\u0648\u0644\u06CC\u0647 (initialQty)",
      lastPurchasePrice: "\u0622\u062E\u0631\u06CC\u0646 \u0642\u06CC\u0645\u062A \u062E\u0631\u06CC\u062F (lastPurchasePrice)",
      lastSalePrice: "\u0622\u062E\u0631\u06CC\u0646 \u0642\u06CC\u0645\u062A \u0641\u0631\u0648\u0634 (lastSalePrice)",
      minQtyAlarm: "\u062D\u062F\u0627\u0642\u0644 \u0645\u0648\u062C\u0648\u062F\u06CC \u0647\u0634\u062F\u0627\u0631 (minQtyAlarm)",
      commissionPercent: "\u062F\u0631\u0635\u062F \u067E\u0648\u0631\u0633\u0627\u0646\u062A (commissionPercent)"
    };
    for (const [key, label] of Object.entries(numFields)) {
      if (input[key] !== void 0 && input[key] !== null && input[key] !== "") {
        if (isNaN(Number(input[key]))) {
          return res.status(422).json({ status: "error", error: `\u0645\u0642\u062F\u0627\u0631 \u0641\u06CC\u0644\u062F ${label} \u0628\u0627\u06CC\u062F \u0639\u062F\u062F\u06CC \u0645\u0639\u062A\u0628\u0631 \u0628\u0627\u0634\u062F.` });
        }
      }
    }
    try {
      if (dbType === "mysql" && mysqlPool && !mysqlError) {
        await mysqlPool.query(`
          CREATE TABLE IF NOT EXISTS items (
            id VARCHAR(100) NOT NULL PRIMARY KEY,
            warehouse_id VARCHAR(100) NULL,
            name VARCHAR(255) NOT NULL,
            code VARCHAR(100) NULL,
            type VARCHAR(50) DEFAULT 'kala',
            color VARCHAR(100) NULL,
            unit VARCHAR(50) NULL,
            qty DECIMAL(15, 4) DEFAULT 0,
            initial_qty DECIMAL(15, 4) DEFAULT 0,
            last_purchase_price DECIMAL(20, 2) DEFAULT 0,
            last_sale_price DECIMAL(20, 2) DEFAULT 0,
            min_qty_alarm DECIMAL(15, 4) DEFAULT 0,
            category_name VARCHAR(255) NULL,
            parent_category VARCHAR(255) NULL,
            sub_category VARCHAR(255) NULL,
            commission_percent DECIMAL(8, 2) DEFAULT 0,
            setup_date VARCHAR(50) NULL,
            fiscal_year_id VARCHAR(100) NULL,
            created_by VARCHAR(100) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        `);
        const warehouseId = input.warehouseId ?? input.warehouse_id ?? null;
        const code = input.code ?? null;
        const type = input.type || "kala";
        const color = input.color ?? null;
        const unit = input.unit ?? null;
        const qty = input.qty !== void 0 && input.qty !== null && input.qty !== "" ? Number(input.qty) : 0;
        const initialQty = input.initialQty !== void 0 && input.initialQty !== null && input.initialQty !== "" ? Number(input.initialQty) : input.initial_qty !== void 0 && input.initial_qty !== null && input.initial_qty !== "" ? Number(input.initial_qty) : 0;
        const lastPurchasePrice = input.lastPurchasePrice !== void 0 && input.lastPurchasePrice !== null && input.lastPurchasePrice !== "" ? Number(input.lastPurchasePrice) : input.last_purchase_price !== void 0 && input.last_purchase_price !== null && input.last_purchase_price !== "" ? Number(input.last_purchase_price) : 0;
        const lastSalePrice = input.lastSalePrice !== void 0 && input.lastSalePrice !== null && input.lastSalePrice !== "" ? Number(input.lastSalePrice) : input.last_sale_price !== void 0 && input.last_sale_price !== null && input.last_sale_price !== "" ? Number(input.last_sale_price) : 0;
        const minQtyAlarm = input.minQtyAlarm !== void 0 && input.minQtyAlarm !== null && input.minQtyAlarm !== "" ? Number(input.minQtyAlarm) : input.min_qty_alarm !== void 0 && input.min_qty_alarm !== null && input.min_qty_alarm !== "" ? Number(input.min_qty_alarm) : 0;
        const categoryName = input.categoryName ?? input.category_name ?? input.category ?? null;
        const parentCategory = input.parentCategory ?? input.parent_category ?? null;
        const subCategory = input.subCategory ?? input.sub_category ?? null;
        const commissionPercent = input.commissionPercent !== void 0 && input.commissionPercent !== null && input.commissionPercent !== "" ? Number(input.commissionPercent) : input.commission_percent !== void 0 && input.commission_percent !== null && input.commission_percent !== "" ? Number(input.commission_percent) : 0;
        const setupDate = input.setupDate ?? input.setup_date ?? null;
        const fiscalYearId = input.fiscalYearId ?? input.fiscal_year_id ?? null;
        const createdBy = input.createdBy ?? input.created_by ?? null;
        await mysqlPool.query(
          `INSERT INTO items (
            id, warehouse_id, name, code, type, color, unit, qty, initial_qty,
            last_purchase_price, last_sale_price, min_qty_alarm, category_name,
            parent_category, sub_category, commission_percent, setup_date, fiscal_year_id, created_by
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            warehouse_id = VALUES(warehouse_id),
            name = VALUES(name),
            code = VALUES(code),
            type = VALUES(type),
            color = VALUES(color),
            unit = VALUES(unit),
            qty = qty + (VALUES(initial_qty) - initial_qty),
            initial_qty = VALUES(initial_qty),
            last_purchase_price = VALUES(last_purchase_price),
            last_sale_price = VALUES(last_sale_price),
            min_qty_alarm = VALUES(min_qty_alarm),
            category_name = VALUES(category_name),
            parent_category = VALUES(parent_category),
            sub_category = VALUES(sub_category),
            commission_percent = VALUES(commission_percent),
            setup_date = VALUES(setup_date),
            fiscal_year_id = VALUES(fiscal_year_id),
            created_by = VALUES(created_by),
            updated_at = CURRENT_TIMESTAMP`,
          [
            id,
            warehouseId,
            name,
            code,
            type,
            color,
            unit,
            qty,
            initialQty,
            lastPurchasePrice,
            lastSalePrice,
            minQtyAlarm,
            categoryName,
            parentCategory,
            subCategory,
            commissionPercent,
            setupDate,
            fiscalYearId,
            createdBy
          ]
        );
        const [rows] = await mysqlPool.query("SELECT * FROM items WHERE id = ? LIMIT 1", [id]);
        if (!rows || rows.length === 0) {
          return res.status(500).json({ status: "error", error: "\u06A9\u0627\u0644\u0627 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F \u0627\u0645\u0627 \u0628\u0627\u0632\u062E\u0648\u0627\u0646\u06CC \u0622\u0646 \u0628\u0627 \u0645\u0634\u06A9\u0644 \u0645\u0648\u0627\u062C\u0647 \u06AF\u0631\u062F\u06CC\u062F." });
        }
        const row = rows[0];
        const itemData = {
          id: String(row.id),
          name: String(row.name || ""),
          type: row.type || "kala",
          code: row.code !== null && row.code !== void 0 ? String(row.code) : null,
          warehouseId: row.warehouse_id !== null && row.warehouse_id !== void 0 ? String(row.warehouse_id) : null,
          color: row.color !== null && row.color !== void 0 ? String(row.color) : null,
          unit: row.unit !== null && row.unit !== void 0 ? String(row.unit) : null,
          qty: row.qty !== void 0 && row.qty !== null ? Number(row.qty) : 0,
          initialQty: row.initial_qty !== void 0 && row.initial_qty !== null ? Number(row.initial_qty) : 0,
          lastPurchasePrice: row.last_purchase_price !== void 0 && row.last_purchase_price !== null ? Number(row.last_purchase_price) : 0,
          lastSalePrice: row.last_sale_price !== void 0 && row.last_sale_price !== null ? Number(row.last_sale_price) : 0,
          minQtyAlarm: row.min_qty_alarm !== void 0 && row.min_qty_alarm !== null ? Number(row.min_qty_alarm) : 0,
          categoryName: row.category_name !== null && row.category_name !== void 0 ? String(row.category_name) : null,
          parentCategory: row.parent_category !== null && row.parent_category !== void 0 ? String(row.parent_category) : null,
          subCategory: row.sub_category !== null && row.sub_category !== void 0 ? String(row.sub_category) : null,
          commissionPercent: row.commission_percent !== void 0 && row.commission_percent !== null ? Number(row.commission_percent) : 0,
          setupDate: row.setup_date !== null && row.setup_date !== void 0 ? String(row.setup_date) : null,
          fiscalYearId: row.fiscal_year_id !== null && row.fiscal_year_id !== void 0 ? String(row.fiscal_year_id) : null,
          createdBy: row.created_by !== null && row.created_by !== void 0 ? String(row.created_by) : null,
          createdAt: row.created_at ? String(row.created_at) : null,
          updatedAt: row.updated_at ? String(row.updated_at) : null
        };
        return res.json({
          status: "success",
          message: "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u06A9\u0627\u0644\u0627 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F.",
          data: itemData,
          item: itemData
        });
      } else {
        const itemsFilePath = import_path.default.join(process.cwd(), "data", "items.json");
        const itemsDir = import_path.default.dirname(itemsFilePath);
        if (!import_fs.default.existsSync(itemsDir)) {
          import_fs.default.mkdirSync(itemsDir, { recursive: true });
        }
        let itemsList = [];
        if (import_fs.default.existsSync(itemsFilePath)) {
          try {
            itemsList = JSON.parse(import_fs.default.readFileSync(itemsFilePath, "utf8"));
          } catch (_) {
            itemsList = [];
          }
        }
        const existingIdx = itemsList.findIndex((it) => it && String(it.id) === id);
        const itemData = {
          id,
          name,
          type: input.type || "kala",
          code: input.code !== void 0 && input.code !== null ? String(input.code) : null,
          warehouseId: input.warehouseId ?? input.warehouse_id ?? null,
          color: input.color ?? null,
          unit: input.unit ?? null,
          qty: input.qty !== void 0 && input.qty !== null && input.qty !== "" ? Number(input.qty) : 0,
          initialQty: input.initialQty !== void 0 && input.initialQty !== null && input.initialQty !== "" ? Number(input.initialQty) : input.initial_qty !== void 0 && input.initial_qty !== null && input.initial_qty !== "" ? Number(input.initial_qty) : 0,
          lastPurchasePrice: input.lastPurchasePrice !== void 0 && input.lastPurchasePrice !== null && input.lastPurchasePrice !== "" ? Number(input.lastPurchasePrice) : input.last_purchase_price !== void 0 && input.last_purchase_price !== null && input.last_purchase_price !== "" ? Number(input.last_purchase_price) : 0,
          lastSalePrice: input.lastSalePrice !== void 0 && input.lastSalePrice !== null && input.lastSalePrice !== "" ? Number(input.lastSalePrice) : input.last_sale_price !== void 0 && input.last_sale_price !== null && input.last_sale_price !== "" ? Number(input.last_sale_price) : 0,
          minQtyAlarm: input.minQtyAlarm !== void 0 && input.minQtyAlarm !== null && input.minQtyAlarm !== "" ? Number(input.minQtyAlarm) : input.min_qty_alarm !== void 0 && input.min_qty_alarm !== null && input.min_qty_alarm !== "" ? Number(input.min_qty_alarm) : 0,
          categoryName: input.categoryName ?? input.category_name ?? input.category ?? null,
          parentCategory: input.parentCategory ?? input.parent_category ?? null,
          subCategory: input.subCategory ?? input.sub_category ?? null,
          commissionPercent: input.commissionPercent !== void 0 && input.commissionPercent !== null && input.commissionPercent !== "" ? Number(input.commissionPercent) : input.commission_percent !== void 0 && input.commission_percent !== null && input.commission_percent !== "" ? Number(input.commission_percent) : 0,
          setupDate: input.setupDate ?? input.setup_date ?? null,
          fiscalYearId: input.fiscalYearId ?? input.fiscal_year_id ?? null,
          createdBy: input.createdBy ?? input.created_by ?? null,
          createdAt: existingIdx >= 0 && itemsList[existingIdx].createdAt ? itemsList[existingIdx].createdAt : (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        if (existingIdx >= 0) {
          itemsList[existingIdx] = itemData;
        } else {
          itemsList.unshift(itemData);
        }
        import_fs.default.writeFileSync(itemsFilePath, JSON.stringify(itemsList, null, 2), "utf8");
        return res.json({
          status: "success",
          message: "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u06A9\u0627\u0644\u0627 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F.",
          data: itemData,
          item: itemData
        });
      }
    } catch (err) {
      console.error("Error saving item:", err);
      return res.status(500).json({ status: "error", error: `\u062E\u0637\u0627 \u062F\u0631 \u0630\u062E\u06CC\u0631\u0647\u200C\u0633\u0627\u0632\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u06A9\u0627\u0644\u0627: ${err.message}` });
    }
  });
  app.all(["/api/db/delete-item", "/api/delete-item", "/db/delete-item"], async (req, res) => {
    if (req.method !== "POST") {
      return res.status(405).json({ status: "error", error: "\u0645\u062A\u062F \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0628\u0627\u06CC\u062F POST \u0628\u0627\u0634\u062F." });
    }
    const input = req.body;
    if (!input || typeof input !== "object") {
      return res.status(422).json({ status: "error", error: "\u0628\u062F\u0646\u0647 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A \u0648 \u0628\u0627\u06CC\u062F \u0633\u0627\u062E\u062A\u0627\u0631 JSON \u0627\u0631\u0633\u0627\u0644 \u0634\u0648\u062F." });
    }
    const id = typeof input.id === "string" ? input.id.trim() : input.id !== void 0 && input.id !== null ? String(input.id).trim() : "";
    if (!id) {
      return res.status(422).json({ status: "error", error: "\u0634\u0646\u0627\u0633\u0647 \u06A9\u0627\u0644\u0627 (id) \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A \u0648 \u0646\u0628\u0627\u06CC\u062F \u062E\u0627\u0644\u06CC \u0628\u0627\u0634\u062F." });
    }
    try {
      if (dbType === "mysql" && mysqlPool && !mysqlError) {
        await mysqlPool.query(`
          CREATE TABLE IF NOT EXISTS items (
            id VARCHAR(100) NOT NULL PRIMARY KEY,
            warehouse_id VARCHAR(100) NULL,
            name VARCHAR(255) NOT NULL,
            code VARCHAR(100) NULL,
            type VARCHAR(50) DEFAULT 'kala',
            color VARCHAR(100) NULL,
            unit VARCHAR(50) NULL,
            qty DECIMAL(15, 4) DEFAULT 0,
            initial_qty DECIMAL(15, 4) DEFAULT 0,
            last_purchase_price DECIMAL(20, 2) DEFAULT 0,
            last_sale_price DECIMAL(20, 2) DEFAULT 0,
            min_qty_alarm DECIMAL(15, 4) DEFAULT 0,
            category_name VARCHAR(255) NULL,
            parent_category VARCHAR(255) NULL,
            sub_category VARCHAR(255) NULL,
            commission_percent DECIMAL(8, 2) DEFAULT 0,
            setup_date VARCHAR(50) NULL,
            fiscal_year_id VARCHAR(100) NULL,
            created_by VARCHAR(100) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        `);
        const [rows] = await mysqlPool.query("SELECT id FROM items WHERE id = ? LIMIT 1", [id]);
        if (!rows || rows.length === 0) {
          return res.status(404).json({ status: "error", error: "\u06A9\u0627\u0644\u0627\u06CC \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u062F\u0631 \u062C\u062F\u0648\u0644 items \u06CC\u0627\u0641\u062A \u0646\u0634\u062F." });
        }
        await mysqlPool.query("DELETE FROM items WHERE id = ? LIMIT 1", [id]);
        return res.json({
          status: "success",
          id,
          deleted: true
        });
      } else {
        const itemsFilePath = import_path.default.join(process.cwd(), "data", "items.json");
        let itemsList = [];
        if (import_fs.default.existsSync(itemsFilePath)) {
          try {
            itemsList = JSON.parse(import_fs.default.readFileSync(itemsFilePath, "utf8"));
          } catch (_) {
            itemsList = [];
          }
        }
        const existingIdx = itemsList.findIndex((it) => it && String(it.id) === id);
        if (existingIdx === -1) {
          return res.status(404).json({ status: "error", error: "\u06A9\u0627\u0644\u0627\u06CC \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u062F\u0631 \u062C\u062F\u0648\u0644 items \u06CC\u0627\u0641\u062A \u0646\u0634\u062F." });
        }
        itemsList.splice(existingIdx, 1);
        import_fs.default.writeFileSync(itemsFilePath, JSON.stringify(itemsList, null, 2), "utf8");
        return res.json({
          status: "success",
          id,
          deleted: true
        });
      }
    } catch (err) {
      console.error("Error deleting item:", err);
      return res.status(500).json({ status: "error", error: `\u062E\u0637\u0627 \u062F\u0631 \u062D\u0630\u0641 \u06A9\u0627\u0644\u0627: ${err.message}` });
    }
  });
  app.post("/api/system/save-gemini-key", async (req, res) => {
    try {
      const { geminiKey, geminiBaseUrl } = req.body;
      const key = geminiKey ? geminiKey.trim() : "";
      const baseUrlVal = geminiBaseUrl ? geminiBaseUrl.trim() : "";
      const configPath = import_path.default.join(process.cwd(), "wp-config.json");
      let config2 = {};
      if (import_fs.default.existsSync(configPath)) {
        try {
          const content = import_fs.default.readFileSync(configPath, "utf8");
          config2 = JSON.parse(content);
        } catch (e) {
          console.error("Error reading config file:", e);
        }
      }
      config2.GEMINI_API_KEY = key;
      config2.GEMINI_BASE_URL = baseUrlVal;
      import_fs.default.writeFileSync(configPath, JSON.stringify(config2, null, 2), "utf8");
      process.env.GEMINI_API_KEY = key;
      process.env.GEMINI_BASE_URL = baseUrlVal;
      await saveKeyData("geminiApiKey", key);
      await saveKeyData("geminiBaseUrl", baseUrlVal);
      return res.json({ status: "success", message: "\u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u062F\u0633\u062A\u06CC\u0627\u0631 \u0647\u0648\u0634 \u0645\u0635\u0646\u0648\u0639\u06CC \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F." });
    } catch (err) {
      console.error("Error saving gemini config:", err);
      return res.status(500).json({ error: `\u062E\u0637\u0627 \u062F\u0631 \u0630\u062E\u06CC\u0631\u0647\u200C\u0633\u0627\u0632\u06CC \u062A\u0646\u0638\u06CC\u0645\u0627\u062A: ${err.message}` });
    }
  });
  app.post("/api/system/clear-uploads", async (req, res) => {
    try {
      const uploadsDir = import_path.default.join(process.cwd(), "uploads");
      if (import_fs.default.existsSync(uploadsDir)) {
        try {
          import_fs.default.rmSync(uploadsDir, { recursive: true, force: true });
          import_fs.default.mkdirSync(uploadsDir, { recursive: true });
        } catch (e) {
          console.warn("Notice: clearing uploads dir error:", e);
        }
      }
      return res.json({ status: "success", message: "\u06A9\u0644\u06CC\u0647 \u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC \u067E\u06CC\u0648\u0633\u062A \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u067E\u0627\u06A9\u0633\u0627\u0632\u06CC \u0634\u062F\u0646\u062F." });
    } catch (err) {
      console.error("Clear uploads error:", err);
      return res.status(500).json({ error: `\u062E\u0637\u0627 \u062F\u0631 \u067E\u0627\u06A9\u0633\u0627\u0632\u06CC \u0641\u0627\u06CC\u0644\u200C\u0647\u0627: ${err?.message || "\u062E\u0637\u0627\u06CC \u0646\u0627\u0634\u0646\u0627\u062E\u062A\u0647"}` });
    }
  });
  function parseBankSmsBody(bodyStr, senderName = "") {
    if (!bodyStr || typeof bodyStr !== "string") return {};
    const cleanBody = bodyStr.trim();
    let bankName = "\u0628\u0627\u0646\u06A9 \u0646\u0627\u0645\u0634\u062E\u0635";
    const lowerSender = (senderName || "").toLowerCase();
    if (cleanBody.includes("\u0645\u0644\u062A") || lowerSender.includes("mellat") || lowerSender.includes("6104")) {
      bankName = "\u0628\u0627\u0646\u06A9 \u0645\u0644\u062A";
    } else if (cleanBody.includes("\u0645\u0644\u06CC") || cleanBody.includes("\u0628\u0627\u0645") || lowerSender.includes("melli") || lowerSender.includes("bam")) {
      bankName = "\u0628\u0627\u0646\u06A9 \u0645\u0644\u06CC \u0627\u06CC\u0631\u0627\u0646";
    } else if (cleanBody.includes("\u0628\u0644\u0648\u0628\u0627\u0646\u06A9") || cleanBody.includes("\u0628\u0644\u0648") || lowerSender.includes("blu")) {
      bankName = "\u0628\u0644\u0648\u0628\u0627\u0646\u06A9 (Blu)";
    } else if (cleanBody.includes("\u0635\u0627\u062F\u0631\u0627\u062A") || lowerSender.includes("saderat")) {
      bankName = "\u0628\u0627\u0646\u06A9 \u0635\u0627\u062F\u0631\u0627\u062A";
    } else if (cleanBody.includes("\u062A\u062C\u0627\u0631\u062A") || lowerSender.includes("tejarat")) {
      bankName = "\u0628\u0627\u0646\u06A9 \u062A\u062C\u0627\u0631\u062A";
    } else if (cleanBody.includes("\u0633\u067E\u0647") || lowerSender.includes("sepah")) {
      bankName = "\u0628\u0627\u0646\u06A9 \u0633\u067E\u0647";
    } else if (cleanBody.includes("\u067E\u0627\u0633\u0627\u0631\u06AF\u0627\u062F") || lowerSender.includes("pasargad")) {
      bankName = "\u0628\u0627\u0646\u06A9 \u067E\u0627\u0633\u0627\u0631\u06AF\u0627\u062F";
    } else if (cleanBody.includes("\u0633\u0627\u0645\u0627\u0646") || lowerSender.includes("saman")) {
      bankName = "\u0628\u0627\u0646\u06A9 \u0633\u0627\u0645\u0627\u0646";
    } else if (cleanBody.includes("\u067E\u0627\u0631\u0633\u06CC\u0627\u0646") || lowerSender.includes("parsian")) {
      bankName = "\u0628\u0627\u0646\u06A9 \u067E\u0627\u0631\u0633\u06CC\u0627\u0646";
    } else if (cleanBody.includes("\u06A9\u0634\u0627\u0648\u0631\u0632\u06CC") || lowerSender.includes("keshavarzi")) {
      bankName = "\u0628\u0627\u0646\u06A9 \u06A9\u0634\u0627\u0648\u0631\u0632\u06CC";
    } else if (cleanBody.includes("\u0645\u0633\u06A9\u0646") || lowerSender.includes("maskan")) {
      bankName = "\u0628\u0627\u0646\u06A9 \u0645\u0633\u06A9\u0646";
    } else if (cleanBody.includes("\u0634\u0647\u0631") || lowerSender.includes("shahr")) {
      bankName = "\u0628\u0627\u0646\u06A9 \u0634\u0647\u0631";
    } else if (cleanBody.includes("\u0631\u0641\u0627\u0647") || lowerSender.includes("refah")) {
      bankName = "\u0628\u0627\u0646\u06A9 \u0631\u0641\u0627\u0647 \u06A9\u0627\u0631\u06AF\u0631\u0627\u0646";
    }
    let type;
    if (cleanBody.includes("\u0648\u0627\u0631\u06CC\u0632") || cleanBody.includes("\u0648\u0627\u0631\u064A\u0632") || cleanBody.includes("\u0627\u0646\u062A\u0642\u0627\u0644 \u0628\u0647") || cleanBody.includes("\u0627\u0641\u0632\u0627\u06CC\u0634") || cleanBody.includes("\u062F\u0631\u06CC\u0627\u0641\u062A")) {
      type = "deposit";
    } else if (cleanBody.includes("\u0628\u0631\u062F\u0627\u0634\u062A") || cleanBody.includes("\u062E\u0631\u06CC\u062F") || cleanBody.includes("\u062E\u0631\u064A\u062F") || cleanBody.includes("\u06A9\u0627\u0647\u0634") || cleanBody.includes("\u0627\u0646\u062A\u0642\u0627\u0644 \u0627\u0632") || cleanBody.includes("\u067E\u0648\u0632") || cleanBody.includes("\u067E\u0631\u062F\u0627\u062E\u062A")) {
      type = "withdrawal";
    }
    const persianDigits = "\u06F0\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F90123456789\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669";
    const englishDigits = "012345678901234567890123456789";
    let englishBody = "";
    for (let i = 0; i < cleanBody.length; i++) {
      const idx = persianDigits.indexOf(cleanBody[i]);
      if (idx !== -1) {
        englishBody += englishDigits[idx % 10];
      } else {
        englishBody += cleanBody[i];
      }
    }
    let amount;
    const amountRialMatch = englishBody.match(/(?:مبلغ|واریز|واريز|برداشت|خرید|پرداخت|مبلغ:)?\s*([0-9,]{3,15})\s*(?:ریال|ريال|Rial)/i);
    const amountTomanMatch = englishBody.match(/(?:مبلغ|واریز|واريز|برداشت|خرید|پرداخت|مبلغ:)?\s*([0-9,]{3,15})\s*(?:تومان|Toman)/i);
    if (amountRialMatch && amountRialMatch[1]) {
      const cleanNum = parseInt(amountRialMatch[1].replace(/,/g, ""), 10);
      if (!isNaN(cleanNum)) amount = cleanNum;
    } else if (amountTomanMatch && amountTomanMatch[1]) {
      const cleanNum = parseInt(amountTomanMatch[1].replace(/,/g, ""), 10);
      if (!isNaN(cleanNum)) amount = cleanNum * 10;
    } else {
      const numberMatches = englishBody.match(/([0-9]{1,3}(?:,[0-9]{3})+|[0-9]{4,12})/g);
      if (numberMatches && numberMatches.length > 0) {
        for (const rawNumStr of numberMatches) {
          const num = parseInt(rawNumStr.replace(/,/g, ""), 10);
          if (num >= 1e3 && num !== 1403 && num !== 1404 && num !== 1405) {
            amount = num;
            break;
          }
        }
      }
    }
    let accountNumber;
    const cardMatch = englishBody.match(/(?:حساب|کارت|به|از|شماره:?)\s*([0-9\*\.\-]{4,20})/i);
    if (cardMatch && cardMatch[1]) {
      accountNumber = cardMatch[1].trim();
    }
    let refCode;
    const refMatch = englishBody.match(/(?:پیگیری|کد پیگیری|رهگیری|کد رهگیری|ارجاع|شماره ارجاع|کد:?)\s*([0-9]{4,16})/i);
    if (refMatch && refMatch[1]) {
      refCode = refMatch[1].trim();
    }
    let balance;
    const balanceMatch = englishBody.match(/(?:موجودی|موجودي):?\s*([0-9,]{3,15})/i);
    if (balanceMatch && balanceMatch[1]) {
      const cleanBal = parseInt(balanceMatch[1].replace(/,/g, ""), 10);
      if (!isNaN(cleanBal)) balance = cleanBal;
    }
    return {
      bankName,
      type,
      amount,
      accountNumber,
      refCode,
      balance
    };
  }
  app.all([
    "/api/sms/receive",
    "/api/sms/receive/",
    "/sms/receive",
    "/sms/receive/",
    "/api/sms",
    "/api/sms/",
    "/sms",
    "/sms/",
    "/api/bank-sms/receive",
    "/api/bank-sms/receive/",
    "/bank-sms/receive",
    "/bank-sms/receive/",
    "/api/bank-sms",
    "/api/bank-sms/",
    "/bank-sms",
    "/bank-sms/"
  ], async (req, res) => {
    try {
      let bodyData = {};
      let rawTextBody = "";
      if (typeof req.body === "string") {
        rawTextBody = req.body.trim();
        try {
          bodyData = JSON.parse(rawTextBody);
        } catch (_err) {
          bodyData = {};
        }
      } else if (req.body && typeof req.body === "object") {
        bodyData = req.body;
      }
      const queryData = req.query || {};
      const smsBody = (bodyData.body || queryData.body || bodyData.message || queryData.message || bodyData.text || queryData.text || bodyData.msg || queryData.msg || bodyData.sms || queryData.sms || bodyData.content || queryData.content || rawTextBody || "").toString().trim();
      const smsSender = (bodyData.sender || queryData.sender || bodyData.phone || queryData.phone || bodyData.from || queryData.from || bodyData.number || queryData.number || bodyData.originatingAddress || queryData.originatingAddress || "\u0646\u0627\u0634\u0646\u0627\u0633").toString().trim();
      const providedApiKey = (bodyData.apiKey || queryData.apiKey || bodyData.key || queryData.key || req.headers["x-api-key"] || req.headers["authorization"] || "").toString().trim();
      const receivedAt = (bodyData.receivedAt || queryData.receivedAt || bodyData.date || queryData.date || (/* @__PURE__ */ new Date()).toISOString()).toString().trim();
      if ((req.method === "GET" || req.method === "HEAD") && !smsBody) {
        return res.json({
          status: "online",
          message: "\u0633\u0631\u0648\u06CC\u0633 \u062F\u0631\u06CC\u0627\u0641\u062A \u067E\u06CC\u0627\u0645\u06A9 \u0628\u0627\u0646\u06A9\u06CC \u0633\u06CC\u0633\u062A\u0645 \u0622\u0646\u0644\u0627\u06CC\u0646 \u0648 \u0641\u0639\u0627\u0644 \u0627\u0633\u062A.",
          endpoint: "/api/sms/receive",
          supportedMethods: ["POST", "GET"],
          samplePayload: {
            sender: "6104",
            body: "\u0628\u0627\u0646\u06A9 \u062A\u062C\u0627\u0631\u062A: \u0648\u0627\u0631\u06CC\u0632 500,000 \u0631\u06CC\u0627\u0644 \u0628\u0647 \u062D\u0633\u0627\u0628 1234",
            apiKey: "sms_secret_key_12345"
          }
        });
      }
      if (!smsBody) {
        return res.status(400).json({
          status: "error",
          error: "\u0645\u062A\u0646 \u067E\u06CC\u0627\u0645\u06A9 (body \u06CC\u0627 message) \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A. \u062C\u0647\u062A \u0622\u0632\u0645\u0627\u06CC\u0634\u060C \u067E\u0627\u0631\u0627\u0645\u062A\u0631 body \u0631\u0627 \u0628\u0627 \u0645\u062A\u062F POST \u06CC\u0627 GET \u0627\u0631\u0633\u0627\u0644 \u06A9\u0646\u06CC\u062F."
        });
      }
      const dbAllData = await loadAllData();
      const configuredApiKey = (dbAllData.smsApiKey || dbAllData.settings?.smsApiKey || "").toString().trim();
      if (configuredApiKey) {
        const cleanProvided = providedApiKey.replace(/^Bearer\s+/i, "").trim();
        if (cleanProvided !== configuredApiKey) {
          return res.status(401).json({
            status: "error",
            error: "\u06A9\u0644\u06CC\u062F API \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A (Unauthorized). \u0644\u0637\u0641\u0627\u064B \u06A9\u0644\u06CC\u062F x-api-key \u06CC\u0627 apiKey \u0635\u062D\u06CC\u062D \u0631\u0627 \u0627\u0631\u0633\u0627\u0644 \u06A9\u0646\u06CC\u062F."
          });
        }
      }
      const parsed = parseBankSmsBody(smsBody, smsSender);
      const existingMessages = Array.isArray(dbAllData.bankSmsMessages) ? dbAllData.bankSmsMessages : [];
      const existingDup = existingMessages.find((m) => {
        if (parsed.refCode && m.refCode && String(m.refCode).trim() === String(parsed.refCode).trim() && m.bankName === (parsed.bankName || "\u0628\u0627\u0646\u06A9 \u0646\u0627\u0645\u0634\u062E\u0635") && m.amount === parsed.amount) {
          return true;
        }
        return m.body === smsBody && m.amount === parsed.amount;
      });
      if (existingDup) {
        return res.json({
          status: "success",
          message: "\u067E\u06CC\u0627\u0645\u06A9 \u062A\u06A9\u0631\u0627\u0631\u06CC \u0628\u0647 \u0635\u0648\u0631\u062A \u0647\u0648\u0634\u0645\u0646\u062F \u0634\u0646\u0627\u0633\u0627\u06CC\u06CC \u0634\u062F \u0648 \u0627\u0632 \u062B\u0628\u062A \u062F\u0648\u0628\u0627\u0631\u0647 \u062C\u0644\u0648\u06AF\u06CC\u0631\u06CC \u06AF\u0631\u062F\u06CC\u062F.",
          smsId: existingDup.id,
          isDuplicate: true,
          parsedData: parsed
        });
      }
      const newSmsItem = {
        id: `sms-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        sender: smsSender,
        bankName: parsed.bankName || "\u0628\u0627\u0646\u06A9 \u0646\u0627\u0645\u0634\u062E\u0635",
        body: smsBody,
        receivedAt: receivedAt || (/* @__PURE__ */ new Date()).toISOString(),
        amount: parsed.amount,
        type: parsed.type,
        accountNumber: parsed.accountNumber,
        refCode: parsed.refCode,
        balance: parsed.balance,
        status: "pending"
      };
      existingMessages.unshift(newSmsItem);
      await saveKeyData("bankSmsMessages", existingMessages);
      return res.json({
        status: "success",
        message: "\u067E\u06CC\u0627\u0645\u06A9 \u0628\u0627\u0646\u06A9\u06CC \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u0633\u06CC\u0633\u062A\u0645 \u062B\u0628\u062A \u06AF\u0631\u062F\u06CC\u062F.",
        smsId: newSmsItem.id,
        parsedData: parsed
      });
    } catch (err) {
      console.error("Error receiving bank SMS:", err);
      return res.status(500).json({ status: "error", error: `\u062E\u0637\u0627 \u062F\u0631 \u062B\u0628\u062A \u067E\u06CC\u0627\u0645\u06A9: ${err.message}` });
    }
  });
  app.get("/api/bank-sms/list", async (req, res) => {
    try {
      const dbAllData = await loadAllData();
      const messages = Array.isArray(dbAllData.bankSmsMessages) ? dbAllData.bankSmsMessages : [];
      return res.json({ messages });
    } catch (err) {
      console.error("Error fetching bank SMS list:", err);
      return res.status(500).json({ error: err.message });
    }
  });
  async function executeSystemUpdateFromBuffer(buffer) {
    let backupDirName = "";
    let backupCreatedSuccessfully = false;
    const activeCfg = getAppConfig();
    const dbAllData = await loadAllData();
    const preUpdateGeminiKey = process.env.GEMINI_API_KEY || activeCfg.GEMINI_API_KEY || dbAllData.geminiApiKey || "";
    const preUpdateGeminiBaseUrl = process.env.GEMINI_BASE_URL || activeCfg.GEMINI_BASE_URL || dbAllData.geminiBaseUrl || "";
    console.log("[System Updater] Decoding update package buffer of length:", buffer.length);
    let zipEntries = [];
    let archiveParsed = false;
    try {
      const zip = new import_adm_zip.default(buffer);
      const rawEntries = zip.getEntries();
      if (rawEntries && rawEntries.length > 0) {
        zipEntries = rawEntries.map((e) => ({
          entryName: e.entryName,
          isDirectory: e.isDirectory,
          getData: () => e.getData()
        }));
        archiveParsed = true;
        console.log(`[System Updater] Parsed as ZIP archive: ${zipEntries.length} items found.`);
      }
    } catch (_zipErr) {
      console.log("[System Updater] AdmZip parsing failed, attempting RAR parsing...");
    }
    if (!archiveParsed) {
      try {
        const { createExtractorFromData } = await import("node-unrar-js");
        const extractor = await createExtractorFromData({ data: new Uint8Array(buffer) });
        const extracted = extractor.extract();
        const files = Array.from(extracted.files);
        zipEntries = files.map((f) => ({
          entryName: f.fileHeader.name,
          isDirectory: f.fileHeader.flags.directory,
          getData: () => Buffer.from(f.extraction || new Uint8Array(0))
        }));
        archiveParsed = true;
        console.log(`[System Updater] Parsed as RAR archive: ${zipEntries.length} items found.`);
      } catch (rarErr) {
        console.error("[System Updater] RAR extraction error:", rarErr);
        throw new Error("\u0641\u0627\u06CC\u0644 \u0627\u0631\u0633\u0627\u0644\u06CC \u0633\u0627\u062E\u062A\u0627\u0631 \u0632\u06CC\u067E (.zip) \u06CC\u0627 \u0631\u0627\u0631 (.rar) \u0645\u0639\u062A\u0628\u0631\u06CC \u0646\u062F\u0627\u0631\u062F \u06CC\u0627 \u0622\u0633\u06CC\u0628 \u062F\u06CC\u062F\u0647 \u0627\u0633\u062A.");
      }
    }
    if (!zipEntries || zipEntries.length === 0) {
      throw new Error("\u0641\u0627\u06CC\u0644 \u0627\u0631\u0633\u0627\u0644\u06CC \u062E\u0627\u0644\u06CC \u0627\u0633\u062A \u06CC\u0627 \u0647\u06CC\u0686 \u0641\u0627\u06CC\u0644\u06CC \u062F\u0631 \u0622\u0646 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F.");
    }
    console.log(`[System Updater] Verifying update content: ${zipEntries.length} items found.`);
    const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
    backupDirName = `auto_system_update_backup_${timestamp}`;
    const backupDir = import_path.default.join(process.cwd(), "backups", backupDirName);
    try {
      if (!import_fs.default.existsSync(backupDir)) {
        import_fs.default.mkdirSync(backupDir, { recursive: true });
      }
      const wpConfigPath = import_path.default.join(process.cwd(), "wp-config.json");
      if (import_fs.default.existsSync(wpConfigPath)) {
        import_fs.default.copyFileSync(wpConfigPath, import_path.default.join(backupDir, "wp-config.json"));
      }
      const envPath = import_path.default.join(process.cwd(), ".env");
      if (import_fs.default.existsSync(envPath)) {
        import_fs.default.copyFileSync(envPath, import_path.default.join(backupDir, ".env"));
      }
      if (dbType === "mysql" && mysqlPool) {
        try {
          const [rows] = await mysqlPool.query("SELECT state_key, state_value FROM app_state");
          import_fs.default.writeFileSync(
            import_path.default.join(backupDir, "mysql_state_backup.json"),
            JSON.stringify(rows, null, 2),
            "utf8"
          );
        } catch (mysqlBackupErr) {
          console.warn("Notice: MySQL backup snapshot warning:", mysqlBackupErr);
        }
      }
      const uploadsDir = import_path.default.join(process.cwd(), "uploads");
      if (import_fs.default.existsSync(uploadsDir)) {
        import_fs.default.cpSync(uploadsDir, import_path.default.join(backupDir, "uploads"), { recursive: true });
      }
      const publicUploadsDir = import_path.default.join(process.cwd(), "public", "uploads");
      if (import_fs.default.existsSync(publicUploadsDir)) {
        import_fs.default.cpSync(publicUploadsDir, import_path.default.join(backupDir, "public_uploads"), { recursive: true });
      }
      backupCreatedSuccessfully = true;
      console.log(`[System Updater] Automatic system update backup created successfully in folder: ${backupDir}`);
    } catch (backupErr) {
      console.error("[System Updater] Warning during pre-update backup creation:", backupErr);
    }
    let extractedCount = 0;
    let skippedCount = 0;
    cleanOldAssetBundles();
    for (const entry of zipEntries) {
      const normalizedEntry = entry.entryName.replace(/\\/g, "/");
      if (entry.isDirectory) {
        if (normalizedEntry.startsWith("data/") || normalizedEntry.startsWith("backups/") || normalizedEntry.startsWith("uploads/") || normalizedEntry.startsWith("public/uploads/") || normalizedEntry.startsWith("node_modules/")) {
          continue;
        }
        const dirPath = import_path.default.join(process.cwd(), normalizedEntry);
        if (!import_fs.default.existsSync(dirPath)) {
          import_fs.default.mkdirSync(dirPath, { recursive: true });
        }
        continue;
      }
      const targetPath = import_path.default.join(process.cwd(), normalizedEntry);
      if (normalizedEntry === "wp-config.json" || normalizedEntry === "wp-config.php" || normalizedEntry === ".env") {
        console.log(`[System Updater] Protected: unconditionally skipping "${normalizedEntry}" to preserve production configuration & DB credentials.`);
        skippedCount++;
        continue;
      }
      if (normalizedEntry.startsWith("data/") || normalizedEntry === "database.json" || normalizedEntry.endsWith(".sqlite") || normalizedEntry.endsWith(".db")) {
        console.log(`[System Updater] Protected: unconditionally skipping user database/data file "${normalizedEntry}" to guarantee absolute data isolation.`);
        skippedCount++;
        continue;
      }
      if (normalizedEntry.startsWith("uploads/") || normalizedEntry.startsWith("public/uploads/") || normalizedEntry.startsWith("data/uploads/")) {
        console.log(`[System Updater] Protected: unconditionally skipping user uploaded file "${normalizedEntry}".`);
        skippedCount++;
        continue;
      }
      if (normalizedEntry.startsWith("backups/")) {
        skippedCount++;
        continue;
      }
      if (normalizedEntry.startsWith("node_modules/")) {
        skippedCount++;
        continue;
      }
      const dirOfFile = import_path.default.dirname(targetPath);
      if (!import_fs.default.existsSync(dirOfFile)) {
        import_fs.default.mkdirSync(dirOfFile, { recursive: true });
      }
      import_fs.default.writeFileSync(targetPath, entry.getData());
      extractedCount++;
      try {
        if (!normalizedEntry.startsWith("dist/")) {
          const distPath = import_path.default.join(process.cwd(), "dist", normalizedEntry);
          const distDir = import_path.default.dirname(distPath);
          if (!import_fs.default.existsSync(distDir)) {
            import_fs.default.mkdirSync(distDir, { recursive: true });
          }
          import_fs.default.writeFileSync(distPath, entry.getData());
        } else {
          const relPath = normalizedEntry.substring(5);
          if (relPath) {
            const rootPath = import_path.default.join(process.cwd(), relPath);
            const rootDir = import_path.default.dirname(rootPath);
            if (!import_fs.default.existsSync(rootDir)) {
              import_fs.default.mkdirSync(rootDir, { recursive: true });
            }
            import_fs.default.writeFileSync(rootPath, entry.getData());
          }
        }
      } catch (_mirrorErr) {
      }
    }
    if (preUpdateGeminiKey) {
      const wpConfigPath = import_path.default.join(process.cwd(), "wp-config.json");
      let postUpdateCfg = {};
      if (import_fs.default.existsSync(wpConfigPath)) {
        try {
          postUpdateCfg = JSON.parse(import_fs.default.readFileSync(wpConfigPath, "utf8"));
        } catch (_) {
        }
      }
      postUpdateCfg.GEMINI_API_KEY = preUpdateGeminiKey;
      if (preUpdateGeminiBaseUrl) {
        postUpdateCfg.GEMINI_BASE_URL = preUpdateGeminiBaseUrl;
      }
      import_fs.default.writeFileSync(wpConfigPath, JSON.stringify(postUpdateCfg, null, 2), "utf8");
      process.env.GEMINI_API_KEY = preUpdateGeminiKey;
      if (preUpdateGeminiBaseUrl) {
        process.env.GEMINI_BASE_URL = preUpdateGeminiBaseUrl;
      }
      await saveKeyData("geminiApiKey", preUpdateGeminiKey);
      if (preUpdateGeminiBaseUrl) {
        await saveKeyData("geminiBaseUrl", preUpdateGeminiBaseUrl);
      }
    }
    console.log(`[System Updater] Update completed successfully! Extracted program files: ${extractedCount}, Protected user data files: ${skippedCount}`);
    return {
      status: "success",
      message: "\u0628\u0647\u200C\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u0646\u062C\u0627\u0645 \u0634\u062F! \u062A\u0645\u0627\u0645\u06CC \u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC \u0647\u0633\u062A\u0647 \u0628\u0631\u0646\u0627\u0645\u0647 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u0631\u062A\u0642\u0627 \u06CC\u0627\u0641\u062A\u0646\u062F \u0648 \u062A\u0645\u0627\u0645 \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633\u060C \u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0648 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u06A9\u0627\u0631\u0628\u0631\u0627\u0646 \u0628\u062F\u0648\u0646 \u0647\u06CC\u0686 \u062A\u063A\u06CC\u06CC\u0631\u06CC \u06A9\u0627\u0645\u0644\u0627\u064B \u062D\u0641\u0638 \u06AF\u0631\u062F\u06CC\u062F.",
      backupCreated: backupCreatedSuccessfully ? backupDirName : null,
      extractedCount,
      skippedCount
    };
  }
  app.post("/api/system/update", async (req, res) => {
    try {
      let buffer = null;
      if (Buffer.isBuffer(req.body) && req.body.length > 0) {
        buffer = req.body;
      } else if (req.body && typeof req.body.zipBase64 === "string") {
        buffer = Buffer.from(req.body.zipBase64, "base64");
      }
      if (!buffer || buffer.length === 0) {
        return res.status(400).json({ error: "\u0641\u0627\u06CC\u0644 \u0627\u0631\u0633\u0627\u0644\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u06CC\u0627 \u062E\u0627\u0644\u06CC \u0627\u0633\u062A." });
      }
      const result = await executeSystemUpdateFromBuffer(buffer);
      return res.json(result);
    } catch (err) {
      console.error("[System Updater] Update execution error:", err);
      return res.status(500).json({
        error: `\u0628\u0631\u0648\u0632 \u062E\u0637\u0627 \u062F\u0631 \u0627\u06A9\u0633\u062A\u0631\u06A9\u062A \u0641\u0627\u06CC\u0644 \u0628\u0647\u200C\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC: ${err?.message || "\u062E\u0637\u0627\u06CC \u0646\u0627\u0634\u0646\u0627\u062E\u062A\u0647"}. \u067E\u0634\u062A\u06CC\u0628\u0627\u0646 \u062E\u0648\u062F\u06A9\u0627\u0631 \u062F\u06CC\u062A\u0627\u0628\u06CC\u0633 \u0628\u0627\u0632\u06CC\u0627\u0628\u06CC \u0634\u062F.`
      });
    }
  });
  app.post("/api/system/update-chunk", async (req, res) => {
    try {
      const uploadIdHeader = req.headers["x-upload-id"] || req.headers["upload-id"];
      const chunkIndexHeader = req.headers["x-chunk-index"] || req.headers["chunk-index"];
      const totalChunksHeader = req.headers["x-total-chunks"] || req.headers["total-chunks"];
      let uploadId = typeof uploadIdHeader === "string" ? uploadIdHeader : "";
      let chunkIndex = typeof chunkIndexHeader === "string" ? parseInt(chunkIndexHeader, 10) : 0;
      let totalChunks = typeof totalChunksHeader === "string" ? parseInt(totalChunksHeader, 10) : 1;
      let chunkBuffer = null;
      if (!uploadId && req.query.uploadId && typeof req.query.uploadId === "string") {
        uploadId = req.query.uploadId;
      }
      if (req.query.chunkIndex !== void 0) {
        chunkIndex = parseInt(String(req.query.chunkIndex), 10);
      }
      if (req.query.totalChunks !== void 0) {
        totalChunks = parseInt(String(req.query.totalChunks), 10);
      }
      if (req.body && typeof req.body === "object") {
        if (typeof req.body.uploadId === "string" && (!uploadId || uploadId.startsWith("update_temp_"))) {
          uploadId = req.body.uploadId;
        }
        if (typeof req.body.chunkIndex === "number" || typeof req.body.chunkIndex === "string") {
          chunkIndex = parseInt(String(req.body.chunkIndex), 10);
        }
        if (typeof req.body.totalChunks === "number" || typeof req.body.totalChunks === "string") {
          totalChunks = parseInt(String(req.body.totalChunks), 10);
        }
        if (typeof req.body.chunkBase64 === "string") {
          chunkBuffer = Buffer.from(req.body.chunkBase64, "base64");
        } else if (typeof req.body.data === "string") {
          chunkBuffer = Buffer.from(req.body.data, "base64");
        }
      }
      if (!chunkBuffer && Buffer.isBuffer(req.body) && req.body.length > 0) {
        chunkBuffer = req.body;
      }
      if (!uploadId) {
        uploadId = "update_temp_" + Date.now();
      }
      const safeUploadId = uploadId.replace(/[^a-zA-Z0-9_-]/g, "_");
      if (!chunkBuffer || chunkBuffer.length === 0) {
        return res.status(400).json({ error: "\u0642\u0637\u0639\u0647 \u0627\u0631\u0633\u0627\u0644\u06CC \u062E\u0627\u0644\u06CC \u06CC\u0627 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A." });
      }
      const tempDir = import_path.default.join(process.cwd(), "backups", "temp_chunks");
      if (!import_fs.default.existsSync(tempDir)) {
        import_fs.default.mkdirSync(tempDir, { recursive: true });
      }
      try {
        const existingTempFiles = import_fs.default.readdirSync(tempDir);
        const twoHoursAgo = Date.now() - 2 * 60 * 60 * 1e3;
        for (const file of existingTempFiles) {
          try {
            const filePath = import_path.default.join(tempDir, file);
            const fileStat = import_fs.default.statSync(filePath);
            if (fileStat.mtimeMs < twoHoursAgo) {
              import_fs.default.unlinkSync(filePath);
            }
          } catch (_) {
          }
        }
      } catch (_) {
      }
      const chunkFilePath = import_path.default.join(tempDir, `${safeUploadId}.part_${chunkIndex}`);
      import_fs.default.writeFileSync(chunkFilePath, chunkBuffer);
      console.log(`[Chunk Updater] Received chunk ${chunkIndex + 1}/${totalChunks} for upload ID: ${safeUploadId} (${chunkBuffer.length} bytes)`);
      if (chunkIndex === totalChunks - 1) {
        console.log(`[Chunk Updater] All ${totalChunks} chunks received. Assembling complete update package...`);
        const assembledBuffers = [];
        for (let i = 0; i < totalChunks; i++) {
          const partPath = import_path.default.join(tempDir, `${safeUploadId}.part_${i}`);
          if (!import_fs.default.existsSync(partPath)) {
            return res.status(400).json({
              error: `\u0642\u0637\u0639\u0647 \u0634\u0645\u0627\u0631\u0647 ${i + 1} \u0627\u0632 \u067E\u06A9\u06CC\u062C \u0628\u0647\u200C\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC \u062F\u0631 \u0633\u0631\u0648\u0631 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F. \u0644\u0637\u0641\u0627\u064B \u0645\u062C\u062F\u062F\u0627\u064B \u062A\u0644\u0627\u0634 \u0646\u0645\u0627\u06CC\u06CC\u062F.`
            });
          }
          assembledBuffers.push(import_fs.default.readFileSync(partPath));
        }
        const fullBuffer = Buffer.concat(assembledBuffers);
        console.log(`[Chunk Updater] Package assembled successfully! Total size: ${(fullBuffer.length / (1024 * 1024)).toFixed(2)} MB`);
        for (let i = 0; i < totalChunks; i++) {
          try {
            const partPath = import_path.default.join(tempDir, `${safeUploadId}.part_${i}`);
            if (import_fs.default.existsSync(partPath)) import_fs.default.unlinkSync(partPath);
          } catch (_) {
          }
        }
        const updateResult = await executeSystemUpdateFromBuffer(fullBuffer);
        return res.json(updateResult);
      }
      return res.json({
        status: "chunk_received",
        chunkIndex,
        totalChunks,
        uploadId: safeUploadId
      });
    } catch (err) {
      console.error("[Chunk Updater] Chunk update error:", err);
      return res.status(500).json({
        error: `\u062E\u0637\u0627 \u062F\u0631 \u067E\u0631\u062F\u0627\u0632\u0634 \u0642\u0637\u0639\u0627\u062A \u0628\u0647\u200C\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC: ${err?.message || "\u062E\u0637\u0627\u06CC \u0633\u0631\u0648\u0631"}`
      });
    }
  });
  app.post("/api/system/build-package", async (req, res) => {
    try {
      console.log("[Build System] Initiating automatic package build (npm run build)...");
      const { exec } = await import("child_process");
      const util = await import("util");
      const execPromise = util.promisify(exec);
      cleanOldAssetBundles();
      cleanHostBackupFolders();
      const zipPath = import_path.default.join(process.cwd(), "dist.zip");
      if (import_fs.default.existsSync(zipPath)) {
        try {
          import_fs.default.unlinkSync(zipPath);
          console.log("[Build System] Deleted existing dist.zip package prior to new build.");
        } catch (unlinkErr) {
          console.warn("[Build System] Warning removing existing dist.zip:", unlinkErr);
        }
      }
      const { stdout, stderr } = await execPromise("npm run build", { cwd: process.cwd(), timeout: 18e4 });
      console.log("[Build System] stdout:", stdout);
      if (stderr) console.log("[Build System] stderr:", stderr);
      const distDir = import_path.default.join(process.cwd(), "dist");
      if (!import_fs.default.existsSync(distDir)) {
        return res.status(500).json({ error: "\u067E\u0648\u0634\u0647 dist \u067E\u0633 \u0627\u0632 \u0627\u062C\u0631\u0627\u06CC \u062F\u0633\u062A\u0648\u0631 \u0633\u0627\u062E\u062A \u0627\u06CC\u062C\u0627\u062F \u0646\u06AF\u0631\u062F\u06CC\u062F." });
      }
      const blueprintDir = import_path.default.join(process.cwd(), "blueprint");
      const publicDir = import_path.default.join(process.cwd(), "public");
      const filesToSync = [
        "api.php",
        "index.php",
        "wp-config.json",
        ".htaccess",
        "manifest.json",
        "sw.js",
        "favicon.svg",
        "icon-192.png",
        "icon-512.png",
        "index.html",
        "schema.sql"
      ];
      for (const f of filesToSync) {
        const destPath = import_path.default.join(distDir, f);
        const blueprintPath = import_path.default.join(blueprintDir, f);
        const rootPath = import_path.default.join(process.cwd(), f);
        const pubPath = import_path.default.join(publicDir, f);
        let srcPath = null;
        if (import_fs.default.existsSync(rootPath)) {
          srcPath = rootPath;
        } else if (import_fs.default.existsSync(blueprintPath)) {
          srcPath = blueprintPath;
        } else if (import_fs.default.existsSync(pubPath)) {
          srcPath = pubPath;
        }
        if (srcPath) {
          try {
            import_fs.default.copyFileSync(srcPath, destPath);
            if (srcPath === rootPath && import_fs.default.existsSync(blueprintDir)) {
              try {
                import_fs.default.copyFileSync(rootPath, blueprintPath);
              } catch (_) {
              }
            }
          } catch (syncErr) {
            console.warn(`[Build System] Notice syncing ${f} to dist:`, syncErr);
          }
        }
      }
      const distAssets = import_path.default.join(distDir, "assets");
      if (!import_fs.default.existsSync(distAssets)) import_fs.default.mkdirSync(distAssets, { recursive: true });
      const assetSources = [
        import_path.default.join(process.cwd(), "assets"),
        import_path.default.join(publicDir, "assets"),
        import_path.default.join(blueprintDir, "assets")
      ];
      for (const aSrc of assetSources) {
        if (import_fs.default.existsSync(aSrc)) {
          try {
            const afiles = import_fs.default.readdirSync(aSrc);
            for (const af of afiles) {
              const srcFile = import_path.default.join(aSrc, af);
              const destFile = import_path.default.join(distAssets, af);
              if (import_fs.default.statSync(srcFile).isFile()) {
                import_fs.default.copyFileSync(srcFile, destFile);
              }
            }
          } catch (_) {
          }
        }
      }
      const distWpConfigPath = import_path.default.join(distDir, "wp-config.json");
      let activeWpConfig = {
        DB_TYPE: "mysql",
        DB_HOST: "localhost",
        DB_PORT: 3306,
        DB_USER: "wdamlpty_hesabdari-h-fahamand",
        DB_PASSWORD: "stsE*j70[m5FlSNY",
        DB_NAME: "wdamlpty_hesabdari-h.fahamand",
        GEMINI_API_KEY: process.env.GEMINI_API_KEY || "",
        GEMINI_BASE_URL: process.env.GEMINI_BASE_URL || "",
        PORT: 3e3
      };
      const rootWpConfigPath = import_path.default.join(process.cwd(), "wp-config.json");
      if (import_fs.default.existsSync(rootWpConfigPath)) {
        try {
          const loaded = JSON.parse(import_fs.default.readFileSync(rootWpConfigPath, "utf8"));
          activeWpConfig = { ...activeWpConfig, ...loaded };
        } catch (_) {
        }
      }
      import_fs.default.writeFileSync(distWpConfigPath, JSON.stringify(activeWpConfig, null, 2), "utf8");
      const legacySamplePath = import_path.default.join(distDir, "wp-config-sample.json");
      if (import_fs.default.existsSync(legacySamplePath)) {
        try {
          import_fs.default.unlinkSync(legacySamplePath);
        } catch (_) {
        }
      }
      const distDataDir = import_path.default.join(distDir, "data");
      if (!import_fs.default.existsSync(distDataDir)) import_fs.default.mkdirSync(distDataDir, { recursive: true });
      const dataKeep = import_path.default.join(distDataDir, ".gitkeep");
      if (!import_fs.default.existsSync(dataKeep)) import_fs.default.writeFileSync(dataKeep, "# Data folder placeholder");
      const dataHtaccess = `# Deny direct web access to data folder
Order Deny,Allow
Deny from all
<IfModule mod_authz_core.c>
    Require all denied
</IfModule>
`;
      import_fs.default.writeFileSync(import_path.default.join(distDataDir, ".htaccess"), dataHtaccess, "utf8");
      const distEnvPath = import_path.default.join(distDir, ".env");
      if (import_fs.default.existsSync(distEnvPath)) {
        try {
          import_fs.default.unlinkSync(distEnvPath);
        } catch (_) {
        }
      }
      const distDbJsonPath = import_path.default.join(distDir, "database.json");
      if (import_fs.default.existsSync(distDbJsonPath)) {
        try {
          import_fs.default.unlinkSync(distDbJsonPath);
        } catch (_) {
        }
      }
      const distBackupsDir = import_path.default.join(distDir, "backups");
      if (import_fs.default.existsSync(distBackupsDir)) {
        try {
          import_fs.default.rmSync(distBackupsDir, { recursive: true, force: true });
        } catch (_) {
        }
      }
      const distUploadsDir = import_path.default.join(distDir, "uploads");
      if (!import_fs.default.existsSync(distUploadsDir)) import_fs.default.mkdirSync(distUploadsDir, { recursive: true });
      const uploadKeep = import_path.default.join(distUploadsDir, ".gitkeep");
      if (!import_fs.default.existsSync(uploadKeep)) import_fs.default.writeFileSync(uploadKeep, "# Uploads folder placeholder");
      ensureUploadsSecurityNode(distDir);
      try {
        const prodPkgJson = {
          name: "accounting-system-production",
          version: "1.0.0",
          private: true,
          main: "server.cjs",
          scripts: {
            start: "node server.cjs"
          },
          dependencies: {
            "express": "^4.21.2",
            "mysql2": "^3.23.4",
            "adm-zip": "^0.6.0",
            "@google/genai": "^2.4.0",
            "dotenv": "^17.2.3",
            "node-unrar-js": "^2.0.2",
            "xlsx": "^0.18.5"
          }
        };
        import_fs.default.writeFileSync(import_path.default.join(distDir, "package.json"), JSON.stringify(prodPkgJson, null, 2), "utf8");
      } catch (pkgErr) {
        console.warn("[Build System] Warning writing production package.json to dist:", pkgErr);
      }
      const zip = new import_adm_zip.default();
      const distFiles = import_fs.default.readdirSync(distDir);
      for (const item of distFiles) {
        const itemPath = import_path.default.join(distDir, item);
        const stat = import_fs.default.statSync(itemPath);
        if (stat.isDirectory()) {
          zip.addLocalFolder(itemPath, item);
        } else {
          zip.addLocalFile(itemPath);
        }
      }
      const htaccessPath = import_path.default.join(distDir, ".htaccess");
      if (import_fs.default.existsSync(htaccessPath)) {
        try {
          zip.addLocalFile(htaccessPath);
        } catch (_) {
        }
      }
      if (import_fs.default.existsSync(zipPath)) {
        try {
          import_fs.default.unlinkSync(zipPath);
        } catch (_) {
        }
      }
      zip.writeZip(zipPath);
      const zipStat = import_fs.default.statSync(zipPath);
      const zipSizeMB = (zipStat.size / (1024 * 1024)).toFixed(2);
      console.log(`[Build System] dist.zip successfully created! Size: ${zipSizeMB} MB (${zipStat.size} bytes)`);
      return res.json({
        status: "success",
        message: `\u067E\u06A9\u06CC\u062C \u0628\u0647\u200C\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC \u062C\u062F\u06CC\u062F \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062C\u0627\u06CC\u06AF\u0632\u06CC\u0646 \u067E\u06A9\u06CC\u062C \u0642\u0628\u0644\u06CC \u0634\u062F \u0648 \u0633\u0627\u062E\u062A\u0647 \u06AF\u0631\u062F\u06CC\u062F (${zipSizeMB} \u0645\u06AF\u0627\u0628\u0627\u06CC\u062A).`,
        sizeMB: zipSizeMB,
        sizeBytes: zipStat.size,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        downloadUrl: "/api/system/download-build"
      });
    } catch (err) {
      console.error("[Build System] Build package error:", err);
      return res.status(500).json({
        error: `\u062E\u0637\u0627 \u062F\u0631 \u0633\u0627\u062E\u062A \u067E\u06A9\u06CC\u062C \u0628\u0647\u200C\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC: ${err?.message || err}`
      });
    }
  });
  app.get("/api/system/download-build", (req, res) => {
    try {
      const zipPath = import_path.default.join(process.cwd(), "dist.zip");
      if (!import_fs.default.existsSync(zipPath)) {
        return res.status(404).json({ error: "\u0641\u0627\u06CC\u0644 dist.zip \u06CC\u0627\u0641\u062A \u0646\u0634\u062F. \u0644\u0637\u0641\u0627\u064B \u0627\u0628\u062A\u062F\u0627 \u062F\u06A9\u0645\u0647 \u0633\u0627\u062E\u062A \u067E\u06A9\u06CC\u062C \u0631\u0627 \u0628\u0632\u0646\u06CC\u062F." });
      }
      const stat = import_fs.default.statSync(zipPath);
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Length", stat.size.toString());
      res.setHeader("Content-Disposition", 'attachment; filename="dist.zip"');
      return res.sendFile(zipPath);
    } catch (err) {
      console.error("[Build System] Download build error:", err);
      return res.status(500).json({ error: `\u062E\u0637\u0627 \u062F\u0631 \u062F\u0627\u0646\u0644\u0648\u062F \u0641\u0627\u06CC\u0644: ${err?.message || err}` });
    }
  });
  app.get("/api/system/build-status", (req, res) => {
    try {
      const zipPath = import_path.default.join(process.cwd(), "dist.zip");
      if (import_fs.default.existsSync(zipPath)) {
        const stat = import_fs.default.statSync(zipPath);
        return res.json({
          exists: true,
          sizeMB: (stat.size / (1024 * 1024)).toFixed(2),
          sizeBytes: stat.size,
          mtime: stat.mtime.toISOString(),
          downloadUrl: "/api/system/download-build"
        });
      } else {
        return res.json({ exists: false });
      }
    } catch (err) {
      return res.json({ exists: false });
    }
  });
  app.post("/api/gemini/extract-slip", async (req, res) => {
    try {
      const { imageBase64 } = req.body;
      if (!imageBase64) {
        return res.status(400).json({ error: "\u062A\u0635\u0648\u06CC\u0631 \u0641\u06CC\u0634 \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." });
      }
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({
          error: "\u06A9\u0644\u06CC\u062F API \u0628\u0631\u0627\u06CC \u062F\u0633\u062A\u06CC\u0627\u0631 \u0647\u0648\u0634\u0645\u0646\u062F \u062A\u0646\u0638\u06CC\u0645 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A (GEMINI_API_KEY \u06CC\u0627\u0641\u062A \u0646\u0634\u062F). \u0644\u0637\u0641\u0627 \u0622\u0646 \u0631\u0627 \u062F\u0631 \u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F."
        });
      }
      const baseUrl = process.env.GEMINI_BASE_URL || void 0;
      const ai = new import_genai.GoogleGenAI({
        apiKey,
        httpOptions: {
          baseUrl,
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      let mimeType = "image/webp";
      let base64Data = imageBase64;
      if (imageBase64.startsWith("data:")) {
        const parts = imageBase64.split(",");
        base64Data = parts[1];
        const mimePart = parts[0].match(/data:(.*?);/);
        if (mimePart) {
          mimeType = mimePart[1];
        }
      }
      let response;
      const slipPromptContents = [
        {
          inlineData: {
            data: base64Data,
            mimeType
          }
        },
        {
          text: "\u0645\u0628\u0644\u063A\u060C \u062A\u0627\u0631\u06CC\u062E \u067E\u0631\u062F\u0627\u062E\u062A \u0648 \u0633\u0627\u0639\u062A \u067E\u0631\u062F\u0627\u062E\u062A \u062F\u0631\u062C \u0634\u062F\u0647 \u0631\u0648\u06CC \u0627\u06CC\u0646 \u0641\u06CC\u0634 \u0648\u0627\u0631\u06CC\u0632\u06CC \u0628\u0627\u0646\u06A9\u06CC \u06CC\u0627 \u0631\u0633\u06CC\u062F \u0627\u0646\u062A\u0642\u0627\u0644 \u0648\u062C\u0647 \u0631\u0627 \u0628\u0627 \u062F\u0642\u062A \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u06A9\u0646. \u0645\u0628\u0644\u063A \u0646\u0647\u0627\u06CC\u06CC \u062A\u0631\u0627\u06A9\u0646\u0634 \u0631\u0627 \u062D\u062A\u0645\u0627\u064B \u0628\u0647 \u0631\u06CC\u0627\u0644 \u062A\u0628\u062F\u06CC\u0644 \u06A9\u0646 (\u0627\u06AF\u0631 \u0645\u0628\u0644\u063A \u0628\u0647 \u062A\u0648\u0645\u0627\u0646 \u0627\u0633\u062A \u0622\u0646 \u0631\u0627 \u0636\u0631\u0628\u062F\u0631 \u06F1\u06F0 \u06A9\u0646) \u0648 \u0628\u0647 \u0635\u0648\u0631\u062A \u06CC\u06A9 \u0639\u062F\u062F \u0635\u062D\u06CC\u062D \u0628\u062F\u0648\u0646 \u06A9\u0627\u0645\u0627\u060C \u0648\u06CC\u0631\u06AF\u0648\u0644 \u06CC\u0627 \u0647\u06CC\u0686 \u06A9\u0644\u0645\u0647\u200C\u0627\u06CC \u0628\u0627\u0632\u06AF\u0631\u062F\u0627\u0646. \u062A\u0627\u0631\u06CC\u062E \u067E\u0631\u062F\u0627\u062E\u062A \u0631\u0627 \u062D\u062A\u0645\u0627\u064B \u0628\u0647 \u0641\u0631\u0645\u062A \u062A\u0627\u0631\u06CC\u062E \u0647\u062C\u0631\u06CC \u0634\u0645\u0633\u06CC \u0628\u0647 \u0635\u0648\u0631\u062A \u0686\u0647\u0627\u0631 \u0631\u0642\u0645\u06CC \u0628\u0631\u0627\u06CC \u0633\u0627\u0644 \u0648 \u062F\u0648 \u0631\u0642\u0645\u06CC \u0628\u0631\u0627\u06CC \u0645\u0627\u0647 \u0648 \u0631\u0648\u0632 (\u0645\u0627\u0646\u0646\u062F 1405/04/06 \u06CC\u0627 1403/12/25) \u062A\u0628\u062F\u06CC\u0644 \u0648 \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u06A9\u0646. \u0627\u06AF\u0631 \u0633\u0627\u0644 \u062F\u0648 \u0631\u0642\u0645\u06CC \u0628\u0648\u062F \u0622\u0646 \u0631\u0627 \u0686\u0647\u0627\u0631 \u0631\u0642\u0645\u06CC \u06A9\u0646 (\u0645\u062B\u0627\u0644: \u0633\u0627\u0644 03 \u0628\u0647 1403). \u0633\u0627\u0639\u062A \u067E\u0631\u062F\u0627\u062E\u062A \u0631\u0627 \u0647\u0645 \u0628\u0647 \u0641\u0631\u0645\u062A \u062F\u0648 \u0631\u0642\u0645\u06CC \u0633\u0627\u0639\u062A \u0648 \u062F\u0642\u06CC\u0642\u0647 (\u0645\u0627\u0646\u0646\u062F 14:20 \u06CC\u0627 09:15) \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u06A9\u0646. \u0627\u06AF\u0631 \u0633\u0627\u0639\u062A \u067E\u0631\u062F\u0627\u062E\u062A \u062F\u0631 \u0631\u0633\u06CC\u062F \u0645\u0648\u062C\u0648\u062F \u0646\u0628\u0648\u062F\u060C \u0645\u0642\u062F\u0627\u0631 \u062E\u0627\u0644\u06CC \u0628\u0631\u06AF\u0631\u062F\u0627\u0646."
        }
      ];
      const slipConfig = {
        responseMimeType: "application/json",
        responseSchema: {
          type: import_genai.Type.OBJECT,
          properties: {
            amount: {
              type: import_genai.Type.INTEGER,
              description: "The extracted transaction amount converted strictly to Iranian Rials (\u0631\u06CC\u0627\u0644). If the slip specifies Tomans (\u062A\u0648\u0645\u0627\u0646), multiply by 10 to convert to Rials. Return as a clean integer without any commas, letters, or words."
            },
            date: {
              type: import_genai.Type.STRING,
              description: "The extracted payment/transaction date converted to Jalali (Persian/Shamsi) calendar in YYYY/MM/DD format (e.g., 1403/05/12 or 1405/04/06). Do not use Gregorian calendar."
            },
            time: {
              type: import_genai.Type.STRING,
              description: "The extracted payment/transaction time/hour in HH:MM format (e.g., 14:32 or 09:15). If not found, return empty string."
            }
          },
          required: ["amount", "date"]
        }
      };
      try {
        response = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: slipPromptContents,
          config: slipConfig
        });
      } catch (_e) {
        try {
          response = await ai.models.generateContent({
            model: "gemini-2.0-flash",
            contents: slipPromptContents,
            config: slipConfig
          });
        } catch (_e2) {
          response = await ai.models.generateContent({
            model: "gemini-1.5-flash",
            contents: slipPromptContents,
            config: slipConfig
          });
        }
      }
      const text = response.text || "{}";
      const parsed = JSON.parse(text);
      return res.json(parsed);
    } catch (err) {
      console.error("Gemini slip extraction error:", err);
      let errorMsg = err?.message || "\u0645\u0634\u06A9\u0644 \u0646\u0627\u0634\u0646\u0627\u062E\u062A\u0647";
      if (errorMsg.includes("403") || err?.status === 403 || errorMsg.includes("Forbidden") || errorMsg.includes("PERMISSION_DENIED")) {
        errorMsg = "\u062E\u0637\u0627\u06CC \u06F4\u06F0\u06F3 (\u062A\u062D\u0631\u06CC\u0645 \u0645\u0633\u062A\u0642\u06CC\u0645 \u06AF\u0648\u06AF\u0644 \u0628\u0631 \u0639\u0644\u06CC\u0647 \u0627\u06CC\u0631\u0627\u0646). \u0633\u0631\u0648\u06CC\u0633 \u062C\u0645\u06CC\u0646\u0627\u06CC \u06AF\u0648\u06AF\u0644 \u0622\u06CC\u200C\u067E\u06CC\u200C\u0647\u0627\u06CC \u0627\u06CC\u0631\u0627\u0646 \u0631\u0627 \u0645\u0633\u062F\u0648\u062F \u06A9\u0631\u062F\u0647 \u0627\u0633\u062A.\n\n\u0631\u0627\u0647\u06A9\u0627\u0631 \u0642\u0637\u0639\u06CC \u0648 \u0622\u0633\u0627\u0646:\n\u0634\u0645\u0627 \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC\u062F \u06CC\u06A9 \u0622\u062F\u0631\u0633 \u067E\u0631\u0648\u06A9\u0633\u06CC \u0645\u0639\u062A\u0628\u0631 (\u0645\u0627\u0646\u0646\u062F \u0622\u062F\u0631\u0633 https://api.openai-hk.com \u06CC\u0627 \u06CC\u06A9 \u067E\u0631\u0648\u06A9\u0633\u06CC \u0627\u062E\u062A\u0635\u0627\u0635\u06CC \u062F\u06CC\u06AF\u0631) \u062F\u0631 \u0628\u062E\u0634 \u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631\u060C \u06A9\u0627\u062F\u0631 \xAB\u0622\u062F\u0631\u0633 \u067E\u0627\u06CC\u0647 API / \u067E\u0631\u0648\u06A9\u0633\u06CC (Base URL)\xBB \u0648\u0627\u0631\u062F \u06A9\u0631\u062F\u0647 \u0648 \u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0631\u0627 \u0630\u062E\u06CC\u0631\u0647 \u0646\u0645\u0627\u06CC\u06CC\u062F \u062A\u0627 \u062F\u0631\u062E\u0648\u0627\u0633\u062A\u200C\u0647\u0627\u06CC \u0634\u0645\u0627 \u0628\u062F\u0648\u0646 \u062A\u062D\u0631\u06CC\u0645 \u0648 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u0631\u0633\u0627\u0644 \u0634\u0648\u0646\u062F.";
      }
      return res.status(500).json({
        error: `\u062E\u0637\u0627 \u062F\u0631 \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0641\u06CC\u0634 \u0628\u0627 \u0647\u0648\u0634 \u0645\u0635\u0646\u0648\u0639\u06CC: ${errorMsg}`
      });
    }
  });
  app.post("/api/upload", async (req, res) => {
    try {
      const { fileData, fileName: reqFileName, category = "general" } = req.body || {};
      if (!fileData) {
        return res.status(400).json({ error: "\u0641\u0627\u06CC\u0644 \u06CC\u0627 \u062A\u0635\u0648\u06CC\u0631 \u0627\u0631\u0633\u0627\u0644\u06CC \u062E\u0627\u0644\u06CC \u0627\u0633\u062A (fileData \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A)." });
      }
      let buffer;
      let detectedExt = "";
      if (typeof fileData === "string" && fileData.startsWith("data:")) {
        const parts = fileData.split(",");
        buffer = Buffer.from(parts[1] || "", "base64");
        const mimeMatch = parts[0].match(/data:image\/([a-zA-Z0-9+]+);/i);
        if (mimeMatch) {
          detectedExt = mimeMatch[1].toLowerCase();
          if (detectedExt === "jpeg") detectedExt = "jpg";
          if (detectedExt === "svg+xml") detectedExt = "svg";
        }
      } else if (typeof fileData === "string") {
        buffer = Buffer.from(fileData, "base64");
      } else if (Buffer.isBuffer(fileData)) {
        buffer = fileData;
      } else {
        return res.status(400).json({ error: "\u0641\u0631\u0645\u062A \u062F\u0627\u062F\u0647\u200C\u0647\u0627\u06CC \u0627\u0631\u0633\u0627\u0644\u06CC \u0641\u0627\u06CC\u0644 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A." });
      }
      if (!buffer || buffer.length === 0) {
        return res.status(400).json({ error: "\u0645\u062D\u062A\u0648\u0627\u06CC \u0641\u0627\u06CC\u0644 \u062E\u0627\u0644\u06CC \u0627\u0633\u062A." });
      }
      let originalName = reqFileName || "image.png";
      let ext = import_path.default.extname(originalName).replace(".", "").toLowerCase();
      if (!ext && detectedExt) {
        ext = detectedExt;
      }
      if (!ext || ["php", "phtml", "exe", "sh", "cgi", "py", "env", "htaccess"].includes(ext)) {
        ext = "png";
      }
      const now = /* @__PURE__ */ new Date();
      const year = now.getFullYear().toString();
      const month = String(now.getMonth() + 1).padStart(2, "0");
      const day = String(now.getDate()).padStart(2, "0");
      const uploadsBase = import_path.default.join(process.cwd(), "uploads", year, month);
      if (!import_fs.default.existsSync(uploadsBase)) {
        import_fs.default.mkdirSync(uploadsBase, { recursive: true });
      }
      const cleanPrefix = (category || "file").replace(/[^a-zA-Z0-9_-]/g, "");
      const timestamp = `${year}${month}${day}_${String(now.getHours()).padStart(2, "0")}${String(now.getMinutes()).padStart(2, "0")}${String(now.getSeconds()).padStart(2, "0")}`;
      const randomHex = Math.random().toString(36).substring(2, 8);
      const generatedFileName = `${cleanPrefix}_${timestamp}_${randomHex}.${ext}`;
      const fullPath = import_path.default.join(uploadsBase, generatedFileName);
      import_fs.default.writeFileSync(fullPath, buffer);
      const relativeUrl = `/uploads/${year}/${month}/${generatedFileName}`;
      const relativePath = `uploads/${year}/${month}/${generatedFileName}`;
      return res.json({
        status: "success",
        url: relativeUrl,
        relativePath,
        fileName: generatedFileName,
        format: ext,
        size: buffer.length,
        year,
        month,
        date: `${year}-${month}-${day}`,
        message: "\u0641\u0627\u06CC\u0644 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062F\u0631 \u067E\u0648\u0634\u0647 uploads \u0628\u0631 \u0627\u0633\u0627\u0633 \u062A\u0627\u0631\u06CC\u062E \u0648 \u0641\u0631\u0645\u062A \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F."
      });
    } catch (err) {
      console.error("Upload error:", err);
      return res.status(500).json({ error: `\u062E\u0637\u0627 \u062F\u0631 \u0622\u067E\u0644\u0648\u062F \u0641\u0627\u06CC\u0644: ${err.message}` });
    }
  });
  const mainUploadsDir = import_path.default.join(process.cwd(), "uploads");
  if (!import_fs.default.existsSync(mainUploadsDir)) {
    import_fs.default.mkdirSync(mainUploadsDir, { recursive: true });
  }
  ensureUploadsSecurityNode();
  app.use("/uploads", import_express.default.static(mainUploadsDir));
  app.use("/public/uploads", import_express.default.static(mainUploadsDir));
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages, systemInstruction } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({
          error: "\u06A9\u0644\u06CC\u062F API \u0628\u0631\u0627\u06CC \u062F\u0633\u062A\u06CC\u0627\u0631 \u0647\u0648\u0634\u0645\u0646\u062F \u062A\u0646\u0638\u06CC\u0645 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A (GEMINI_API_KEY \u06CC\u0627\u0641\u062A \u0646\u0634\u062F). \u0644\u0637\u0641\u0627 \u0622\u0646 \u0631\u0627 \u062F\u0631 \u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F."
        });
      }
      const baseUrl = process.env.GEMINI_BASE_URL || void 0;
      const ai = new import_genai.GoogleGenAI({
        apiKey,
        httpOptions: {
          baseUrl,
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      const contents = messages.map((m) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.text }]
      }));
      let response;
      const chatSysInstruction = systemInstruction || "\u0634\u0645\u0627 \u06CC\u06A9 \u062F\u0633\u062A\u06CC\u0627\u0631 \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0648 \u0645\u0627\u0644\u06CC \u0647\u0648\u0634\u0645\u0646\u062F \u0648 \u0645\u062A\u062E\u0635\u0635 \u0628\u0631\u0627\u06CC \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC \u0645\u0627 \u0647\u0633\u062A\u06CC\u062F. \u0628\u0647 \u062A\u0645\u0627\u0645\u06CC \u0633\u0648\u0627\u0644\u0627\u062A \u0639\u0645\u0648\u0645\u06CC\u060C \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC\u060C \u0627\u0635\u0648\u0644 \u0645\u0627\u0644\u06CC\u0627\u062A\u06CC \u0648 \u0646\u062D\u0648\u0647 \u06A9\u0627\u0631 \u0628\u0627 \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0628\u0627 \u0644\u062D\u0646\u06CC \u0645\u0648\u062F\u0628\u0627\u0646\u0647\u060C \u062D\u0631\u0641\u0647\u200C\u0627\u06CC \u0648 \u0628\u0647 \u0632\u0628\u0627\u0646 \u0641\u0627\u0631\u0633\u06CC \u067E\u0627\u0633\u062E \u062F\u0647\u06CC\u062F.";
      try {
        response = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents,
          config: {
            systemInstruction: chatSysInstruction,
            temperature: 0.7
          }
        });
      } catch (err25) {
        try {
          response = await ai.models.generateContent({
            model: "gemini-2.0-flash",
            contents,
            config: {
              systemInstruction: chatSysInstruction,
              temperature: 0.7
            }
          });
        } catch (err20) {
          try {
            response = await ai.models.generateContent({
              model: "gemini-1.5-flash",
              contents,
              config: {
                systemInstruction: chatSysInstruction,
                temperature: 0.7
              }
            });
          } catch (err15) {
            throw new Error(`\u062E\u0637\u0627\u06CC \u0686\u0646\u062F\u06AF\u0627\u0646\u0647 \u062C\u0645\u06CC\u0646\u0627\u06CC: ${err15.message || "\u0627\u0645\u06A9\u0627\u0646 \u0628\u0631\u0642\u0631\u0627\u0631\u06CC \u0627\u0631\u062A\u0628\u0627\u0637 \u0628\u0627 \u0645\u062F\u0644 \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F"}. \u0631\u0627\u0647\u0646\u0645\u0627: \u062F\u0631 \u067E\u0646\u0644 Google AI Studio \u0645\u0637\u0645\u0626\u0646 \u0634\u0648\u06CC\u062F \u067E\u0631\u0648\u0698\u0647 \u0634\u0645\u0627 \u0628\u0647 \u062F\u0631\u0633\u062A\u06CC \u0645\u062A\u0635\u0644 \u0634\u062F\u0647 \u0648 \u0633\u0631\u0648\u06CC\u0633 Generative Language API \u0641\u0639\u0627\u0644 \u0627\u0633\u062A.`);
          }
        }
      }
      const responseText = response.text || "\u067E\u0627\u0633\u062E\u06CC \u062F\u0631\u06CC\u0627\u0641\u062A \u0646\u0634\u062F.";
      return res.json({ text: responseText });
    } catch (err) {
      console.error("Gemini API Error:", err);
      let errorMsg = err?.message || "\u0645\u0634\u06A9\u0644 \u0646\u0627\u0634\u0646\u0627\u062E\u062A\u0647";
      if (errorMsg.includes("403") || err?.status === 403 || errorMsg.includes("Forbidden") || errorMsg.includes("PERMISSION_DENIED")) {
        errorMsg = "\u062E\u0637\u0627\u06CC \u06F4\u06F0\u06F3 (\u062A\u062D\u0631\u06CC\u0645 \u0645\u0633\u062A\u0642\u06CC\u0645 \u06AF\u0648\u06AF\u0644 \u0628\u0631 \u0639\u0644\u06CC\u0647 \u0627\u06CC\u0631\u0627\u0646). \u0633\u0631\u0648\u06CC\u0633 \u062C\u0645\u06CC\u0646\u0627\u06CC \u06AF\u0648\u06AF\u0644 \u0622\u06CC\u200C\u067E\u06CC\u200C\u0647\u0627\u06CC \u0627\u06CC\u0631\u0627\u0646 \u0631\u0627 \u0645\u0633\u062F\u0648\u062F \u06A9\u0631\u062F\u0647 \u0627\u0633\u062A.\n\n\u0631\u0627\u0647\u06A9\u0627\u0631 \u0642\u0637\u0639\u06CC \u0648 \u0622\u0633\u0627\u0646:\n\u0634\u0645\u0627 \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC\u062F \u06CC\u06A9 \u0622\u062F\u0631\u0633 \u067E\u0631\u0648\u06A9\u0633\u06CC \u0645\u0639\u062A\u0628\u0631 (\u0645\u0627\u0646\u0646\u062F \u0622\u062F\u0631\u0633 https://api.openai-hk.com \u06CC\u0627 \u06CC\u06A9 \u067E\u0631\u0648\u06A9\u0633\u06CC \u0627\u062E\u062A\u0635\u0627\u0635\u06CC \u062F\u06CC\u06AF\u0631) \u062F\u0631 \u0628\u062E\u0634 \u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631\u060C \u06A9\u0627\u062F\u0631 \xAB\u0622\u062F\u0631\u0633 \u067E\u0627\u06CC\u0647 API / \u067E\u0631\u0648\u06A9\u0633\u06CC (Base URL)\xBB \u0648\u0627\u0631\u062F \u06A9\u0631\u062F\u0647 \u0648 \u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0631\u0627 \u0630\u062E\u06CC\u0631\u0647 \u0646\u0645\u0627\u06CC\u06CC\u062F \u062A\u0627 \u062F\u0631\u062E\u0648\u0627\u0633\u062A\u200C\u0647\u0627\u06CC \u0634\u0645\u0627 \u0628\u062F\u0648\u0646 \u062A\u062D\u0631\u06CC\u0645 \u0648 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u0631\u0633\u0627\u0644 \u0634\u0648\u0646\u062F.";
      } else if (errorMsg.includes("429") || err?.status === 429 || errorMsg.includes("RESOURCE_EXHAUSTED") || errorMsg.toLowerCase().includes("quota") || errorMsg.toLowerCase().includes("rate limit")) {
        errorMsg = "\u0645\u062D\u062F\u0648\u062F\u06CC\u062A \u0633\u0647\u0645\u06CC\u0647 \u0631\u0627\u06CC\u06AF\u0627\u0646 \u0647\u0648\u0634 \u0645\u0635\u0646\u0648\u0639\u06CC \u06AF\u0648\u06AF\u0644 (Quota / Rate Limit) \u0628\u0647 \u067E\u0627\u06CC\u0627\u0646 \u0631\u0633\u06CC\u062F\u0647 \u0627\u0633\u062A.\n\n\u0631\u0627\u0647\u06A9\u0627\u0631:\n\u06F1. \u0686\u0646\u062F \u062F\u0642\u06CC\u0642\u0647 \u0635\u0628\u0631 \u06A9\u0646\u06CC\u062F \u062A\u0627 \u0645\u062D\u062F\u0648\u062F\u06CC\u062A \u0633\u0627\u0639\u062A\u06CC/\u062F\u0642\u06CC\u0642\u0647\u200C\u0627\u06CC \u0631\u06CC\u0633\u062A \u0634\u0648\u062F.\n\u06F2. \u06CC\u0627 \u062F\u0631 \u0628\u062E\u0634 \xAB\u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0633\u06CC\u0633\u062A\u0645 > \u0647\u0648\u0634 \u0645\u0635\u0646\u0648\u0639\u06CC\xBB\u060C \u06A9\u0644\u06CC\u062F API \u06CC\u0627 \u067E\u0631\u0648\u06A9\u0633\u06CC \u0627\u062E\u062A\u0635\u0627\u0635\u06CC \u062E\u0648\u062F \u0631\u0627 \u0648\u0627\u0631\u062F \u0646\u0645\u0627\u06CC\u06CC\u062F.\n(\u0633\u0627\u06CC\u0631 \u0628\u062E\u0634\u200C\u0647\u0627\u06CC \u062D\u0633\u0627\u0628\u062F\u0627\u0631\u06CC\u060C \u0635\u062F\u0648\u0631 \u0641\u0627\u06A9\u062A\u0648\u0631\u060C \u0627\u0633\u0646\u0627\u062F \u0648 \u0627\u0646\u0628\u0627\u0631\u062F\u0627\u0631\u06CC \u06A9\u0627\u0645\u0644\u0627\u064B \u0645\u0633\u062A\u0642\u0644 \u0648 \u0641\u0639\u0627\u0644 \u0647\u0633\u062A\u0646\u062F.)";
      }
      return res.status(500).json({
        error: `\u062E\u0637\u0627 \u062F\u0631 \u0628\u0631\u0642\u0631\u0627\u0631\u06CC \u0627\u0631\u062A\u0628\u0627\u0637 \u0628\u0627 \u062F\u0633\u062A\u06CC\u0627\u0631 \u0647\u0648\u0634\u0645\u0646\u062F: ${errorMsg}`
      });
    }
  });
  app.use("/assets", import_express.default.static(import_path.default.join(process.cwd(), "public", "assets")));
  app.use("/assets", import_express.default.static(import_path.default.join(process.cwd(), "dist", "assets")));
  app.use("/assets", import_express.default.static(import_path.default.join(process.cwd(), "assets")));
  app.use(import_express.default.static(import_path.default.join(process.cwd(), "public")));
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting in DEVELOPMENT mode with Vite dev middleware...");
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting in PRODUCTION mode, serving static files...");
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath, {
      setHeaders: (res, filePath) => {
        if (filePath.endsWith(".html") || filePath.endsWith("sw.js") || filePath.endsWith("manifest.json")) {
          res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
          res.setHeader("Pragma", "no-cache");
          res.setHeader("Expires", "0");
        }
      }
    }));
    app.get("*", (req, res) => {
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://localhost:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
